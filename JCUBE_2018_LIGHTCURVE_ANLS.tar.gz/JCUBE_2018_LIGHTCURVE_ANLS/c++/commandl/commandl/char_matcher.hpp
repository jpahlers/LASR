/*
This descendent of matcher, performs matches against a single character.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: char_matcher.hpp,v 1.2 2003/03/03 00:52:30 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef CHAR_MATCHER_HEADER	// Begin the Header Guard to prevent multiple
#define CHAR_MATCHER_HEADER	//	inclusions.

#include "matcher.hpp"
#include <map>
#include <string>
#include <vector>

namespace commandl
{

/*!
	\brief A matcher class that matches only on the first char of a key.

	This matcher only matches single character keys.
*/
class char_matcher : public matcher
{

// ==================== Constructors & Destructor ===================== //
public:

	char_matcher();

	char_matcher
		(
		std::vector<argument*>	// arguments
		);

	virtual ~char_matcher();

// =========================== Accessors ============================== //
public:

	virtual argument*
	match( const std::string& ) const;

	virtual std::string
	usage_key( const std::string& ) const;

	virtual std::vector<std::string>
	usage_keys( const std::vector<std::string>& ) const;


// =========================== Methods ================================ //
public:

	virtual std::map<std::string, argument*>
	resolve_keys
		(
		const std::vector<argument*>&
		);

	virtual char_matcher*
	clone() const;

// --------------------------- Protected Methods ---------------------- //
protected:


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:


}; // End of the class declaration

} // End of the namespace declaration

#endif	// End the Header Guard

