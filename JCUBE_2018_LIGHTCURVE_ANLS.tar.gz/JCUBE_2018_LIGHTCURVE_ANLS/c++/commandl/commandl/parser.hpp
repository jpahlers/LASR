/*
This is an abstract base class for parsers.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: parser.hpp,v 1.5 2003/03/25 23:53:36 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef BASIC_PARSER_HEADER	// Begin the Header Guard to
#define BASIC_PARSER_HEADER	// prevent multiple inclusions.

#include "argument.hpp"
#include "matcher.hpp"
#include "whole_matcher.hpp"
#include "policy.hpp"
#include <iostream>
#include <map>
#include <string>
#include <utility>
#include <vector>

namespace commandl
{

/*!
	\brief The class from which all parsers descend.

	The parser is the heavy workhorse of the commandl library.  Once
	you have set up all the other kinds of objects, it is the parser
	that uses them all to do the work.  It is highly flexible (because
	of the other classes that it depends on), and configurable.  It can
	be configured to either throw exceptions or not.  My guess is that
	the commandl::parser class will probably be the least subclassed,
	but I could very well be wrong.

*/
//template <typename matcherT>
class parser
{

// ==================== Constructors & Destructor ===================== //
public:

	/*
	parser
		(
		matcher,						// matcher
		policy = policy()		// policy
		);
	*/

	parser
		(
		const std::vector<argument*>&,	// arguments
		const matcher&,					// matcher
		const policy&						// policy
		);

	parser
		(
		const std::vector<argument*>&,	// arguments
		const matcher&					// matcher
		);

	parser
		(
		const std::vector<argument*>&		// arguments
		);

	parser( const parser& );
		

	virtual ~parser();

// =========================== Accessors ============================== //
public:

	virtual std::string
	name() const;

	virtual unsigned long
	stop_position() const;

	virtual std::map<unsigned long, std::string>
	elements_without_prefixes() const;

	virtual std::map<unsigned long, std::string>
	elements_without_keys() const;

	virtual std::map<unsigned long, std::string>
	elements_after_stop() const;

	virtual std::ostream&
	usage( std::ostream& = std::cout ) const;

	virtual std::ostream&
	usage( argument*, std::ostream& = std::cout ) const;

	virtual std::ostream&
	short_usage( std::ostream& = std::cout ) const;

	virtual std::ostream&
	short_usage( argument*, std::ostream& = std::cout ) const;

// =========================== Methods ================================ //
public:

	virtual void set_name( const std::string& );
	virtual void exceptions( bool = true );

	virtual bool parse( int, char**, std::ostream& = std::cout );
	virtual bool parse( std::vector<std::string>, std::ostream& = std::cout );
	/*virtual void parse	(
						std::vector<std::string>::iterator,
						std::vector<std::string>::iterator
						);
	*/

	virtual parser& operator=( const parser& );

// --------------------------- Protected Methods ---------------------- //
protected:

	virtual std::pair<std::string, std::string>
	separate_prefix_from( std::string );

	virtual std::pair<std::string::size_type, std::string>
	find_assignment_in( std::string );

	virtual void
	identify_prefix_and_key( std::string );

	virtual void
	parse_required_values	(
							std::string,
							std::string,
							std::string,
							std::string,
							commandl::argument*,
							std::vector<std::string>::iterator&,
							std::vector<std::string>::iterator
							);
	virtual void
	parse_optional_values	(
							std::string,
							std::string,
							std::string,
							std::string,
							commandl::argument*,
							std::vector<std::string>::iterator&,
							std::vector<std::string>::iterator
							);
	virtual void
	parse_character_keys	(
							std::string,
							std::string,
							std::vector<std::string>::iterator&,
							std::vector<std::string>::iterator,
							bool = false
							);


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:

	//! This is the vector of argument* that parser will parse for.
	std::vector<argument*>					Arguments;

	//! This is the matcher* that parser will use to match arguments.
	matcher*								Matcher_ptr;

	//! This is the policy object that parser will use.
	policy									Policy;

	//! This determines whether parser throws commandl exceptions or not.
	bool									Throws_Exceptions;

	/*! Optional name of the program, can be set in parser for nice usage 
		statements.
	*/
	std::string								Name;

	//! This is a counter for how far along the parser is.
	unsigned long int						Position;

	//! This is the position at which the parser stopped parsing.
	unsigned long int						Stop_Position;

	//! This is the vector of Elements that parser is currently parsing.
	std::vector<std::string>				Elements;

	/*! If the Policy allows for it, this map contains the parsed elements
		that did not have valid prefixes.  They are stored as the position
		of an element without a valid prefix, and the element itself.
	*/
	std::map<unsigned long, std::string>	Elements_without_prefixes;

	/*! If the Policy allows for it, this map contains the parsed elements
		that did not have matching keys.  They are stored as the position
		of an element without a matching key, and the element itself.
	*/
	std::map<unsigned long, std::string>	Elements_without_keys;

	/*! If there were any elements after the parser was told to stop parsing
		they will be in this map.  They are stored as the position
		of the element, and the element itself.
	*/
	std::map<unsigned long, std::string>	Elements_after_stop;

}; // End of the class declaration

} // End of the namespace declaration

#endif	// End the Header Guard

