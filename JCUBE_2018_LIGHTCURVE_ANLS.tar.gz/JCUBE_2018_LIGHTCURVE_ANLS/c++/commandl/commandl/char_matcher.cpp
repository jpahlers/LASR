/*
This descendent of matcher, performs matches against a single character. 
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: char_matcher.cpp,v 1.4 2003/03/03 00:52:30 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "exceptions.hpp"
#include "argument.hpp"
#include "matcher.hpp"
#include "char_matcher.hpp"
#include <algorithm>
#include <map>
#include <string>
#include <vector>

#if defined (DEBUG)
/*******************************************************************************        DEBUG controls
 
        DEBUG report selection options.
        Define any of the following options to obtain the desired debug reports:*/
#define DEBUG_ALL               (-1)
#define DEBUG_CONSTRUCTORS      (1 << 0)
#define DEBUG_ACCESSORS         (1 << 1)
 
#include        <iostream>
#include        <iomanip>
using std::cerr;
using std::endl;
#endif  //      DEBUG

/*
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "int_arg ($Revision: 1.4 $ $Date: 2003/03/03 00:52:30 $)";
*/

// ==================== Constructors & Destructor ==================== //

/*!
	\brief A constructor which should be followed by a call to set_arguments().
*/
commandl::char_matcher::char_matcher()
	: matcher()
	{ }

/*!
	\brief Primary constructor for this class.
*/
commandl::char_matcher::char_matcher
	(
	std::vector<argument*>	arguments
	)
	: matcher()
	{
	Keys = resolve_keys( arguments );
	}

commandl::char_matcher::~char_matcher()
	{ }


// =========================== Accessors ============================== //

/*!
	\brief This method will perform matching on a string.

	However, the string should only be a single character long.
	Anything else will cause an exception.
*/
commandl::argument*
commandl::char_matcher::match( const std::string& key ) const
	{
	using std::map;
	using std::string;

	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << ">>> char_matcher::match (" << key << ")" << endl;
	#endif

	if( key.empty() )
		{
		throw matcher_exception	(
								"An empty key cannot be matched against.",
								key
								);
		}

	if( key.size() > 1 )
		{
		throw matcher_exception	(
								"The key \"" + key 
								+ "\" has more than one character.",
								key
								);
		}
	// To get this far key can be a string of only one character.

	// Let's try and find this key.
	map<string, argument*>::const_iterator matched_iter
															= Keys.find( key );

	if( matched_iter == Keys.end() )
		{
		throw matcher_exception	(
								"Couldn't find a key matching \"" 
								+ key + "\"",
								key
								);
		}

	argument* matched_arg = matched_iter->second;

	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << "<<< char_matcher::match (" << key << ") returned a match."
			<< endl;
	#endif
	return matched_arg;
	//return (*matched_iter)->second;
	}

std::string
commandl::char_matcher::usage_key( const std::string& key ) const
	{
//cout << "char_matcher(usage_key) method" << endl;
	std::string output_key( key, 0, 1 );
	return output_key;
	}

std::vector<std::string>
commandl::char_matcher::usage_keys
	(
	const std::vector<std::string>& keys
	) const
	{
	std::vector<std::string> output_keys;
	output_keys.reserve( keys.size() );

	/* The below doesn't seem to be working.
	std::transform	(
					keys.begin(), keys.end(),
					back_inserter( output_keys ),
					std::mem_fun_ref( &char_matcher::as_key )
					);
	*/

	for	(
		std::vector<std::string>::const_iterator key_iter = keys.begin();
		key_iter != keys.end();
		++key_iter
		)
		{
		std::string out_key = usage_key( *key_iter );
		output_keys.push_back( out_key );
		}

	return output_keys;
	}

// =========================== Methods ================================ //

/*!
	\brief This method performs the task of providing unique keys.

	For this class, doing so involves taking only the first character
	from the potential keys provided by the arguments.  If there
	is a conflict between the first letters of two potential keys
	(like "file" and "forget"), then this method will throw.
*/
std::map<std::string, commandl::argument*>
commandl::char_matcher::resolve_keys
	(
	const std::vector<argument*>& arguments
	)
	{
	using std::map;
	using std::string;
	using std::vector;
	
	map<string, argument*>	key_map;
	map<string, int>				key_count;

	for	(
		vector<argument*>::const_iterator arg_iter = arguments.begin();
		arg_iter != arguments.end();
		++arg_iter
		)
		{
		vector<string> arg_keys = (*arg_iter)->get_keys();

		for	(
			vector<string>::const_iterator arg_key_iter = arg_keys.begin();
			arg_key_iter != arg_keys.end();
			++arg_key_iter
			)
			{
			string key( *arg_key_iter, 0, 1 );
			
			/*if( *arg_key_iter.empty() )
				{
				throw matcher_exception	(
										"The potential key \""
										+ *key_iter 
										+ "\" has more than one character.",
										*key_iter
										);
				}
			*/

			// note that below initializes key_count[key] to zero.
			if( key_count[key] > 0 )
				{
				throw matcher_exception	(
										"The potential key \""
										+ key
										+ "\" from \""
										+ *arg_key_iter 
										+ "\" is duplicated.",
										*arg_key_iter
										);
				}

			key_map[key]	= *arg_iter;
			key_count[key]	+= 1;
			}
		}

	return key_map;
	}

/*!
	\brief This method returns a newed copy of this object.

	Since the pointer returned has been newed, it is imperative that
	callers of this method are sure to call delete on the pointer.
*/
commandl::char_matcher*
commandl::char_matcher::clone() const
	{
	return new char_matcher( *this );
	}


// --------------------------- Protected Methods ---------------------- //


// --------------------------- Private Methods ------------------------ //

