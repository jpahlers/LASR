/*
This is a descendent of argument that deals with float values.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: float_arg.cpp,v 1.2 2003/03/03 00:52:30 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <sstream>
#include "exceptions.hpp"
#include "argument.hpp"
#include "float_arg.hpp"

/*
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "float_arg ($Revision: 1.2 $ $Date: 2003/03/03 00:52:30 $)";
*/

// ==================== Constructors & Destructor ==================== //


/*!
	\brief Constructor that takes multiple keys to build an float_arg.

	\overload commandl::argument::argument
*/
commandl::float_arg::float_arg
	(
	std::vector<std::string>	key_strings,	// keys
	std::string					value_desc,		// value description
	std::string					desc,			// description
	bool						required,		// argument required?
	bool						val_required	// value required?
	)
	:	argument	(
					key_strings,
					value_desc,
					desc,
					required,
					int(1),
					val_required
					),
		arguments_float( 0 )
	{ }

/*!
	\brief Constructor that takes a single key to build an float_arg.

	\overload commandl::argument::argument
*/
commandl::float_arg::float_arg
	(
	std::string		key_string,		// key
	std::string		value_desc,		// value description
	std::string		desc,			// description
	bool			required,		// argument required?
	bool			val_required	// value required?
	)
	:	argument	(
					key_string,
					value_desc,
					desc,
					required,
					int(1),
					val_required
					),
		arguments_float( 0 )
	{ }


// =========================== Accessors ============================== //

/*!
	\brief This operator allows automatic conversion of a float_arg to an float.

	\return A float.
*/
commandl::float_arg::operator float() const
	{
	return arguments_float;
	}

// =========================== Methods ================================ //

/*!
	\brief This operator is called when there is no value to pass in.

	This operator should only be called when there is no corresponding
	value to be set.  If values_size() returns anything other than
	zero, this version of the operator will 
*/
void
commandl::float_arg::operator()
	(
	const std::string&	prefix,
	const std::string&	key,
	const unsigned long	order
	)
	{
	if( (values_size() != 0) && (values_required()) )
		{
		throw argument_exception(
								"This argument requires a value.",
								this,
								prefix,
								key
								);
		}
	found( order );
	return;
	}

/*!
	\brief Used when there is a single string to be passed as the value.

	This operator should be used to pass a value in to be converted to
	the internal representation of a float within this class.
*/
void
commandl::float_arg::operator()
	(
	const std::string&	value,
	const std::string&	prefix,
	const std::string&	key,
	const std::string&	assign,
	const unsigned long	order
	)
	{
	using namespace std;

	istringstream in( value );
	float	float_value;
	string	after_float;
	if( !(in >> float_value) )
		{
		throw argument_exception(
								"Could not parse a float from \""
									+ value + "\"",
								this,
								prefix,
								key,
								assign,
								value
								);
		}
	if( in >> after_float )
		{
		ostringstream message;
		message << "There were extra characters after " << float_value
				<< " in the value \"" << value << "\"";
		throw argument_exception(
								message.str(),
								this,
								prefix,
								key,
								assign,
								value
								);
		}

	arguments_float = float_value;
	found( order );
	return;
	}

/*!
	\brief Can be used to pass a value contained in a vector.

	It is important to note that float_arg can take only a single
	float as its value.  If the vector passed in has more than
	a single element, this operator will throw.
*/
void
commandl::float_arg::operator()
	(
	const std::vector<std::string>&		values,
	const std::string&					prefix,
	const std::string&					key,
	const std::string&					assign,
	const unsigned long					order
	)
	{
	if( values.size() != 1 )
		{
		throw argument_exception(
								"This argument only takes a single value.",
								this,
								prefix,
								key,
								assign,
								values
								);
		}
	operator()( values.front(), prefix, key, assign, order );
	}

/*!
	\brief This operator allows assignment of a float value.
*/
commandl::float_arg&
commandl::float_arg::operator=( const float& new_float )
	{
	arguments_float = new_float;
	return *this;
	}


// --------------------------- Protected Methods ---------------------- //


// --------------------------- Private Methods ------------------------ //

