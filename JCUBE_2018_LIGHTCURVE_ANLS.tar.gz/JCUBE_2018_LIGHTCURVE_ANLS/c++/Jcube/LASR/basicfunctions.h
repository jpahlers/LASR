#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <iterator>
#include <limits>
#include <unistd.h>
#include "/usr/include/cfitsio/fitsio.h"
#include "../Jcrap.h"
#include "constants.h"
#ifndef BASICFUNCTIONS_H
#define BASICFUNCTIONS_H

using namespace std;

namespace BasicFunctions
{
	string currentpath();
	bool fileexist(string); //test to see if a file is accessible
	pair<double,int> findclosest(vector<vector<double> >, double, double);
	double gaussrand(double, double); //Uses Box-Muller transform with random seeding
	double white2red(double, double, double);
	bool stringisnumber(string);
	pair<double,double> vectordiff(vector<double>, vector<double>);//find |r1-r2| for any dimension of vectors
	vector<vector<double> > vectorsort(vector<vector<double> >, const int); //sort according to column number
	vector<pair<double,string> > pairsort(vector<pair<double,string> >);
	double vectorsum(vector<vector<double> >, int); //sum a single column of a vector of vectors
	vector<vector<double> > Zcube2vec(cube);
	cube combineZcubes(vector<cube>);
	int factorial(int);
	int sumcount(int);
	double mod(double, double);
	double MAX(double, double);
	double MIN(double, double);
	double SIGN(double, double);
}

	
namespace PeriodogramBasics
{
	vector<vector<double> > cutoutpeak(vector<vector<double> >, int, int);
}				
namespace Statistics{
	struct Gamma{
		static const int ASWITCH=100;
		static const double EPS;
		static const double FPMIN;
		static const int ngau = 18;
		double gln;
		static const double y[18];
		static const double w[18];
		double gammln(const double);
		double gammp(const double, const double);
		double gammq(const double, const double);
		double gser(const double, const double);
		double gcf(const double, const double);
		double gammpapprox(double, double, int);
		double invgammp(double, double);
	};
	
	struct Chisqdist{
		Gamma gam;
		double nu,fac;
		Chisqdist(double nnu) : nu(nnu) {
			if (nu <= 0.) throw("ERROR: negative degrees of freedom in Chisqdist");
			fac = 0.693147180559945309*(0.5*nu)+gammln(0.5*nu);
		}

		double p(double x2) {
			if (x2 <= 0.) throw("bad x2 in Chisqdist");
			return exp(-0.5*(x2-(nu-2.)*log(x2))-fac);
		}
		double cdf(double x2) {
			if (x2 < 0.) throw("bad x2 in Chisqdist");
			return gam.gammp(0.5*nu,0.5*x2);
		}

		double invcdf(double p) {
			if (p < 0. || p >= 1.) throw("bad p in Chisqdist");
			return 2.*gam.invgammp(p,0.5*nu);
		}
	};
}	
	
namespace Latex{
	pair<double,double> unc2latex(double);	
	
	
	
	
	
	
	
	
}	
	









































#endif
