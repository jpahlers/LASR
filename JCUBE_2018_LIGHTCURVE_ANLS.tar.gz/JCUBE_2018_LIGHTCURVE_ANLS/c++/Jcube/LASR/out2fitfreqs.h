#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <iterator>
#include <limits.h>
#include <unistd.h>
#include "../Jcrap.h"
#include "basicfunctions.h"
#include "constants.h"


using namespace std;
using namespace Constants;
