class despinner : public Jcrap::diffeq<double>, public EGP
{
	public:
		despinner(EGP planet, value);
		~despinner();
		
		value avgtorque(value);
		double avgtorque(double);
		value torque(double);
		double torque_dbl(double);
		double cheaptorque(double);
		
		double odeint_newstop (double x1);

	protected:
		void derivs(double, vector<double>&, vector<double>&);
		double func(double d){ return torque_dbl(d); };
		double auxfunc(double);
	private:
		value avgtorque_hirotation;
		value maxfdot;
		value minfdot;					// max and min anomaly change rates rads/sec

};


#include "spinorbit.h"

class delineator : public Jcrap::diffeq<double>
/* This will calculate what eccentricity below which despin equilibrium always brings the
synchronous radius outside the max stable orbit radius */
{
	public:
	void derivs(double, vector<double>&, vector<double>&) { 1; }
	double auxfunc(double e) { return (spinorbit(e)-2.887); }
};

double e_crit();
