#include<string>
#include<list>
#include<iostream>
#include<iomanip>
#include<vector>
#include"../Jcrap.h"
#include"astro.h"

#ifndef EGP_h
#define EGP_h 1

using namespace Jcrap;

class EGP : public astro::object
{
	public:
		string starname;
		value starmass;				// in Msun
		value starradius;				// in Rsun
		string startype;				// spectral type
		value stardistance;			// in parsecs
		value m_v;						// V magnitude
		value starlum;					// in Lsun
		value age;						// in Gyr
		value metallicity;			// [Fe/H]/[Fe/H Sun]
//		string name;					//
//		value mass;						// in Mjup
//		value radius;					// in Rjup
//		value period;					// in days
//		value semimajoraxis;			// in AU
//		value eccentricity;			//
		string references;
		string bibtex;
		
//		double Q;
//		double k2;
//		double C_MR2;					// Moment of inertia coefficient C
//		value I;							// Moment of inertia
//		value n;							// mean motion
		value D;							// Torque constant from M&D p 191
//		value Tau;						// Time of perihelion
		value rotrate;					// rotation rate, radians/sec: pseudoglobal variable passed in to do integrations
		double rotrate_dbl;
// these are here so that they don't need to be recalculated over the course
// of the calculations
		value Rhill;
		value Rroche;
		value despintime_var;
		double spinorbitratio;
		unsigned long int arrayspace;
		double savedx;
		
		
				
		EGP(string);
		EGP();	
		
		pair<double, double> orbitelements(double);
		pair<value, value> orbitelements(value);
		double fdot(pair<double, double>);
		value fdot(pair<value, value>);
		value orbitdecaytime(value);
		value orbitevolutiontime(value, value, value);
		value despintime(value);
		value despintest(value);
		value maxsatmass();
		value maxsatmass(value, value, value);
		
		value despintime_adv(value, double);
		value spiralintime_adv(double);
		value spinuptolock_adv(double, double);
		value lifetimeintegrate(value, value, bool = 1, double=3.15e13);
		value maxlifetime_adv(value);
		pair<value,cube> satlifetime(value);
		pair<value,cube> maxsatmass_adv();
		
	
		
		static void loadbestiary();
		static list<EGP> bestiary;	
		static EGP hypothetical(value, value, value, double=0);
		void compilevars();
		void convert(unit);

};

ostream& operator<<(ostream& out, EGP planet);

#endif
