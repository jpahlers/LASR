#ifndef astro_h
#define astro_h

namespace astro {
	class object;
}


class astro::object
{
	public:
// required quantities
		string name;
		value mass;
		value radius;
		
		value semimajoraxis;
		value period;
		value eccentricity;
		value Tau;					// time of perehelion

// not necessarily req'd ones
		double Q;					// tidal dissipation parameter
		double k2;					// love #
		double C_MR2;				// moment of inertia coefficient
		
// calculated ones
		value I;						// Moment of inertia
		value n;						// mean motion
		
// related objects
		object *primary;
		list<object> satellites;
		
// methods
//		virtual pair<double, double> orbitelements(double) { 1; }
//		virtual pair<value, value> orbitelements(value) { 1; }
//		virtual double fdot(pair<double, double>) { 1; }
//		virtual value fdot(pair<value, value>) { 1; }

	private:
};
#endif
