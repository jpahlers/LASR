#ifndef imagespace_h
#define imagespace_h 1


#include <string>

#include <qapplication.h>
#include <qimage.h>
#include <qwidget.h>
#include <qpainter.h>
//Added by qt3to4:
#include <QMouseEvent>
#include <QPaintEvent>

#include "../Jcrap.h"
#include "algorithm.h"

class algorithm;

class Jcrap::imagespace : public QWidget
{
	Q_OBJECT

public:
	imagespace(QWidget *parent=0, const char *name=0, const char *startfile=0);
	imagespace(cube, QWidget *parent=0, const char *name=0);
	void load(string imagefilename);
	void load(cube);
	void save(string imagefilename);
	void saveplane(string planefilename);
	string imagefilename();
	bool isCube();
	bool& BW() {return blackandwhite;}
	axis dimension() {return planeaxis;}
	unsigned int N(axis A);
	void setimageplane(axis=Z, int=-1, int=-1);
	float scalemin() const;
	float scalemax() const;
	
	cube& imagecube() {return imgcube;}
	cube& imageplane() {return imgplane;}
	pair<float, float> scaling() 
			{return pair<float, float>(currentscalemin, currentscalemax);}
	
		
	void setscaling();
	void setpreviousimg();
	void blink();
	void setbrightlimits();
	int startplane();
	int endplane() {return end;}
	axis Axis();
	double* axiscalibration();
	void assignwavecal(cube);
	
	void mousePressEvent(QMouseEvent *);
	void mouseMoveEvent(QMouseEvent *);
	void mouseReleaseEvent(QMouseEvent *);
	
	void paintEvent(QPaintEvent *);
	
	
	algorithm *Algorithm;
	
	friend class algorithm;	
	friend class clean;
	friend class zero;
	friend class makegraph;
	friend class colorcube;
	
	pair<int, int> spacecoordinates(QMouseEvent *);
	pair<lonangle, latangle> interpolatedcoordinates(QMouseEvent *, projtype=CYL);

signals:
	void scalingchanged(float, float);
	void pixelchanged(float, float, float);
	void cubeviewpaint(QPaintEvent*);
	
public slots:
	void brightnesscontrast(QMouseEvent *);
	void setpixelinfo(QMouseEvent *);
	void setscaling(float min, float max);
	void setbrightlimits(float min, float max);
	
protected:
	QSize	sizeHint() const;

protected:
// image data
	QImage	img, previousimg, scaledimg;
	cube		imgcube;
	cube		imgplane;
	
	bool		blinktopreviousimage;
	
	
// parameters about where the plane came from
	axis		planeaxis;
	int		start;
	int		end;
	string	imgfilename;
	bool		blackandwhite;
	float		minbrightness;
	float		maxbrightness;
	float		currentscalemin;
	float		currentscalemax;
};

#endif
