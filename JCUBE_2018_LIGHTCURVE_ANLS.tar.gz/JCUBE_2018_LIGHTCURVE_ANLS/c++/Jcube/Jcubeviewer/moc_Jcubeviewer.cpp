/****************************************************************************
** Meta object code from reading C++ file 'Jcubeviewer.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "Jcubeviewer.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Jcubeviewer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Jcrap__cubeviewer[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      19,   18,   18,   18, 0x08,
      30,   18,   18,   18, 0x08,
      41,   18,   18,   18, 0x08,
      53,   18,   18,   18, 0x08,
      60,   18,   18,   18, 0x08,
      71,   18,   18,   18, 0x08,
      85,   18,   18,   18, 0x08,
     102,   18,   18,   18, 0x08,
     119,   18,   18,   18, 0x08,
     136,   18,   18,   18, 0x08,
     149,   18,   18,   18, 0x08,
     160,   18,   18,   18, 0x08,
     174,   18,   18,   18, 0x08,
     186,   18,   18,   18, 0x08,
     197,   18,   18,   18, 0x08,
     209,   18,   18,   18, 0x08,
     216,   18,   18,   18, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_Jcrap__cubeviewer[] = {
    "Jcrap::cubeviewer\0\0loadfile()\0savefile()\0"
    "saveimage()\0quit()\0loadwave()\0"
    "createcolor()\0createclassify()\0"
    "loadmapoffsets()\0subtracthelper()\0"
    "loadmosaic()\0loadmask()\0loadpolygon()\0"
    "loadclean()\0loadzero()\0loadgraph()\0"
    "crop()\0splice()\0"
};

void Jcrap::cubeviewer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        cubeviewer *_t = static_cast<cubeviewer *>(_o);
        switch (_id) {
        case 0: _t->loadfile(); break;
        case 1: _t->savefile(); break;
        case 2: _t->saveimage(); break;
        case 3: _t->quit(); break;
        case 4: _t->loadwave(); break;
        case 5: _t->createcolor(); break;
        case 6: _t->createclassify(); break;
        case 7: _t->loadmapoffsets(); break;
        case 8: _t->subtracthelper(); break;
        case 9: _t->loadmosaic(); break;
        case 10: _t->loadmask(); break;
        case 11: _t->loadpolygon(); break;
        case 12: _t->loadclean(); break;
        case 13: _t->loadzero(); break;
        case 14: _t->loadgraph(); break;
        case 15: _t->crop(); break;
        case 16: _t->splice(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData Jcrap::cubeviewer::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Jcrap::cubeviewer::staticMetaObject = {
    { &Q3MainWindow::staticMetaObject, qt_meta_stringdata_Jcrap__cubeviewer,
      qt_meta_data_Jcrap__cubeviewer, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Jcrap::cubeviewer::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Jcrap::cubeviewer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Jcrap::cubeviewer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Jcrap__cubeviewer))
        return static_cast<void*>(const_cast< cubeviewer*>(this));
    return Q3MainWindow::qt_metacast(_clname);
}

int Jcrap::cubeviewer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3MainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
