#ifndef Jcubeview_h
#define Jcubeview_h

#include <qslider.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qsplitter.h>
#include <qlabel.h>


#include "imagespace.h"
#include "controlpanel.h"

class Jcrap::cubeview : public QSplitter
{
	Q_OBJECT

public:
	cubeview(cube);
	cubeview(QWidget *parent=0, const char *name=0, const char *startfile=0);
	void load(string loadfilename);
	void load(cube);
	void save(string loadfilename);
	string imagefilename();
	void viewplane(axis=Z, int=0, int=-1);
	Jcrap::imagespace& Imagespace();
	void assignwavecal(cube);

   
public slots:
	void changeplane(int);
	void changescale(float, float);
	void changeplaneto(int);
	void dopaint(QPaintEvent*);
	
private:
	Jcrap::imagespace 	imspace;
	Jcrap::controlpanel	ctrlspace;
	QHBoxLayout 			mainwindow;
};

#endif
