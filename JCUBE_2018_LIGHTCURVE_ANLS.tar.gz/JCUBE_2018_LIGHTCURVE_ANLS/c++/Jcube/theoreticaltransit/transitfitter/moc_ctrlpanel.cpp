/****************************************************************************
** Meta object code from reading C++ file 'ctrlpanel.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "ctrlpanel.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ctrlpanel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ctrlpanel[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      11,       // signalCount

 // signals: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x05,
      22,   10,   10,   10, 0x05,
      33,   10,   10,   10, 0x05,
      46,   10,   10,   10, 0x05,
      62,   10,   10,   10, 0x05,
      74,   10,   10,   10, 0x05,
      87,   10,   10,   10, 0x05,
     100,   10,   10,   10, 0x05,
     117,   10,   10,   10, 0x05,
     130,   10,   10,   10, 0x05,
     142,   10,   10,   10, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_ctrlpanel[] = {
    "ctrlpanel\0\0foldData()\0cropData()\0"
    "filterData()\0normalizeData()\0cleanData()\0"
    "foldVisual()\0cropVisual()\0residualVisual()\0"
    "exportData()\0exportFit()\0exportResiduals()\0"
};

void ctrlpanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ctrlpanel *_t = static_cast<ctrlpanel *>(_o);
        switch (_id) {
        case 0: _t->foldData(); break;
        case 1: _t->cropData(); break;
        case 2: _t->filterData(); break;
        case 3: _t->normalizeData(); break;
        case 4: _t->cleanData(); break;
        case 5: _t->foldVisual(); break;
        case 6: _t->cropVisual(); break;
        case 7: _t->residualVisual(); break;
        case 8: _t->exportData(); break;
        case 9: _t->exportFit(); break;
        case 10: _t->exportResiduals(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData ctrlpanel::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ctrlpanel::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_ctrlpanel,
      qt_meta_data_ctrlpanel, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ctrlpanel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ctrlpanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ctrlpanel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ctrlpanel))
        return static_cast<void*>(const_cast< ctrlpanel*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int ctrlpanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void ctrlpanel::foldData()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void ctrlpanel::cropData()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void ctrlpanel::filterData()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void ctrlpanel::normalizeData()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void ctrlpanel::cleanData()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}

// SIGNAL 5
void ctrlpanel::foldVisual()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}

// SIGNAL 6
void ctrlpanel::cropVisual()
{
    QMetaObject::activate(this, &staticMetaObject, 6, 0);
}

// SIGNAL 7
void ctrlpanel::residualVisual()
{
    QMetaObject::activate(this, &staticMetaObject, 7, 0);
}

// SIGNAL 8
void ctrlpanel::exportData()
{
    QMetaObject::activate(this, &staticMetaObject, 8, 0);
}

// SIGNAL 9
void ctrlpanel::exportFit()
{
    QMetaObject::activate(this, &staticMetaObject, 9, 0);
}

// SIGNAL 10
void ctrlpanel::exportResiduals()
{
    QMetaObject::activate(this, &staticMetaObject, 10, 0);
}
QT_END_MOC_NAMESPACE
