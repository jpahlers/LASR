#include "plotspace.h"
//Added by qt3to4:
#include <QPaintEvent>
#include <QResizeEvent>
#include <QMouseEvent>
#include <Q3MemArray>

plotspace::plotspace(QWidget *parent, const char *name, Qt::WFlags flags)
			: QWidget(parent, name, flags | Qt::WNoAutoErase)
{
	setBackgroundMode(Qt::PaletteDark);
	setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
	
	residual=0;
	fold=0;
	crop=0;
	GreyBoxon=0;
	
	loaddata(cube(0,0,0));
	
	
}


QSize plotspace::sizeHint() const
{
	return QSize(640,480);
}

void plotspace::loaddata(cube incube)
{
	Data = incube;
	
	setlimits(Data);
		
	refreshPixmap();
	
}

void plotspace::setlimits(cube incube)
{
	osuppress++;
	
// setting time limits on x axis
	if (crop) {
		_timeonleft  = _centertime-_cropfraction*_period;
		_timeonright = _centertime+_cropfraction*_period;
	} else {
		_timeonleft  = incube.minaxis(Z);
		_timeonright = incube.maxaxis(Z);
		double tmargin((_timeonright-_timeonleft)/50.);
		_timeonleft -= tmargin;
		_timeonright+= tmargin;
	} 
		
// setting flux limits on y axis
	if (incube.N(Z)>1) {
		_fluxmax     = incube.plane(X,0).max();
		_fluxmin     = incube.plane(X,0).min();
		double fmargin((_fluxmax-_fluxmin)/40.);
		_fluxmax    += fmargin;
		_fluxmin    -= 3.*fmargin;
	} else if (Data.N(Z)>1 && Guess.N(Z)>1) {
		cube all(Data.plane(X,0).blocksz(Guess.plane(X,0)));
		_fluxmax     = all.max();
		_fluxmin     = all.min();
		double fmargin((_fluxmax-_fluxmin)/40.);
		_fluxmax    += fmargin;
		_fluxmin    -= 3.*fmargin;
	} else if (Guess.N(Z)>1) {
		_fluxmax     = Data.plane(X,0).max();
		_fluxmin     = Data.plane(X,0).min();
		double fmargin((_fluxmax-_fluxmin)/40.);
		_fluxmax    += fmargin;
		_fluxmin    -= 3.*fmargin;
	} else if (Guess.N(Z)>1){
		_fluxmax     = Guess.plane(X,0).max();
		_fluxmin     = Guess.plane(X,0).min();
		double fmargin((_fluxmax-_fluxmin)/40.);
		_fluxmax    += fmargin;
		_fluxmin    -= 3.*fmargin;
	} else {
		_fluxmax = 1.01;
		_fluxmin = 0.97;
	}
	
	osuppress--;
}

void plotspace::loadguess(cube incube)
{
	Guess = incube;
		
	refreshPixmap();
}

void plotspace::loadfit(cube incube)
{
	Fit = incube;
	
	refreshPixmap();
}

void plotspace::savefit(string savefilename)
{
	if (savefilename.find(".Jcube")!=string::npos) 
		savefilename = savefilename.substr(0,savefilename.find(".Jcube"));
	cout << "Root savename = \"" << savefilename << "\"\n";
	
	
	
	string dataname(savefilename+string(".data.Jcube"));
	Data.write(dataname.c_str());
	
	string guessname(savefilename+string(".guess.Jcube"));
	Guess.write(guessname.c_str());
	
	string fitname(savefilename+string(".fit.Jcube"));
	Fit.write(fitname.c_str());
	
	string residualname(savefilename+string(".residual.Jcube"));
	if (Data.N(Z) == Fit.N(Z)) (Data.plane(X,0)-Fit).write(residualname.c_str());
		
}

void plotspace::saveimage(string savefilename)
{
	if (savefilename.find(".png")!=string::npos) 
		savefilename = savefilename.substr(0,savefilename.find(".png"));
	savefilename+= string(".png");
	cout << "Saveimagename = \"" << savefilename << "\"\n";
	
	const QString outname(QString::fromStdString(savefilename));
	
	pixmap.save(outname,"PNG",1.0);
		
}
cube& plotspace::data() {return Data;}

cube plotspace::copyofdata() const
{
	return Data;
}

cube plotspace::fit() const
{
	return Fit;
}


void plotspace::paintEvent(QPaintEvent *event)
{
	Q3MemArray<QRect> rects = event->region().rects();
	for (int i=0;i<int(rects.size());i++)
		bitBlt(this, rects[i].topLeft(), &pixmap, rects[i]);
	
	QPainter painter(this);
}

void plotspace::resizeEvent(QResizeEvent* /*event*/)
{
	refreshPixmap();
}

void plotspace::redraw() { refreshPixmap(); }

void plotspace::refreshPixmap()
{
	pixmap.resize(size());
	pixmap.fill(this, 0, 0);
	QPainter painter(&pixmap);
//	QPainter painter(&pixmap, this);  // used to be this in Qt3
	
	
	painter.fillRect(0,0,width(),height(),QColor(0,0,0));
	if (GreyBoxon) drawGreyBox(&painter);
	
	drawData(&painter);
	drawGuess(&painter);
	drawData(&painter);
	drawFit(&painter);
	
	
	update();
	
	
}



bool isoutside2(cube& c, axis A, int a)
{
	bool answer(1);
	double lowerlimit, upperlimit;
		
	if (A==X) answer = 1;
	else if (A==Y) answer = 1;
	else if (A==Z) {
		lowerlimit = str2double(c.keyword("croplowerlimit"));
		upperlimit = str2double(c.keyword("cropupperlimit"));
		if ((double(c.Axis(Z,a)) > upperlimit)  ||  (double(c.Axis(Z,a)) < lowerlimit))
			answer = 0;
	}
	
//	cout << "upperlimit = " << upperlimit << "\n";
//	cout << ", lowerlimit = " << lowerlimit << "\n";
//	cout << "In evaluator for A=" << A << ", a=" << a << ".  answer=" << answer;
//	cout << ", value=" << c(0,0,a) << ",  z=" << c.Axis(Z,a) << "\n";
	
	return answer;
}

void plotspace::drawData(QPainter *painter)
{
	drawCube(painter, Data, 1);
}

void plotspace::drawGuess(QPainter *painter)
{
	if (Guess.N(Z))
		drawCube(painter, Guess, 2);
}

void plotspace::drawFit(QPainter *painter)
{
	if (Fit.N(Z))
		drawCube(painter, Fit, 3);
}

void plotspace::drawCube(QPainter *painter, cube drawcube, int method)
{	
	cube todrawdata(drawcube);
	
	if (residual) {
		if (drawcube.N(Z) == Fit.N(Z))
			todrawdata = drawcube-Fit;
		else if (drawcube.N(Z) == Guess.N(Z))
			todrawdata = drawcube-Guess;	
	}
	if (fold) {
		for (int z(0);z<todrawdata.N(Z);z++) {
			while (todrawdata.Axis(Z,z) > _centertime+_period/2.) 
				todrawdata.Axis(Z,z) -= _period;
			while (todrawdata.Axis(Z,z) < _centertime-_period/2.)
				todrawdata.Axis(Z,z) += _period;
		}
	}
	if (crop) {
		todrawdata.keyword("croplowerlimit") = Data.keyword("croplowerlimit");
		todrawdata.keyword("cropupperlimit") = Data.keyword("cropupperlimit");
		todrawdata = todrawdata.smartselectivespliceout(&isoutside2);
	}	
	
	if (method==1)  // data
		{
			
			setlimits(todrawdata);
		}
	
	int upperpoint(todrawdata.N(Z));
	if (method!=1) upperpoint-=2;
	for (int i(0);i<upperpoint;i++) {
		int x1(int((todrawdata.Axis(Z,i)-timeonleft())/(timeonright()-timeonleft())*width()));
		int y1(int((1.-(todrawdata(0,0,i)-fluxmin())/(fluxmax()-fluxmin()))*height()));
		
		
		if (method==1) {  // data
			painter->setPen(QPen(Qt::white,1,Qt::SolidLine));
				
			painter->drawLine(x1-plussize(), y1, x1+plussize()+1, y1);
			painter->drawLine(x1, y1-plussize(), x1, y1+plussize()+1);
		} else {
			int x2(int((todrawdata.Axis(Z,i+1)-timeonleft())/(timeonright()-timeonleft())*width()));
			int y2(int((1.-(todrawdata(0,0,i+1)-fluxmin())/(fluxmax()-fluxmin()))*height()));
			if (method==2) {  // guess
				painter->setPen(QPen(Qt::blue, 1, Qt::SolidLine));
			
				painter->drawLine(x1,y1,x2,y2);
			}
			if (method==3) {  // fit
				painter->setPen(QPen(QColor(0,255,255), 2, Qt::SolidLine));
			
				painter->drawLine(x1,y1,x2,y2);
			}
		}
	}
}

void plotspace::drawGreyBox(QPainter *painter)
{
	double temp;
	if (GreyBoxleft > GreyBoxright) {
		temp = GreyBoxleft;
		GreyBoxleft = GreyBoxright;
		GreyBoxright = temp;
	}
	
	int x1((GreyBoxleft-timeonleft())/(timeonright()-timeonleft())*width());
	int x2((GreyBoxright-timeonleft())/(timeonright()-timeonleft())*width());
	painter->fillRect(x1,0,x2-x1,height(),QColor(128,128,128));
}

void plotspace::setGreyBox(bool b) 
{
	GreyBoxon=b;
	redraw();
}

void plotspace::setGreyBox(pair<double, double> l, pair<double,double> r) 
{
	GreyBoxleft=l.first;
	GreyBoxright=r.first;
	redraw();
}

pair<double, double> plotspace::getGreyBox()
{
	pair<double, double> answer;
	answer.first = GreyBoxleft;
	answer.second= GreyBoxright;
	return answer;
}

void plotspace::mousePressEvent(QMouseEvent*event)
{
	double trange = _timeonright - _timeonleft;
	int twidth = width();
	double tinterval = trange/twidth;
	
	int xclicked = event->x();
	
	_xvaluecoordinate = _timeonleft+tinterval*xclicked;
	
	

	double fmax = Data.plane(X,0).max();
	double fmin = Data.plane(X,0).min();
	double fmargin = (fmax-fmin)/40;
	int fheight = height();
	double finterval = ((fmax-fmin)+4*fmargin)/fheight;
	
	int yclicked = event->y();
	
	_yvaluecoordinate = (fmax+fmargin)-finterval*yclicked;
	
	cout<<"Time(s): "<<_xvaluecoordinate<<endl;
	cout<<"Flux: "<<_yvaluecoordinate<<endl;
	cout << "timeonleft= " << _timeonleft << "\n";
	
	returncoordinates();
	
	emit updateCoordinates();

}

pair<float,float> plotspace::returncoordinates()
{
	pair<float,float> coordinates;
	coordinates.first=_xvaluecoordinate;
	coordinates.second=_yvaluecoordinate;
	
	//cout<<"coordinates are:"<<coordinates.first<<"	"<<coordinates.second<<endl;
	
	
	return coordinates;
}

void plotspace::toggleresidual()
{
	residual = !residual;
	redraw();
}

void plotspace::togglefold(double in_t0, double in_period)
{
	_centertime=in_t0;
	_period=in_period;
	fold = !fold;
	redraw();
}


void plotspace::togglecrop(double in_t0, double in_period, double in_cropfrac)
{
	_centertime=in_t0;
	_period=in_period;
	_cropfraction=in_cropfrac;
	crop = !crop;
	
	Data.keyword("croplowerlimit", double2str(_centertime-_cropfraction*_period));
	Data.keyword("cropupperlimit", double2str(_centertime+_cropfraction*_period));
	
	redraw();
}
