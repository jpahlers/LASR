/****************************************************************************
** Meta object code from reading C++ file 'transitfitter.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "transitfitter.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'transitfitter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_transitfitter[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x08,
      26,   14,   14,   14, 0x08,
      36,   14,   14,   14, 0x08,
      47,   14,   14,   14, 0x08,
      59,   14,   14,   14, 0x08,
      66,   14,   14,   14, 0x0a,
      85,   14,   14,   14, 0x0a,
     108,   14,   14,   14, 0x0a,
     132,   14,   14,   14, 0x0a,
     158,   14,   14,   14, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_transitfitter[] = {
    "transitfitter\0\0loadfile()\0addfile()\0"
    "savefile()\0saveimage()\0quit()\0"
    "precessiontoggle()\0showlightcurvetoggle()\0"
    "showinclinationtoggle()\0"
    "showascendingnodetoggle()\0"
    "showstellarobliquitytoggle()\0"
};

void transitfitter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        transitfitter *_t = static_cast<transitfitter *>(_o);
        switch (_id) {
        case 0: _t->loadfile(); break;
        case 1: _t->addfile(); break;
        case 2: _t->savefile(); break;
        case 3: _t->saveimage(); break;
        case 4: _t->quit(); break;
        case 5: _t->precessiontoggle(); break;
        case 6: _t->showlightcurvetoggle(); break;
        case 7: _t->showinclinationtoggle(); break;
        case 8: _t->showascendingnodetoggle(); break;
        case 9: _t->showstellarobliquitytoggle(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData transitfitter::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject transitfitter::staticMetaObject = {
    { &Q3MainWindow::staticMetaObject, qt_meta_stringdata_transitfitter,
      qt_meta_data_transitfitter, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &transitfitter::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *transitfitter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *transitfitter::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_transitfitter))
        return static_cast<void*>(const_cast< transitfitter*>(this));
    return Q3MainWindow::qt_metacast(_clname);
}

int transitfitter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3MainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
