#ifndef transitfitter_h 
#define transitfitter_h 1
#define QT3_SUPPORT

#include <q3mainwindow.h>
#include <q3popupmenu.h>
#include <qmenubar.h>

class transitfitter;

#include <fitter.h>
#include "../../Jcrap.h"

class transitfitter : public Q3MainWindow
{
	Q_OBJECT

public:
	transitfitter(QWidget *parent=0, const char *name=0, const char *startfile=0);
	void loadfile(string);
	void setstartdir(string);
	
	void precession(bool);
	bool precession();
	void showlightcurve(bool);
	bool showlightcurve();
	void showinclination(bool);
	bool showinclination();
	void showascendingnode(bool);
	bool showascendingnode();
	void showstellarobliquity(bool);
	bool showstellarobliquity();
	
private slots:
	void loadfile();
	void addfile();
	void savefile();
	void saveimage();
	void quit();
	
public slots:
	void precessiontoggle();
	void showlightcurvetoggle();
	void showinclinationtoggle();
	void showascendingnodetoggle();
	void showstellarobliquitytoggle();

private:
	fitter Fitter;
	Q3PopupMenu FILEmenu;
	Q3PopupMenu DATAmenu;
	Q3PopupMenu MODIFYmenu;
	Q3PopupMenu ADDmenu;
	Q3PopupMenu SETTINGSmenu;
	Q3PopupMenu ANALYSISmenu;
	Q3PopupMenu GRAPHmenu;
	Q3PopupMenu OUTPUTmenu;
	
	string startdir;
};

#endif
