#include "ctrlpanel.h"
#include <iostream>

ctrlpanel::ctrlpanel(QWidget *parent, const char *name) :
	Q3VBox(parent, name),
	calcstylebuttons(2, Qt::Horizontal, "Calc Style", this),
	cartesianbutton("Cartesian", &calcstylebuttons),
	polar1button("Polar", &calcstylebuttons),
	polar2button("Full Polar", &calcstylebuttons),
	analyticbutton("Analytic", &calcstylebuttons),
	polarscatteringbutton("Scattering", &calcstylebuttons),
	
	Wavelengths(1, Qt::Horizontal, "Wavelength Menu", this),
	Keplerbandpassbutton("Kepler Bandpass", &Wavelengths),
	Singlewavelength(&Wavelengths),
	Singlewavelengthbutton("Single Wavelength (microns)", &Singlewavelength),
	Singlewavelengthbox("0.5", &Singlewavelength),
	
	visualizebuttons(3, Qt::Horizontal, "Visualization Options", this),
	foldvisual("Fold", &visualizebuttons),
	cropvisual("Crop", &visualizebuttons),
	residualvisual("Residual", &visualizebuttons),
	
	binandcropamount(this),
	cropamount(&binandcropamount),
	cropamountlabel("To Crop:", &cropamount),
	cropamountbox("0.2", &cropamount),
	binamount(&binandcropamount),
	binamountlabel("To Bin(s):", &binamount),
	binamountbox("60", &binamount),
	
	
	
	Integrationtime("Integration Time(min)",this),
	
	accs(this),
	accuracy("Accuracy", &accs),
	guesspointslabel("Guess points:", &accs),
	guesspointsbox("0", &accs),
	
	coordinates(this),
	xycoordinates(&coordinates),
	xvaluelabel("Time (s)", &xycoordinates),
	xvaluebox(" ", &xycoordinates),
	yvaluelabel("Stellar Flux", &xycoordinates),
	yvaluebox(" ", &xycoordinates),
	
	exportbuttons(3, Qt::Horizontal, "Export Actions", this),
	exportdata("Export Data", &exportbuttons),
	exportfit("Export Fit", &exportbuttons),
	exportresiduals("Export Residuals", &exportbuttons)	
	
{
	setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Expanding);
	
	Integrationtime.rerange(0,60);
	Integrationtime.value(0.);
	
	accuracy.rerange(0,20);
	accuracy.value(6);
	
	calcstylebuttons.setButton(3);
	
	Wavelengths.insert(&Keplerbandpassbutton);
	Wavelengths.insert(&Singlewavelengthbutton);
	Wavelengths.setButton(1);
	
	connect(&foldvisual, SIGNAL(clicked()), this, SIGNAL(foldVisual()));
	connect(&cropvisual, SIGNAL(clicked()), this, SIGNAL(cropVisual()));
	connect(&residualvisual, SIGNAL(clicked()), this, SIGNAL(residualVisual())); 
	
	connect(&exportdata, SIGNAL(clicked()), this, SIGNAL(exportData()));
	connect(&exportfit, SIGNAL(clicked()), this, SIGNAL(exportFit()));
	connect(&exportresiduals, SIGNAL(clicked()), this, SIGNAL(exportResiduals()));
	
}

QSize ctrlpanel::sizeHint() const
{
	return QSize(350,500);
}

int ctrlpanel::calcmethod()
{
	return calcstylebuttons.selectedId();
} 

float ctrlpanel::accuracy_ln() 
{
	return float(accuracy.value()*log(10));
}

double ctrlpanel::timeintegration()
{
	return double(Integrationtime.value());
}

float ctrlpanel::cropamountvariable()
{
	float ca(str2float(cropamountbox.text().toStdString()));
	return ca;
}

float ctrlpanel::binamountvariable()
{
	float bin(str2float(binamountbox.text().toStdString()));
	return bin;
}

void ctrlpanel::inputtime(double t)
{
	string time;
	
	
	time = double2fstr(t, 9);
	cout << "Setting time " << t << " = " << time << "\n";
	xvaluebox.setText(QString::fromStdString(time));

}

void ctrlpanel::inputflux(double f)
{
	string flux(double2fstr(f, 11));
	yvaluebox.setText(QString::fromStdString(flux));
}

double ctrlpanel::wavelength()
{
	double answer(-1.);
	if (Wavelengths.selectedId() == 0) {
		cout << "wavelength(): Using Kepler Bandpass.\n";
	}
	if (Wavelengths.selectedId() == 1) {
		cout << "wavelength(): Single wavelength returned, l=" << str2double(Singlewavelengthbox.text().toStdString()) << "\n";
		answer = str2double(Singlewavelengthbox.text().toStdString());
	}
	return answer;
}

unsigned long ctrlpanel::guesspoints()
{
	return str2ulong(guesspointsbox.text().toStdString());
}
