/****************************************************************************
** Meta object code from reading C++ file 'fitter.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "fitter.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fitter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_fitter[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      39,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       8,    7,    7,    7, 0x0a,
      20,    7,    7,    7, 0x0a,
      31,    7,    7,    7, 0x0a,
      43,    7,    7,    7, 0x0a,
      54,    7,    7,    7, 0x0a,
      65,    7,    7,    7, 0x0a,
      78,    7,    7,    7, 0x0a,
      91,    7,    7,    7, 0x0a,
     107,    7,    7,    7, 0x0a,
     119,    7,    7,    7, 0x0a,
     129,    7,    7,    7, 0x0a,
     143,    7,    7,    7, 0x0a,
     163,    7,    7,    7, 0x0a,
     186,    7,    7,    7, 0x0a,
     203,    7,    7,    7, 0x0a,
     224,    7,    7,    7, 0x0a,
     249,    7,    7,    7, 0x0a,
     275,    7,    7,    7, 0x0a,
     312,    7,    7,    7, 0x0a,
     332,    7,    7,    7, 0x0a,
     343,    7,    7,    7, 0x0a,
     354,    7,    7,    7, 0x0a,
     368,    7,    7,    7, 0x0a,
     382,    7,    7,    7, 0x0a,
     393,    7,    7,    7, 0x0a,
     406,    7,    7,    7, 0x0a,
     419,    7,    7,    7, 0x0a,
     436,    7,    7,    7, 0x0a,
     449,    7,    7,    7, 0x0a,
     461,    7,    7,    7, 0x0a,
     479,    7,    7,    7, 0x0a,
     517,    7,    7,    7, 0x0a,
     531,    7,    7,    7, 0x0a,
     548,    7,    7,    7, 0x0a,
     569,    7,    7,    7, 0x0a,
     588,    7,    7,    7, 0x0a,
     611,    7,    7,    7, 0x0a,
     621,    7,    7,    7, 0x0a,
     631,    7,    7,    7, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_fitter[] = {
    "fitter\0\0plotguess()\0dothefit()\0"
    "doMCMCfit()\0folddata()\0cropdata()\0"
    "splicedata()\0filterdata()\0normalizedata()\0"
    "cleandata()\0bindata()\0baselinesub()\0"
    "baselinesub_go(int)\0baselinesub_subtract()\0"
    "oscillationsub()\0oscillationsub_fit()\0"
    "oscillationperiodogram()\0"
    "oscillationsub_subtract()\0"
    "oscillation_calculatefreqstability()\0"
    "orbitchange(double)\0orbitadd()\0"
    "orbitsub()\0transitnext()\0transitprev()\0"
    "timemult()\0foldvisual()\0cropvisual()\0"
    "residualvisual()\0exportdata()\0exportfit()\0"
    "exportresiduals()\0"
    "coordinatevalues(pair<double,double>)\0"
    "periodogram()\0graphobliquity()\0"
    "graphascendingnode()\0graphinclination()\0"
    "outputprecessioninfo()\0newmoon()\0"
    "newring()\0newplanet()\0"
};

void fitter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        fitter *_t = static_cast<fitter *>(_o);
        switch (_id) {
        case 0: _t->plotguess(); break;
        case 1: _t->dothefit(); break;
        case 2: _t->doMCMCfit(); break;
        case 3: _t->folddata(); break;
        case 4: _t->cropdata(); break;
        case 5: _t->splicedata(); break;
        case 6: _t->filterdata(); break;
        case 7: _t->normalizedata(); break;
        case 8: _t->cleandata(); break;
        case 9: _t->bindata(); break;
        case 10: _t->baselinesub(); break;
        case 11: _t->baselinesub_go((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->baselinesub_subtract(); break;
        case 13: _t->oscillationsub(); break;
        case 14: _t->oscillationsub_fit(); break;
        case 15: _t->oscillationperiodogram(); break;
        case 16: _t->oscillationsub_subtract(); break;
        case 17: _t->oscillation_calculatefreqstability(); break;
        case 18: _t->orbitchange((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 19: _t->orbitadd(); break;
        case 20: _t->orbitsub(); break;
        case 21: _t->transitnext(); break;
        case 22: _t->transitprev(); break;
        case 23: _t->timemult(); break;
        case 24: _t->foldvisual(); break;
        case 25: _t->cropvisual(); break;
        case 26: _t->residualvisual(); break;
        case 27: _t->exportdata(); break;
        case 28: _t->exportfit(); break;
        case 29: _t->exportresiduals(); break;
        case 30: _t->coordinatevalues((*reinterpret_cast< pair<double,double>(*)>(_a[1]))); break;
        case 31: _t->periodogram(); break;
        case 32: _t->graphobliquity(); break;
        case 33: _t->graphascendingnode(); break;
        case 34: _t->graphinclination(); break;
        case 35: _t->outputprecessioninfo(); break;
        case 36: _t->newmoon(); break;
        case 37: _t->newring(); break;
        case 38: _t->newplanet(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData fitter::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject fitter::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_fitter,
      qt_meta_data_fitter, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &fitter::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *fitter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *fitter::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_fitter))
        return static_cast<void*>(const_cast< fitter*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int fitter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 39)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 39;
    }
    return _id;
}
static const uint qt_meta_data_MCMCwindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x0a,
      22,   11,   11,   11, 0x0a,
      33,   11,   11,   11, 0x0a,
      53,   11,   11,   11, 0x0a,
      62,   11,   11,   11, 0x0a,
      73,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MCMCwindow[] = {
    "MCMCwindow\0\0runMCMC()\0MCMCstep()\0"
    "MCMCdisplayupdate()\0sizeup()\0sizedown()\0"
    "exportfit()\0"
};

void MCMCwindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MCMCwindow *_t = static_cast<MCMCwindow *>(_o);
        switch (_id) {
        case 0: _t->runMCMC(); break;
        case 1: _t->MCMCstep(); break;
        case 2: _t->MCMCdisplayupdate(); break;
        case 3: _t->sizeup(); break;
        case 4: _t->sizedown(); break;
        case 5: _t->exportfit(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData MCMCwindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MCMCwindow::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_MCMCwindow,
      qt_meta_data_MCMCwindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MCMCwindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MCMCwindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MCMCwindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MCMCwindow))
        return static_cast<void*>(const_cast< MCMCwindow*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int MCMCwindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}
static const uint qt_meta_data_baselinedialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      16,   15,   15,   15, 0x05,
      28,   15,   15,   15, 0x05,
      36,   15,   15,   15, 0x05,

 // slots: signature, parameters, type, tag, flags
      47,   15,   15,   15, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_baselinedialog[] = {
    "baselinedialog\0\0cancelled()\0go(int)\0"
    "subtract()\0go()\0"
};

void baselinedialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        baselinedialog *_t = static_cast<baselinedialog *>(_o);
        switch (_id) {
        case 0: _t->cancelled(); break;
        case 1: _t->go((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->subtract(); break;
        case 3: _t->go(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData baselinedialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject baselinedialog::staticMetaObject = {
    { &Q3HBox::staticMetaObject, qt_meta_stringdata_baselinedialog,
      qt_meta_data_baselinedialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &baselinedialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *baselinedialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *baselinedialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_baselinedialog))
        return static_cast<void*>(const_cast< baselinedialog*>(this));
    return Q3HBox::qt_metacast(_clname);
}

int baselinedialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3HBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void baselinedialog::cancelled()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void baselinedialog::go(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void baselinedialog::subtract()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}
static const uint qt_meta_data_oscillationdialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      19,   18,   18,   18, 0x05,
      31,   18,   18,   18, 0x05,
      45,   18,   18,   18, 0x05,
      56,   18,   18,   18, 0x05,
      78,   18,   18,   18, 0x05,

 // slots: signature, parameters, type, tag, flags
     103,   18,   18,   18, 0x0a,
     108,   18,   18,   18, 0x0a,
     122,   18,   18,   18, 0x0a,
     140,   18,   18,   18, 0x0a,
     156,   18,   18,   18, 0x0a,
     174,   18,   18,   18, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_oscillationdialog[] = {
    "oscillationdialog\0\0cancelled()\0"
    "fit_clicked()\0subtract()\0generateperiodogram()\0"
    "calculatefreqstability()\0go()\0"
    "freqchanged()\0loadperiodogram()\0"
    "populatefreqs()\0loadfrequencies()\0"
    "savefrequencies()\0"
};

void oscillationdialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        oscillationdialog *_t = static_cast<oscillationdialog *>(_o);
        switch (_id) {
        case 0: _t->cancelled(); break;
        case 1: _t->fit_clicked(); break;
        case 2: _t->subtract(); break;
        case 3: _t->generateperiodogram(); break;
        case 4: _t->calculatefreqstability(); break;
        case 5: _t->go(); break;
        case 6: _t->freqchanged(); break;
        case 7: _t->loadperiodogram(); break;
        case 8: _t->populatefreqs(); break;
        case 9: _t->loadfrequencies(); break;
        case 10: _t->savefrequencies(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData oscillationdialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject oscillationdialog::staticMetaObject = {
    { &Q3HBox::staticMetaObject, qt_meta_stringdata_oscillationdialog,
      qt_meta_data_oscillationdialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &oscillationdialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *oscillationdialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *oscillationdialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_oscillationdialog))
        return static_cast<void*>(const_cast< oscillationdialog*>(this));
    return Q3HBox::qt_metacast(_clname);
}

int oscillationdialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3HBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void oscillationdialog::cancelled()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void oscillationdialog::fit_clicked()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void oscillationdialog::subtract()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void oscillationdialog::generateperiodogram()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void oscillationdialog::calculatefreqstability()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}
QT_END_MOC_NAMESPACE
