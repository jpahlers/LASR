#ifndef ctrlpanel_h
#define ctrlpanel_h

#include <q3vbox.h>
#include <qpushbutton.h>
#include <q3buttongroup.h>
#include <qradiobutton.h>
#include <qcheckbox.h>
//Added by qt3to4:
#include <QLabel>

#include "../../slidedial.h"  // for slidedial definition

class ctrlpanel : public Q3VBox
{
	Q_OBJECT
			
public:
	ctrlpanel(QWidget *parent=0, const char *name=0);
	QSize sizeHint() const;
	
	int calcmethod();
	float accuracy_ln();
	unsigned long guesspoints();
	float cropamountvariable();
	float binamountvariable();
	double timeintegration();
	void inputtime(double);
	void inputflux(double);
	void setcrop(double c) {setcrop(double2str(c));}
	void setcrop(string c) {cropamountbox.clear();
			cropamountbox.insert(QString::fromStdString(c));}
	double wavelength();
	
signals:
	void foldData();
	void cropData();
	void filterData();
	void normalizeData();
	void cleanData();
	void foldVisual();
	void cropVisual();
	void residualVisual();
	void exportData();
	void exportFit();
	void exportResiduals();
	
private:
	Q3ButtonGroup calcstylebuttons;
	QRadioButton cartesianbutton;
	QRadioButton polar1button;
	QRadioButton polar2button;
	QRadioButton analyticbutton;
	QRadioButton polarscatteringbutton;
	
	Q3ButtonGroup	Wavelengths;
	QRadioButton	Keplerbandpassbutton;
	Q3HBox		Singlewavelength;
	QRadioButton	Singlewavelengthbutton;
	QLineEdit	Singlewavelengthbox;
	
	Q3ButtonGroup	visualizebuttons;
	QPushButton	foldvisual;
	QPushButton	cropvisual;
	QPushButton	residualvisual;
	
	
	Q3HBox		binandcropamount;
	Q3HBox		cropamount;
	QLabel		cropamountlabel;
	QLineEdit	cropamountbox;
	Q3HBox		binamount;
	QLabel		binamountlabel;
	QLineEdit	binamountbox;
	
	slidedial Integrationtime;
	
	Q3HBox accs;
	slidedial accuracy;
	QLabel guesspointslabel;
	QLineEdit guesspointsbox;
	
	Q3VBox		coordinates;
	Q3HBox		xycoordinates;
	QLabel		xvaluelabel;
	QLineEdit	xvaluebox;
	QLabel		yvaluelabel;
	QLineEdit	yvaluebox;
	
	Q3ButtonGroup	exportbuttons;
	QPushButton		exportdata;
	QPushButton		exportfit;
	QPushButton		exportresiduals;
};


#endif
