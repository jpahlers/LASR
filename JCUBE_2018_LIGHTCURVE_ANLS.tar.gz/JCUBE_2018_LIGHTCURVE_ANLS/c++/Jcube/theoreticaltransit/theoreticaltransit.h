#include <map>
#include <list>
#include <strstream>
#include "../Jfunction.h"
#include "../../../nr/nr.h"
//#include "diff.phasefunc.h"

#ifndef THEORETICALTRANSIT
#define THEORETICALTRANSIT 1

namespace transit 
{
	class  star;
	class  planet;
	class  ringsystem;
	class  ring;
	class  Transit;
	class  arcbright;
	class  planetangler;
	class  planetdeviator;
	class  planetringchunker;
	enum   darkeningmodel {LINEAR, QUADRATIC, SQUARE_ROOT, LOG, CHARBONNEAU, CLARET};
	static const double G  = 6.673e-11;
	static const double pi = 3.1415926535897932384;
	
	enum   calctype {CARTESIAN, POLAR_INTEGRAL, POLAR_INTEGRAL2,
						  ANALYTIC_APPROXIMATION, POLAR2WITHSCATTERING};
	enum   diffcalctype {NODIFFRACTION, UNIDIRECTIONAL, DISKINTEGRATED, DISKINTERPOLATED};
	enum   oblatecalctype {POINTCORE, DARWINRADAU};
	
	calctype int2calctype(int);
}

class phasefunc : public Jcrap::function<double>
{	

public:
	phasefunc(value _a=value(1.0, "cm"), value _lambda=value(0.5, "um")) :
			a(_a), lambda(_lambda)
	{
		x = 2.*3.1415926535*(double)(a.convert("m")/lambda.convert("m"));
//		cout << "x=" << x << "\n";
	}
	
	double the_function(double phi) {
		// this class/function impliments French and Nicholson eq(8)
		double answer;
		if (phi != 0.)
			answer = Jbessj1(x*sin(phi))/sin(phi);
		else
			answer = Jbessj1(x*sin(1e-8))/sin(1e-8);
		return answer*answer/transit::pi;  // changed 7/15/2003 so as to integrate to 1
		// this should now integrate to 4pi over the whole 4pi forwardscattering solid angle space
	}
	
	value a, lambda, x;
};

class azimuthalsegment
{
	public:
		azimuthalsegment(double phi1=0., double phi0=0., double opdepth=-1.)
			: end(phi1), start(phi0), tau(opdepth) 
		{
			if (tau < 0.) tau = 1.e15;
			if (end < start) {
				double temp(start);
				start=end;
				end=temp;
			}
		}
			
	public:
		double end, start, tau;
};

class transit::star
{
	public:
			star(value r,value m,darkeningmodel=QUADRATIC,double=-1.,
			     double=0.,double=0.,double=0.,double=0.,calctype=CARTESIAN,
				  double=0.,double=0.,value P=value(0., "s"), bool=true);
			star();
			
			calctype ctype;
			
			double limbdark(double);
			double starbright_xy(double, double);
			
			void generateimage();
			
			double mass()   { return _mass; }
			value mass_value();
			void mass(value);
			double radius() { return _radius; }
			value radius_value();
			void radius(double);
			double oblateradius(double);
			void rotationperiod(value);
			double rotationperiod() {return _rotationperiod;}
			value omega_value();
			double radius_in_pixels();
			bool precalculate() {return _precalculate;}
			void precalculate(bool b) {_precalculate=b;}
			
			void f(double in_f) { _f=in_f; if(_precalculate)normalize(); } // oblateness setter
			double f() { return _f; }       // oblateness getter
			double MOIcoefficient();
			void MOIcoefficient(double m);
			double J2() { return MOIcoefficient()*f(); }  // using point-core assumption
			double f_eff();  // use for stellar obliquity reasons		(in star.c++)
			double f_inferred(); // calculate f from other parameters using _oblatecalctype
			void stellarobliquity(double d) {stellarobliquity0(d);}
			void stellarobliquity0(double);
			double stellarobliquity();
			void skyazimuth(double);
			double skyazimuth();
			void wavelength(double);
			double wavelength() { return _wavelength; }
			void Beta(double b) { _Beta=b; if(_precalculate)normalize(); }
			double Beta() {return _Beta;}
			void Tpole(double t) { cout << "in Tpole setter.  Old Tpole:  " << _Tpole << "; ";;
			cout << "new Tpole:  " << t << "\n"; _Tpole=t; if(_precalculate)normalize(); }
			double Tpole() {return _Tpole;}
			static bool temperaturedebug;
			
			darkeningmodel darkenmodel() { return limbdarktype; }
			vector<double> u() { 
				vector<double> answer(4);
				answer[0] = u1;
				answer[1] = u2;
				answer[2] = u3;
				answer[3] = u4;
				return answer;
			}
			double c1() {return u1;}
			double c2() {return u2;}
			double c3() {return u3;}
			double c4() {return u4;}
			void set_darkening_coefficient(double,int);
			cube image();
			void calibration(double);
			double calibration() {return _calibration;}
			double sum();
			
			double res();
			void res(double);
	
			void normalize();
			double zfromxy(double, double);
		
			friend class transit::Transit;
			
			transit::Transit* parenttransit();
			void parenttransit(transit::Transit* ttt) {_parenttransit = ttt;}
			
	private:
			transit::Transit *_parenttransit;	// pointer to the parent Transit object that contains this star
	
			double u1,u2,u3,u4;
			double _radius;   // equatorial radius, in meters
			double _mass;		// in kg
			double _rotationperiod;
			double resolution;
			double _radius_in_pixels;
			darkeningmodel limbdarktype;
			bool _precalculate;
			
			double _f;        // oblateness (flattening)
			oblatecalctype _oblatecalctype;  // how to infer oblateness
			double _stellarobliquity0; // angle between stellar rot pole & plane of sky, in degrees -- at t0
			double _stellarobliquity; // calculated, precessed stellar obliquity
			double _skyazimuth0;	// actual orientation of the stellar north pole wrt sky north in deg counterclock -- at t0
			double _skyazimuth;  // calculated, precessed sky azimuth -- this ONLY matters for transit pictures
			double _wavelength;   // wavelength at which the star is being observed -- or 0.0 for bolometric flux
			double _Beta;     // gravity-darkening coefficient.  0.25 for von Zeipel
			double _Tpole;    // pole temperature
			double _MOIcoefficient;
			
			cube   _image;
			double _sum;
			double _calibration;
			
};

class transit::ring  // code is inside rings.c++
{
	public:
			ring(value, value, value, double);
			
			double transmittance(double, double, double, double, double);
			double scattering(double, double, double, double, double, Transit&);
			double ringedge_xy(double, double, double, double, int=1);
	
			void inneredge(value);
			double inneredge();
			void outeredge(value);
			double outeredge();
			void tau(double);
			double tau();
			

			phasefunc phasef;
			cube scatterprofile;
			
			diffcalctype diffraction();
			void diffraction(diffcalctype, star* =NULL, planet* =NULL);
			
	private:
			diffcalctype calculatediffraction;
			double _inneredge;		// ring start (in meters)
			double _outeredge;		// ring end (in meters)
			double _tau;				// normal ring optical depth
//			double _particlesize;		// particle radius (in meters)
};

class transit::ringsystem : public list<ring>
{
	public:
			
			double transmittance(double, double, double, double, double);
			double scattering(double, double, double, double, double, Transit&);
			
			bool diffractioncalculate();
			static ringsystem saturn(star&, planet&);
			
			operator bool();
			
};



class transit::planet
{
	public:
			planet(value,value,double,double=0.,double=0.,double=-1.,double=0.,double=0.);
			planet(value,value,double,cube,double=0.,double=-1.,double=0.,double=0.);
			planet(value mass,value radius, value semimajoraxis);
			planet();
	
			
			double f(double);
			double r(double);
			double x(double);
			double y(double);
			void orbitrecalculate(double);
			
			
			string name() { return planetname; }
			void name(string s) { planetname=s; }
			void inclination(double d) {inclination0(d);}
			void inclination0(double);
			void inclination(angle a) {inclination0(a.radians());}
			double inclination();
			double semimajoraxis();
			value semimajoraxis_value();
			void semimajoraxis(value);
			value period();
			void period(value);
			void oblateness(double);
			double oblateness();
			void obliquity(double);	// this ends up being the projected obliquity
			double obliquity();
			void realobliquity(double);
			double realobliquity();
			void poleangle(double);
			double poleangle();
			double Requatorial();
			value Requatorial_value();
			double Rpolar();
			value Rpolar_value();
			double Rmaximum();
			double Rea() { return radius; }
			void Rea(double);
			value Radius() { return value(Rea(), "m"); }
			double mass() { return Mass; }
			void mass(value m);
			value Mass_value()   { return value(mass(), "kg"); }
			double density();
			void density(value);  // this assumes constant radius, and sets the MASS for the density
			void density(double);
			value density_value();
			void ascendingnode(double d) {ascendingnode0(d);}
			void ascendingnode0(double);
			double ascendingnode();
			void longitudeofpericenter(double);
			double longitudeofpericenter();
			void argumentofpericenter(double);
			double argumentofpericenter();
			void eccentricity(double);
			double eccentricity() {return e;}
			void epoch(double);
			double epoch();
			void parentmass(double);
			double parentmass();
			value parentmass_value() {return value(parentmass(), "kg");}
			double n();
			value n_value();
			double timefromM(double);
			double Mfromtime(double);
				
			ringsystem& rings();
			void rings(ringsystem);
			angle ringopeningangle();
			
			vector<planet>& moons() {return Moons;}
			void addmoon(planet& p);
			
			bool insideplanet(double, double, double); 	// now deprecated, in favor of transmittance() and scattering()
			bool insideplanet(double, double, Transit&); 	// now deprecated, in favor of transmittance() and scattering()
//			double transmittance(double, double, double);	// given x,y pixel position relative to planet center (and scale), return a number between 0 and 1 representing the fraction of starlight that gets through
			double transmittance(double, double, Transit&);	// given x,y absolute position in meters, return a number between 0 and 1 representing the fraction of starlight that gets through
			double scattering(double,double,double,Transit&);// given transit parameters (and true anomaly), determine the amount of light 
			double planetedge(double, double,double, double);
			double planetedge_xy(double, double,double, double);
			double xlocationCOM(double);	// planet center-of-mass posn in meters relative to primary
			double ylocationCOM(double);  // planet center-of-mass posn in meters relative to primary
			double zlocationCOM(double);  // planet center-of-mass posn in meters relative to primary
			double rlocationCOM(double);  // in meters relative to primary, projected into the xy plane
			double thetalocationCOM(double);
			double xlocation(double);  // planet posn in meters -- accounts for satellites
			double ylocation(double);  // planet posn in meters -- accounts for satellites
			double zlocation(double);  // planet posn in meters -- accounts for satellites
			double rlocation(double);  // in meters -- accounts for satellites
			double thetalocation(double);  // accounts for satellites

			
			friend class transit::Transit;
			
			transit::Transit* parenttransit();
			void parenttransit(transit::Transit* ttt) {_parenttransit = ttt;}
			
	private:
			// planet info
			string planetname;// maybe this will help with debugs.
			double radius;		//
			double Mass;		// store only if relevant
			double Parentmass;// inelegant, I know.
			double o;			// oblateness (fixed to 0 very temporarily)
			double Re;			// Equatorial radius
			double Rp;			// polar radius
			double obl;			// projected obliquity
			double q;			// real obliquity
			double axisang;	// azimuthal rotational axis angle, clockwise from line of sight.
			ringsystem Rings;
			vector<planet> Moons;
			cube shape;
			
			
			// orbit info -- for subplanets (moons) coordinate system is relative to
			// primary &/or primary's orbit pole
			double P;			// orbital period, days
			double a;			// storage for semimajor axis, to speed computation
			double e;			// orbital eccentricity 
			double i0;			// orbital inclination     radians separating
			                  // orbit pole from line-of-sight for planets,
									// radians separating orbit pole from planet orbit
									// pole for subplanets (moons) -- at time t0
			double i;			// calculated, precessed inclination
			double asc0;		// Omega -- longitude of the ascending node, at t0
			double asc;			// calculated, precessed ascending node
			double argperi;   // lower-case omega -- argument of pericenter, at t0
									// (but eccentricity precession not yet implimented)
			double Epoch;     // time of pericenter passage
			
			// bookkeeping info:  store previous M so that you know whether or not
			// you have to recalculate E
			double lastM, lastE;
			
			transit::Transit *_parenttransit;	// pointer to the parent Transit object that contains this planet
};



class transit::Transit : public Jcrap::function<double>
{
	public:
			Transit(Transit&);
			Transit(const transit::star&, const transit::planet&, double);
			Transit(const transit::star&, const vector<transit::planet>&, double);
			Transit(vector<double>, int, calctype=transit::POLAR_INTEGRAL);
			Transit& operator=(Transit&);
			
			double timestep;	// in seconds

			cube planetimage();
			cube transitimage();
			cube lightcurve(double=-1,double=-1,double=-1,double=0.,int=1);
			cube lightcurve(const cube&, double=0.);
			double lightflux(double, double=0.);
			double the_function(double);
			cube movie(double=-1,double=-1,double=-1, double=0., bool=false);
			cube multiexposure(double=-1,double=-1,double=-1);
			
			double time();
			void time(double);
//			double toffset();
//			void toffset(double);
			double M();
			planet& the_planet(int i=-1) { return Planet(i); }
			int defaultplanet() { return _defaultplanet;}
			void defaultplanet(int i) { _defaultplanet=i;}
			void setplanet(planet);
			void starradius(double);
			cube planetimage_generate();
			cube scatterimage_generate();
			double planetcover(double);
			double platescale();
			vector<azimuthalsegment> planetangle(double,double);	
			double analcover();	
			double analcover(double, double, double=0.);	
			
			star&   Star()   {return _star;  }	
			planet& Planet(int i=-1);
			vector<planet>& Planets() {return _planets;}
			void Planets(const vector<planet>&p) {_planets=p;}
			
			
			void operator++(int=1);
			
			vector<double> n;
			
			void precess();
			void needtopreprecess();
			void needtoprecess();
			void precession(bool);
			bool precession() {return _precession;}
			angle Psi() {precess(); return _Psi;}
			angle Psi_p() {precess(); return _Psi_p;}
			angle Psi_s() {precess(); return _Psi_s;}
			value Omegadot_p() {precess(); return _Omegadot_p;}
			value Omegadot() {precess(); return _Omegadot;}
			value precessionperiod_planetonly();
			value precessionperiod();
			vector<double> Ltotal() {return L_total_sky;}
			vector<double> Lpo() {return L_po_sky;}
			
	private:
			star _star;
			vector<planet> _planets;
			int _defaultplanet;
			cube _planetimage;
			double _time;
			
			bool _precession;
			unsigned int _needtopreprecess;
			unsigned int _needtoprecess;
			angle _Psi, _Psi_p, _Psi_s;
			value _Omegadot_p, _Omegadot;
			vector<double> L_total_sky;
			vector<double> L_po_sky;
			
			void internalcopy(Transit&);
			void internalcopy(const transit::star&, const vector<transit::planet>&, const double,
					const unsigned int=1, const unsigned int=1, const bool=0, const int=0);
};

class transit::arcbright : public Jcrap::function<double>
{
	public:
		arcbright(transit::Transit *a, double b) : t(a) {radius = b*t->Star().radius();}
	
		double the_function(double phi) {
			double answer(0.0);
			double x, y, yprime;  // x y looking for
			x      =  radius * cos(phi) / t->Star().radius_in_pixels();  // convert from radius=0.5 space to realspace
			yprime =  radius * sin(phi) / t->Star().radius_in_pixels();
			y      = yprime * (1.-t->Star().f_eff());  // for oblate stars//			cout << "Calculating for x=" << radius*cos(phi) << ", y=" << radius*sin(phi) << "\n";

			answer = t->Star().starbright_xy(x, -y);
			return answer;
		}
	
	transit::Transit *t;
	double radius;
};


class transit::planetringchunker : public Jcrap::function<double>
// the azimuthal integrator function -- has nothing to do with planetary rings
{
	public:
			planetringchunker(double a, transit::Transit *b, double c) : 
				M(a), r(c), t(b), starptr(&(b->Star())) {}
			planetringchunker(double a, transit::star *in_s, double c) : 
				M(a), r(c), t(0), starptr(in_s) {}

			double the_function(double theta) {
				double answer;
				double x, y, yprime, rx(0.), ry(0.);  // x y looking for, planet x y, relative x y
				x      =  r * cos(theta) * starptr->radius() / starptr->radius_in_pixels();  // convert from radius=0.5 space to realspace
				yprime =  r * sin(theta) * starptr->radius() / starptr->radius_in_pixels();
				y      = yprime * (1.-starptr->f_eff());  // for oblate stars
				
				if (t == 0) {
				// case 1:  integrating star flux with no planet
					answer = r*(starptr->starbright_xy(x,y));
			//		cout << "Starintegration case -- r=" << r << " answer=" << answer << "\n";
			//		cout << "x=" << x << ", y=" << y << " yprime=" << yprime << "\n";
				} else {
				// case 2:  integrating intercepted planet flux
				
					double transmittance(1.);
					if (r < starptr->radius_in_pixels()) { 
						transmittance = t->Planet().transmittance(x, y, *t);
	//					cout << "time = " << t->time() << "; calling transmittance with x=" << x << ", y=" << y << ".  transmittance=" << transmittance << "\n";
	//					cout << "Star radius in pixels = " << t->Star().radius_in_pixels() << "\n";
	//					cout << "Transit platescale = " << t->platescale();
					}
				/* note that this is a bit funky and confusing unless you keep
				   in mind that I've chosen to have this function calculate the
					amount of flux to subtract from the total because its absorbed
					by the planet or rings.  Thus, if nothing is absorbed, this
					function returns 0. while if the planet is in the way it
					returns starflux*r.  Returns negative for scattered (?)*/
				
					answer = (1.0-transmittance)*r*(starptr->starbright_xy(x,y));
					if (transmittance!=0.0 && t->Planet().rings().size()!=0) {
						if (r < starptr->radius_in_pixels())  // as long as the ring isn't covered by planet
							answer -= t->Planet().scattering(rx, ry, 1.0, *t) * r;
						else answer = t->Planet().scattering(rx, ry, 1.0, *t) * r;
					}
					if (answer < 0) {
						answer = 0.; // otherwise the integrator gets upset
//						cout << "fudge\n";
					}
//					cout << "in planetringchunker, answer = " << answer << "\n";
				}
				
				return answer;
			}
			
			double M, r;
			transit::Transit *t;
			transit::star *starptr;
};



class transit::planetangler : public Jcrap::function<double>
{
	public:
			planetangler(double a, transit::Transit *b, double c, double d) : 
				f(a), intmin(c), intmax(d), t(b) {}
			
			double the_function(double r) {
				double answer(0.);
				if (r > t->Star().radius_in_pixels()) return answer;
				if (r < intmax && r > intmin) {
					vector<azimuthalsegment> cover_segments;
					cover_segments = t->planetangle(f, r);
//					cout << "cover_segments.size() = " << cover_segments.size() << "\n";
					
//					transit::planetringchunker chunk(f, &(t->Star()), r);
					transit::arcbright Arcbright(t, r);

					if (t->Star().rotationperiod()) {  // fast-rotating case
//						Arcbright.plot(-pi, pi, 100).graph(); char c; cin >> c;
						for (unsigned int i(0);i<cover_segments.size();i++) {
//							double blockedflux(0.);
//							cout << "r = " << r << ", integrating from " << cover_segments.at(i).second;
//							cout << " to " << cover_segments.at(i).first << "\n";
//							answer += chunk.integrate_smooth(cover_segments.at(i).second,
//								cover_segments.at(i).first, 1.e-2/t->Star().res(), 3);
							answer += Arcbright.integrate_smooth(cover_segments.at(i).start,
								cover_segments.at(i).end, 1.e-2/t->Star().res(), 3) * r * (-expm1(-cover_segments.at(i).tau));
/*							cube thisgraph(Arcbright.plot(cover_segments.at(i).start,
								cover_segments.at(i).end, 100));
							thisgraph.keyword("title", float2str(r, 19));
							thisgraph.graph(); char c; cin >> c;*/
						}
						
					} else {  // spherical, uniform stellar temperature situation
						
//						double mu(cos(asin(r/(double)t->Star().radius_in_pixels())));
						for (unsigned int i(0);i<cover_segments.size();i++) {
//  this old way seemed to work.  'fixing' it in order to match how fast-rotating case works for debug of that case
//							answer += fabsl(cover_segments.at(i).first-cover_segments.at(i).second)
//											*r*1.*t->Star().limbdark(mu);  // use starbright instead?
//							answer += fabsl(cover_segments.at(i).first-cover_segments.at(i).second)
//											*chunk.the_function(0.);
							answer += fabsl(cover_segments.at(i).end-cover_segments.at(i).start)
											*Arcbright.the_function(0.) * r * -expm1(-cover_segments.at(i).tau);
						}
					}
				} else
					answer = 0.0;
//				cout << "r = " << r << ", planetcover = " << answer << "\n";
				return answer;
			}
			double f, intmin, intmax;
			transit::Transit *t;
};


class transit::planetdeviator : public Jcrap::function<double>
// function that does the 2-d integration of stellar flux
{
	public:
			planetdeviator(double a, transit::Transit *b) : 
				f(a), t(b) {starptr = &(b->Star());}
			planetdeviator(transit::star *staronly) : 
				t(0), starptr(staronly) {} // rest of the vars don't matter
			
			double the_function(double r) {
			// the_function takes the radial location in pixels, not meters, to prevent
			// nr routines from going haywire with stupidly huge numbers.
				double answer;
//				cout << "In planetdeviator (radial integrator) t=" << t ;
//				cout << " r=" << r << "\n";
		
				if (r > starptr->radius_in_pixels() 
						&& starptr->ctype != POLAR2WITHSCATTERING) return 0.;
				if (r == 0) return 0.;
				
				if (t == 0) {
				// case 1: integrating with no planet present for total star flux
//					cout << "ringchunking for r=" << r << "\n";
					transit::planetringchunker chunk(f, starptr, r);
					
//					cube chunkplot=chunk.plot(-pi, pi, 1000);
//					if (chunkplot.max() != 0.)
//					cout << "r=" << r << "\n";
//					chunkplot.keyword("title", (float2str(r)));
//					chunkplot.graph("-T X -x -3.14 3.14 -y -0.01 1.0");
//					char c; cin>>c;
					answer = chunk.integrate_smooth(-pi, pi,
							1.e-2/starptr->res(), 11);
				} else {
				// case 2: returns amount of flux that planet intercepts
//					cout << "Case 2 with r=" << r << "\n";
					transit::planetringchunker chunk(f, t, r);
				
				
					double thetapos(atan2((t->Planet().ylocation(f))/(1.-starptr->f_eff()), t->Planet().xlocation(f)));  // take new oblate stellar geometry into account
					double thetaradius(t->Planet().Rmaximum() / (1.-starptr->f_eff()) /
						(r / (starptr->radius_in_pixels()) * (starptr->radius())) * 1.2);

//				cube chunkplot=chunk.plot(thetapos-thetaradius, thetapos+thetaradius,
//						1000);
//				if (chunkplot.max() != 0.) 
//					chunkplot.graph("-T X -y -0.01 1.0");
//				cout << "before azimuthal chunk integration, thetapos=";
//				cout << thetapos << ", thetaradius=" << thetaradius << ", r=" << r <<"\n";
//				cout << "Rp=" << t->Planet().Rmaximum() << ", R*=";
//				cout << t->Star().radius() << "\n";
//				char c; cin >> c;
				
				
					int Kinitial=8;
					if (t->Planet().rings()) Kinitial += 2;
//				cout << "before azimuthal chunk integration\n";
					if (r < 2.*t->Planet().Rmaximum()/starptr->radius()*starptr->radius_in_pixels()/(1.-starptr->f_eff())  
							|| t->Planet().moons().size()) {
				// if within 2 planetary radii of center, or if moons, integrate full circle
						answer = chunk.integrate_smooth(-pi, pi,
								1.e2/starptr->res(), 14);
//						cout << "just integrated all the way around to find answer=" << answer << "\n";
					}
					else {// otherwise just integrate the area around the planet
						answer = chunk.integrate_smooth(thetapos-thetaradius,
								thetapos+thetaradius, 1.e-2/starptr->res(), Kinitial);
//						cout << "just integrated around planet to find answer=" << answer << "\n";
					}
				}
				return answer;
			}
			
			double f; 
			transit::Transit *t;
			transit::star *starptr;
};

static double twopi(2.*3.1415926535897932384642643383279502884197);

class starbright : public Jcrap::function<double>, public transit::star
{
	public:
			starbright(transit::star d, double t=0.) : transit::star(d), theta(t) { }
			
			double the_function(double r) {
				if (theta==0.)
					return twopi*r*starbright_xy(r,0.);
				else 
					return twopi*r*starbright_xy(r*cos(theta), r*sin(theta));
			}
			
			double theta;
};

#endif
