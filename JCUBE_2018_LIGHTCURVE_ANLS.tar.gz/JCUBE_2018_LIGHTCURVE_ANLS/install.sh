################################
# create necessary directories 
################################

if [ ! -d "$HOME/lib" ]; then
	mkdir $HOME/lib
	echo "created $HOME/lib directory"
fi

if [ ! -d "$HOME/bin" ]; then
	mkdir $HOME/bin
	echo "created $HOME/bin directory"
fi

################################
#Install Dependencies
################################

if ! type "g++" > /dev/null; then
	echo "installing g++"
	sudo apt-get install -qqy g++
fi

if ! type "pip" > /dev/null; then
	echo "installing pip"
	sudo apt-get install -qqy python-pip
fi

#sudo apt install libqt4-designer libqt4-opengl libqt4-svg libqtgui4 libqtwebkit4 libqt4-dev
#sudo apt-get install libboost-program-options-dev
#sudo apt-get install libgdal-dev
#sudo apt-get install libmysqlclient-dev libmysqld-dev libmysql++-dev libmysql++-doc
#sudo apt install graphicsmagick-libmagick-dev-compat
#export CPLUS_INCLUDE_PATH=/usr/include/gdal
#export C_INCLUDE_PATH=/usr/include/gdal


cd c++/commandl
if [ ! -f "commandl/libcommandl.a" ]; then
	make
	echo "created $HOME/lib directory"
fi
cd ../../

cd nr/
make
cd ../

echo "installed all dependencies!"

################################
#Install Jcube
################################
cd c++/Jcube/
make
cd ../../
################################
#Install Jcubeviewer
################################

cd c++/Jcube/Jcubeviewer
make
cd ../../../

################################
#Install Transitfitter
################################

cd c++/Jcube/theoreticaltransit
make
cd transitfitter/
make
if ! type "transitfitter" > /dev/null; then
	echo "linking transitfitter"
	sudo ln -s $PWD/./transitfitter /usr/bin/transitfitter
fi
cd ../../../../

################################
#Install LASR
################################

cd c++/Jcube/LASR/
make
if ! type "LASR" > /dev/null; then
	echo "linking LASR"
	sudo ln -s ./LASR /usr/bin/LASR
fi




