cd nr/
rm *.o
cd ../

cd c++/commandl/commandl/
rm *.o
rm *.d 
rm *.a
cd ../../

cd Jcube/
rm *.o

cd LASR
rm *.o
rm *.d

cd ../Jcubeviewer/
rm *.o

cd ../theoreticaltransit/
rm *.o

cd transitfitter/
rm transitfitter
rm *.o



