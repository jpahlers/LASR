
#ifndef SPINORBIT_H
#define SPINORBIT_H


float eq2_52(float);
float Torque_EZ(float);
float Torque(float t);
float Torqueintegral(float r);
double spinorbit(double e);

class EGPcrap
{
public:
	static double M;
	static double e;
	static EGP o;
	static double rotation;
};
#endif
