#include "../Jfunction.h"
#include "EGP.h"

class habitablefunc : public Jcrap::function<double>
{
	public:
			habitablefunc(const EGP&, value, double=1.);
			habitablefunc(const EGP&);
			
			double the_function(double);
	
	private:
			value Mm;
			double k2p;
			value T;
			value Rp;
			value G;
			double Qp;
			double Fratio;
			value Mp;
};
