#include "signalreduction.h"
template <class T>
double zzbrent(T &func, double x1, double x2, double chisqmin, double dchisq, cube &tscube, cube &fitcube, int &paramno, double tol){ // Uses Brent's method of root-finding to solve uncertainties
	int ITMAX=100;
	double EPS=numeric_limits<double>::epsilon();
	double a=x1,b=x2,c=x2,d,e;
	double fa=func(tscube,fitcube,a,chisqmin,dchisq,paramno);
	double fb=func(tscube,fitcube,b,chisqmin,dchisq,paramno);
//	cout << "fa=" << fa << "\tfb=" << fb << endl;
	double fc,p,q,r,s,tol1,xm;
	if ((fa > 0.0 && fb > 0.0) || (fa < 0.0 && fb < 0.0)){
		cout << "Root must be bracketed in zbrent\n";
		throw("Root must be bracketed in zbrent");
	}
	fc=fb;
	for (int iter=0;iter<ITMAX;iter++){
		if ((fb > 0.0 && fc > 0.0) || (fb < 0.0 && fc < 0.0)) {
			c=a;
			fc=fa;
			e=d=b-a;
		}
		if (abs(fc) < abs(fb)) {
			a=b;
			b=c;
			c=a;
			fa=fb;
			fb=fc;
			fc=fa;
		}
		tol1=2.0*EPS*abs(b)+0.5*tol;
		xm=0.5*(c-b);
		if (abs(xm) <= tol1 || fb == 0.0){return b;}
		if (abs(e) >= tol1 && abs(fa) > abs(fb)){
			s=fb/fa;
			if (a == c){
				p=2.0*xm*s;
				q=1.0-s;
			}
			else{
				q=fa/fc;
				r=fb/fc;
				p=s*(2.0*xm*q*(q-r)-(b-a)*(r-1.0));
				q=(q-1.0)*(r-1.0)*(s-1.0);
			}
			if (p > 0.0) q = -q;
			p=abs(p);
			double min1=3.0*xm*q-abs(tol1*q);
			double min2=abs(e*q);
			if (2.0*p < (min1 < min2 ? min1 : min2)) {
				e=d;
				d=p/q;
			} else {
				d=xm;
				e=d;
			}
		} 
		else{
			d=xm;
			e=d;
		}
		a=b;
		fa=fb;
		cout << "tol1=" << tol1 << endl;
		if (abs(d) > tol1){b += d;}
		else{ 
			b += BasicFunctions::SIGN(tol1,xm);
			fb=func(tscube, fitcube, b, chisqmin, dchisq, paramno);
			cout << "new fb =" << fb;
		}
		cout << "b="<< b << endl;
	}
	throw("Maximum number of iterations exceeded in zbrent");
		
}

template <class T>
double zbisect(T &func, double x1, double x2, double del, double chisqmin, double dchisq, cube &tscube, cube &fitcube, int &paramno, double tol){
	int ITMAX=100;
	double EPS=numeric_limits<double>::epsilon();
	double a=x1,b=x2;
	double fa=func(tscube,fitcube,a,chisqmin,dchisq,paramno);
	double fb=func(tscube,fitcube,b,chisqmin,dchisq,paramno);
	double c(0),fc(0);
	int count(0.);
	while(fa*fb>=0.){
		cout << "function not bracketed by (a,b) -- increasing the value of b to ";
		if(paramno % 3 == 0){
			while(b>2.*Constants::pi){b-=2.*Constants::pi;}
			while(b<2.*Constants::pi){b+=2.*Constants::pi;}
		}
		if(a>b){
			b-=del;
			cout << b  << " for paramno " << paramno << endl;
		}
		else{
			b+=del;
			cout << b  << " for paramno " << paramno << endl;
		}
		fb=func(tscube,fitcube,b,chisqmin,dchisq,paramno);
		cout << "f(a=" << a << ")=" << fa << " f(b=" << b << ")=" << fb << endl;
		count++;
		if(count>=100){
			cout << "ERROR: cannot bracket function for paramno " << paramno << endl;
			throw("ERROR: cannot bracket function.\n");
		}
	}
	
	for(int n(0); n<ITMAX; n++){
		c=(b+a)/2.;		
		fc=func(tscube,fitcube,c,chisqmin,dchisq,paramno);
		if(fa*fc>=0){
			a = c;
			fa = fc;
		}
		else{
			b = c;
			fb = fc;	
		}
//		cout << "f(a= " << a << ")=" << fa << "\tf(b=" << b << ")=" << fb << endl;
		if(abs(b-a)<tol){
			return (b+a)/2;}
		
	}
	cout << "Maximum number of iterations exceeded in zbisect\n";
	throw("Maximum number of iterations exceeded in zbrent");


}

#define TINY 1.e-20
struct LASRfit{
	cube tscube;
	vector<vector<double> > LASRpts;
	vector<double> dels;
	double fhwidth;
	double peakpts;
	float ftol;
	int nsteps;
	LASRfit(cube _ts, vector<vector<double> > _lspts, vector<double> _d, double _fhw, double _ppts, float _ftol, int _nsteps) : tscube(_ts), LASRpts(_lspts), dels(_d), fhwidth(_fhw), peakpts(_ppts), ftol(_ftol), nsteps(_nsteps) {}                                           
	
	double freqspace;
	int ihi,ilo,inhi,ndim,mpts,nfreqs;
	double freqstart,freqend,fmin;
	
	vector<double> minimize(){
		double NMAX = nsteps;
		int nfunc;
		double tstart=tscube.Axis(Z,0);
		for(int z(0); z<tscube.N(Z); z++){
			tscube.Axis(Z,z)-=tstart;
		}
		
		freqspace = 2.*fhwidth/peakpts;
		periodo tseries(tscube); 
		ameeba am(ftol);
		cube p0=am.buildpmatrix(LASRpts,dels); //initial p simplex
		cube p = p0;
		
		nfreqs=LASRpts.size();
				
		double sig0(0.); //significance without subtraction
		ndim=p.N(Y);
		mpts=p.N(X);
		vector<double> y(mpts),psum(ndim),pmin(ndim),pline(ndim);
 
		for(int j(0); j<ndim; j++){pline[j]=p(0,j,0);}
		for(int n(0); n<nfreqs; n++){
			pline[3*n+1]=0.;
		}
		sig0=get_yval(pline);
		cout << "initial significance: " << sig0 << endl;
		
		for(int i(0); i<mpts; i++){ //get initial y values 
			for(int j(0); j<ndim; j++){pline[j]=p(i,j,0);}
			y[i]=get_yval(pline);
		}
		
		cout << "using simplex:\n---------------------------------------------------------------------\n";
		am.printmatrix(p,y);		
		nfunc=0;
		get_psum(p,psum);
		
		for(;;){
			ilo=0;
			ihi = y[0]>y[1] ? (inhi=0,1) : (inhi=1,0);
			for(int i(0); i<mpts; i++){
				if(y[i]<=y[ilo]){ilo=i;}
				if(y[i]>y[ihi]){
					inhi=ihi;
					ihi=i;
				}
				else if(y[i]>y[inhi] && i!=ihi){inhi=i;}
			}
			double rtol = y[ilo]/sig0;
			cout << "rtol=" << rtol << endl;
			if(rtol<ftol || nfunc>=NMAX){
				if(nfunc>=NMAX){cout << "WARNING: NMAX EXCEEDED\n";}
				swap(y[0],y[ilo]);
				for(int j(0); j<ndim; j++){
					swap(p(0,j,0),p(ilo,j,0));
					pmin[j]=p(0,j,0);
				}
				fmin=y[0];
				return pmin;
			}			
			cout << "---------------------------------------------------------------------\nusing simplex:\n";
			am.printmatrix(p,y);		
			nfunc+=2;
			double ytry = amotry(p,y,psum,ihi,-1.0);
			if(ytry <= y[ilo]){ytry=amotry(p,y,psum,ihi,2.0);}
			else if(ytry >= y[inhi]){
				double ysave = y[ihi];
				ytry=amotry(p,y,psum,ihi,0.5);
				if(ytry >= ysave){
					for(int i(0); i<mpts; i++){
						if(i != ilo){
							for(int j=0; j<ndim; j++){p(i,j,0)=psum[j]=0.5*(p(i,j,0)+p(ilo,j,0));}
							y[i]=get_yval(psum);
						}
					}
					nfunc+=ndim;
					get_psum(p,psum);
				}
			}
			else --nfunc;	
			vector<double> psmall(ndim);
			for(int j(0); j<ndim; j++){psmall[j]=p(ilo,j,0);}
			cout << "% reduced: " << (sig0-get_yval(psmall))*100/sig0 << endl;	
		} // end of primary for-loop		
	}
	
	inline void get_psum(cube &p, vector<double> &psum){
		for(int j(0); j<ndim; j++){
			double sum =0.;
			for(int i(0); i<mpts; i++){
				sum+=p(i,j,0);
			}
			psum[j]=sum;
		}
	}
	
	inline double get_yvalold(vector<double> pline){
		freqspace = 2.*fhwidth/peakpts;
		periodo tseries(tscube);
		ameeba am(ftol);
		double sigsum(0.);
		cube newcube = tscube;
		for(int n(0); n<nfreqs; n++){ //create subtracted timeseries cube
			newcube = tseries.subcube(newcube,pline[3*n+0],pline[3*n+1],pline[3*n+2]);
		}
		for(int n(0); n<nfreqs; n++){ // find peaks, calculate total significance
			freqstart = pline[3*n]-fhwidth;
			freqend = pline[3*n]+fhwidth;
			cube fpeak = tseries.periodogram_parallel(newcube,freqstart,freqend,freqspace,0);
			sigsum+=am.sigcalc(fpeak);
		}
		return sigsum;
	}
	
	inline double get_yval(vector<double> pline){
		freqspace = 2.*fhwidth/peakpts;
		periodo tseries(tscube);
		ameeba am(ftol);
		double sigsum(0.);
		cube newcube = tscube;
		for(int n(0); n<nfreqs; n++){ //create subtracted timeseries cube
			newcube = tseries.subcube(newcube,pline[3*n+0],pline[3*n+1],pline[3*n+2]);
		}
		vector<cube> cubevector(nfreqs);
		for(int n(0); n<nfreqs; n++){ // find peaks, calculate total significance
			freqstart = roundedfreq(pline[3*n]-fhwidth,freqspace);
			freqend = roundedfreq(pline[3*n]+fhwidth,freqspace);
//			cout << "starting frequency (should be divisible by " << freqspace << ") " << freqstart << endl; 
			
			cube fpeak = tseries.periodogram_parallel(newcube,freqstart,freqend,freqspace,0);
			cubevector[n]=fpeak;
		}
		if(nfreqs==1){
			cube totcube=cubevector[0];
			double sigsum = am.sigcalc(totcube);
			return sigsum;
		}
		else{
			cube totcube=BasicFunctions::combineZcubes(cubevector);
			double sigsum = am.sigcalc(totcube);
			return sigsum; 
		}
	}
	
	
	inline double roundedfreq(double freqval, double pspace){
		double rem = fmod(freqval,pspace);
		if(rem>=pspace/2){return freqval+pspace-rem;}
		else{return freqval-rem;}
	}
	
	
	inline void print_results(vector<double> results){
		cout << setprecision(5) << scientific;
		cout << "********************************************************************\n";
		cout << "RESULTS FOUND:\n";
		cout << "freq(Hz)" << "\tAmplitude" << "\tphase\n";
		nfreqs=LASRpts.size();
		for(int i(0); i<nfreqs; i++){
			cout << results[3*i+0] << "\t" << results[3*i+1] << "\t" << results[3*i+2] << endl;		
		}
		cout << "********************************************************************\n";
	}
	
	inline double amotry(cube &p, vector<double> &y, vector<double> &psum, const int ihi, const double fac){
		vector<double> ptry(ndim);
		double fac1=(1.0-fac)/ndim;
		double fac2=fac1-fac;
		for(int j(0); j<ndim; j++){
			ptry[j]=psum[j]*fac1-p(ihi,j,0)*fac2;
		}
		double ytry = get_yval(ptry);
		if(ytry<y[ihi]){
			y[ihi]=ytry;
			for(int j(0); j<ndim; j++){
				psum[j] += ptry[j]-p(ihi,j,0);
				p(ihi,j,0) = ptry[j];
			}			
		}
		return ytry;		
	}
	
	inline cube tssub(vector<double> results){
		freqspace = 2.*fhwidth/peakpts;
		cout << "creating subtracted timeseries inside LASRfit::outbaseline\n";
		int nopeaks = results.size()/3;
		cube outcube = tscube;
		periodo tseries(outcube);
		for(int n(0); n<nopeaks; n++){
			double freq = results[3*n+0];
			double amp = results[3*n+1];
			double phase = results[3*n+2];
			outcube = tseries.subcube(outcube,freq,amp,phase);
		}
		return outcube;
	}
	
	inline cube presult(cube incube, vector<double> results){
		periodo tseries(tscube);
		freqspace = 2.*fhwidth/peakpts;
		int nopeaks = results.size()/3;
		vector<vector<double> > periodovector;
		for(int n(0); n<nopeaks; n++){
			cube fpeak = tseries.periodogram_parallel(incube,results[3*n]-fhwidth,results[3*n]+fhwidth,freqspace,0);
			vector<double> row (2);
			for(int z(0); z<fpeak.N(Z); z++){
				row.at(0) = fpeak.Axis(Z,z);
				row.at(1) = fpeak(Z,z);
				
				int istrue = 1; 
				for(int i(0); i<periodovector.size(); i++){
					if(row.at(0)==periodovector.at(i).at(0)){istrue=0;}
				}
				if(istrue==1){periodovector.push_back(row);} 
			}
		}
		cube outpcube(1,1,periodovector.size());
		for(int z(0); z<outpcube.N(Z); z++){
			outpcube.Axis(Z,z) = periodovector.at(z).at(0);
			outpcube(0,0,z) = periodovector.at(z).at(1);
			 
		}
		return outpcube;
	}
	
	cube uncerfinder(cube &tscube, cube &fitcube, double dchisq, double chisqmin){
		analysis anl;
		cube results(3,1,fitcube.N(Z));
		for(int paramno(0); paramno<fitcube.N(Z); paramno++){
			double pval = fitcube(0,0,paramno);
			int oscno = floor((paramno-1)/3)+1;
			if(paramno==0){
				double tol =1.e-6;
				double upperunc = zbisect(*anl.chisqroot, pval, pval+1.e-3, 0., chisqmin, dchisq, tscube, fitcube, paramno, tol);
				double lowerunc = zbisect(*anl.chisqroot, pval, pval-1.e-3, 0., chisqmin, dchisq, tscube, fitcube, paramno, tol);
				results(0,0,paramno)=fitcube(0,0,paramno);
				results(1,0,paramno)=upperunc-pval;
				results(2,0,paramno)=pval-lowerunc;
				cout << "Z_0=" << results(0,0,paramno) << "\t+" << results(1,0,paramno) << "\t-" << results(2,0,paramno) << endl; 
			}
			else{
				double del;
				double tol;
				string pname;
				if(paramno % 3 == 1){ //find uncertainty of a frequency
					del = 5.e-9;
					tol = 1.e-11;
					pname = "f"+int2str(oscno);
				}
				if(paramno % 3 == 2){ //find uncertainty of an amplitude
					del = 1.e-4;
					tol = 1.e-8;
					pname = "a"+int2str(oscno);
				}
				if(paramno % 3 == 0){ //find uncertainty of a phase
					del = 0.25;
					tol = 1.e-5;
					pname = "p"+int2str(oscno);
				}
				double upperunc = zbisect(*anl.chisqroot, pval, pval+del, del, chisqmin, dchisq, tscube, fitcube, paramno, tol);
				double lowerunc = zbisect(*anl.chisqroot, pval, pval-del, del, chisqmin, dchisq, tscube, fitcube, paramno, tol);
				results(0,0,paramno)=fitcube(0,0,paramno);
				results(1,0,paramno)=upperunc-pval;
				results(2,0,paramno)=pval-lowerunc;
				cout << pname << "=" << results(0,0,paramno) << "\t+" << results(1,0,paramno) << "\t-" << results(2,0,paramno) << endl; 
			}
		}
		return results;
	}
	
	cube errorprop(cube &tscube, cube &unccube){
		cube outcube=tscube;
		int nparams = unccube.N(Z)-1;
		int nosc = nparams/3;
		double w,a,p,t,dw,da,dp,errsq;
		if (osuppress < 1) cout << "Calculating new uncertainties --  00%";
		if (osuppress < 1) cout.flush();
		for(int z(0); z<outcube.N(Z); z++){
			errsq=pow(tscube(1,0,z),2);
			t=BasicFunctions::mod(tscube.Axis(Z,z),2.*Constants::pi/w);
			for(int n(0); n<nosc; n++){
				w=2.*Constants::pi*unccube(0,0,3*n+1);
				a=unccube(0,0,3*n+2);
				p=unccube(0,0,3*n+3);
				dw=2.*Constants::pi*(unccube(1,0,3*n+1)+unccube(2,0,3*n+1))/2.;
				da=(unccube(1,0,3*n+2)+unccube(2,0,3*n+2))/2.;
				dp=(unccube(1,0,3*n+3)+unccube(2,0,3*n+3))/2.;
//				cout << "dw=" << dw << "\tda=" << da << "\tdp=" << dp << endl;
				errsq+= pow(sin(w*t+p)*da,2) + pow(a*cos(w*t+p)*t*dw,2) + pow(a*cos(w*t+p)*dp,2);	
			}
			outcube(1,0,z)=sqrt(errsq);
//			cout << "new_unc=" << outcube(1,0,z) << "\told_unc=" << tscube(1,0,z)<<endl;
			if(osuppress<1){printpercent(z,tscube.N(Z)-1);}
			//if(osuppress<1){printpercent(z,tscube.N(Z)-1);}
		}
		if (osuppress < 1) printpercent (tscube.N(Z), tscube.N(Z)-1);
		if (osuppress < 1) cout << "\n";
		return outcube;
	}
	
};
#undef TINY

struct fishermatrix{
	cube tscube;
	cube fitcube;
	int nparams;
	double chisqmin;
	analysis anl;
	fishermatrix(cube _ts, cube _fit, double _chisqmin) : tscube(_ts), fitcube(_fit), nparams(fitcube.N(Z)), chisqmin(_chisqmin) {}                       
	cube buildcovmatrix(vector<double> dsteps);
	cube getdiagonals(vector<double> dsteps);
	cube getuptriangle(vector<double> dsteps, cube diag);
	double determinant(cube covcube);
	pair<vector<double>, bool> eigenvalues(cube covcube);
	cube builduncer(cube fishcube);
};


cube fishermatrix::buildcovmatrix(vector<double> dsteps){
	cube fishcube(nparams,nparams,1);
	cube covcube(nparams,nparams,1);
	cube diags = getdiagonals(dsteps);
	cube uptriangle = getuptriangle(dsteps, diags);
	for(int i(0); i<nparams; i++){
		for(int j(0); j<nparams; j++){
			if(j>i) fishcube(i,j,0)=uptriangle(0,i,j);
			if(j==i) fishcube(i,j,0)=diags(0,i,j);
			if(j<i) fishcube(i,j,0)=uptriangle(0,j,i);
		}
	}
	covcube = fishcube.matrixinvert();	
	return covcube;	
}

cube fishermatrix::getdiagonals(vector<double> dsteps){
	if (osuppress < 1) cout << "Calculating diagonal elements of fisher matrix --  00%";
	if (osuppress < 1) cout.flush();
	cube diag(3,nparams,nparams);
	cube adjupfitcube = fitcube;
	cube adjdownfitcube = fitcube;
	double chisqup, chisqdown; 
	for(int i(0); i<nparams; i++){
		adjupfitcube(0,0,i)+=2.*dsteps[i];
		adjdownfitcube(0,0,i)-=2.*dsteps[i];
		chisqup = anl.chisqvalue(tscube, adjupfitcube, 0);
		chisqdown = anl.chisqvalue(tscube, adjdownfitcube, 0); 
		diag(0,i,i) = (chisqup+chisqdown-2.*chisqmin)/(4.*dsteps[i]*dsteps[i]);
		if(osuppress<1){printpercent(i,nparams-1);} 
		adjupfitcube(0,0,i)=fitcube(0,0,i);
		adjdownfitcube(0,0,i)=fitcube(0,0,i);		
	}
	if (osuppress < 1) printpercent (nparams, nparams);
	if (osuppress < 1) cout << "\n";
	return diag;
}

cube fishermatrix::getuptriangle(vector<double> dsteps, cube diag){
	int nelem = (nparams-1.)*nparams/2.;
	if (osuppress < 1) cout << "Calculating off-diagonal elements of fisher matrix --  00%";
	if (osuppress < 1) cout.flush();
	cube uptriangle(3,nparams,nparams);
	cube adjdblupfitcube = fitcube;
	cube adjdbldownfitcube = fitcube;
	cube adjupdownfitcube = fitcube;
	cube adjdownupfitcube = fitcube;
	double chisqdblup, chisqdbldown, chisqdownup, chisqupdown; 
	for(int i(0); i<nparams; i++){
		for(int j(i+1); j<nparams; j++){				
			adjdblupfitcube = fitcube;
			adjdbldownfitcube = fitcube;
			adjupdownfitcube = fitcube;
			adjdownupfitcube = fitcube;
			adjdblupfitcube(0,0,i)+=dsteps[i];
			adjdblupfitcube(0,0,j)+=dsteps[j];
			adjdbldownfitcube(0,0,i)-=dsteps[i];
			adjdbldownfitcube(0,0,j)-=dsteps[j];
			adjupdownfitcube(0,0,i)+=dsteps[i];
			adjupdownfitcube(0,0,j)-=dsteps[j];
			adjdownupfitcube(0,0,i)-=dsteps[i];
			adjdownupfitcube(0,0,j)+=dsteps[j];
			chisqdblup = anl.chisqvalue(tscube, adjdblupfitcube, 0);
			chisqdbldown = anl.chisqvalue(tscube, adjdbldownfitcube, 0);
			chisqupdown = anl.chisqvalue(tscube, adjupdownfitcube, 0);
			chisqdownup = anl.chisqvalue(tscube, adjdownupfitcube, 0);
			uptriangle(0,i,j) = ((chisqdblup-chisqupdown)-(chisqdownup-chisqdbldown))/(4.*dsteps[i]*dsteps[j]);
			if(osuppress<1){printpercent(i*nparams+j-BasicFunctions::sumcount(i+1),nelem-1);}			
		}
	}
	if (osuppress < 1) printpercent (nelem, nelem-1);
	if (osuppress < 1) cout << "\n";
	return uptriangle;
}

double fishermatrix::determinant(cube covcube){
	long double det = covcube.determinant();
	return det;
}

pair<vector<double>, bool> fishermatrix::eigenvalues(cube covcube){
	bool ans(true);
	pair<cube,vector<double> > eigen = covcube.eigenvalues();
	for(int n(0); n<eigen.second.size(); n++){
		if(eigen.second[n]<0.) ans=false;
	}
	vector<double> vals = eigen.second;
	return {vals,ans};
}

cube fishermatrix::builduncer(cube covcube){
	cube outcube(2,1,nparams);
	for(int n(0); n<nparams; n++){
		outcube(0,0,n)=fitcube(0,0,n);
		outcube(1,0,n)=sqrt(covcube(n,n,0));
	}
	return outcube;
}





