#ifndef CONSTANTS_H
#define CONSTANTS_H

namespace Constants
{
	const double pi(3.141592653589793238462643383279502884197);
	const double c=299800000.0;
	const double G=6.67384*pow(10.,-11.);	
	const double ly=9.4605*pow(10.,15.);
	const double parsec=3.2616*ly;
	const double secinday=86400.0;
	const double secinyear=365.242*secinday;
	
	const double amerc = 5.791*pow(10.,7.);
	const double aearth = 1496000000.0;
	const double amars = 2.2792*pow(10.,11.);
	const double ajup=7.7857*pow(10.,11.);
	const double anep=4.49506*pow(10.,12.);
	const double asat = 1.42673*pow(10.,12.);
	const double auran=2.87246*pow(10.,12.);
	const double aven = 	1.0821*pow(10.,8.);
	const double au = 149597870691.0;
	const double eearth=0.0167;
	const double emars=0.0935;	
	const double emerc=0.2056;	
	const double ejup=0.0489;	
	const double enep=0.0113;
	const double esat = 0.0565;
	const double euran=0.0457;
	const double even = 0.0067;
	const double mearth=5.97219*pow(10.,24.);
	const double mjup=1.89813*pow(10.,27.);		
	const double mmars=6.4171*pow(10.,23.);
	const double mmoon=7.3477*pow(10.,22.);
	const double mmerc=3.3011*pow(10.,23.);	
	const double mnep=1.02413*pow(10.,26);
	const double msat=5.683*pow(10.,26.);
	const double msun=1.98891*pow(10.,30.);
	const double muran=8.6183*pow(10.,25.);
	const double mven= 4.8675*pow(10.,24.);
	const double rearth=6378100.0;
	const double rmerc=2439700.0;
	const double rmars=3389500.0;
	const double rmoon=1737400.0;
	const double rnep=24622000.0;
	const double rsat=60268000.0;
	const double rjup=71492000.0;
	const double rsun=695500000.0;
	const double ruran=25362000.0;
	const double rven=6051800.0;
	
	const double atest=1.42673*pow(10.,12.);
	const double etest=0.0565;
	const double mtest=2.2*5.683*pow(10.,26.);
	const double rtest=60268000.0;
		 
		
}

#endif
