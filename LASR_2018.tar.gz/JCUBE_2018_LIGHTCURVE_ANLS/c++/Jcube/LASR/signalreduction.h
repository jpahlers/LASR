#include "basicfunctions.h"


using namespace std;
using namespace Constants;

class gendata{
	public:
			gendata(vector<vector<double> > params, double tstart,double tend, double tspace, double sigma, double lagcor, double F0, vector<pair<double,double> > gaps);
			void params(vector<vector<double> > inparams){_params=inparams;}
			void tstart(double intstart){_tstart=intstart;}
			void tend(double intend){_tend=intend;}
			void tspace(double intspace){_tspace=intspace;} 
			void sigma(double insigma){_sigma=insigma;}
			void lagcor(double inlagcor){_lagcor=inlagcor;}
			void F0(double inF0){_F0=inF0;}
			void gaps(vector<pair<double,double> > ingaps){_gaps=ingaps;}
			
			vector<vector<double> > params(){return _params;}
			double tstart(){return _tstart;}
			double tend(){return _tend;}
			double tspace(){return _tspace;}
			double sigma(){return _sigma;}
			double lagcor(){return _lagcor;}
			double F0(){return _F0;}
			vector<pair<double,double> > gaps(){return _gaps;}
			
			//functions
			vector<pair<double,double> > data();
			cube datacube();
			bool outsidegap(double);
			pair<cube,cube> transitcutter(cube,long double,long double,long double,int);
			
	private:
			vector<vector<double> > _params;
			double _tstart;
			double _tend;
			double _tspace;
			double _sigma;
			double _lagcor;
			double _F0;
			vector<pair<double,double> > _gaps;
};

class periodo{
	public:
			periodo(cube tscube);
			void tscube(cube intscube){_tscube=intscube;}
			
			cube tscube(){return _tscube;}
			
			//functions
			pair<double,double> avevar(cube);
			cube periodogram_parallel(cube,float,float,float,int);
			cube periodogram_parallelnew(cube,float,float,float,int);
			cube subcube(cube,double,double,double);
			pair<int,pair<double,double> > maxsignif(cube);
	private:
			cube _tscube;
};

class ameeba{
	public:
			ameeba(float ftol);
			void ftol(double inftol){_ftol=inftol;}
			
			float ftol(){return _ftol;}
			
			//functions
			double sigcalc(cube);
			cube buildpmatrix(vector<vector<double> >, const vector<double>);
			vector<double> minstep(cube,vector<double>);
			int printpsimplex(cube);
			void printmatrix(cube,vector<double>);
			
	private:
			float _ftol;
			
};

class analysis{
	public:
			
			//functions
			static double chisqvalue(cube, cube, int);
			static double chisqroot(cube&, cube&, double&, double&, double&, int&);
			cube injecttransit(cube, cube, double, double, double, double, double, int);
};		















