#include "../Jcrap.h"

#include "theoreticaltransit.h"

#ifndef TRANSITFITHH
#define TRANSITFITHH


using namespace transit;

class transitfunc : public Jcrap::multifunction<double>
{
	public:
		transitfunc(transit::Transit&);
	
		double the_function(double,vector<double>&,unsigned int=0);
		vector<double> the_derivitives(double, vector<double>&,unsigned int=0);
	
		
		transit::Transit* tp;
		
		transit::Transit& Transit() {return *tp;}
		map<double, double> timeintegrationdatabase;
		pair<vector<double>, double> fit_withtimeintegration(cube, vector<double>, vector<int>);  // override of multifunction::fit
		
		void set_initialalamda(double d) {initialalamda = d;}
		double aconvert(vector<double>&, vector<int>&, int);
		
		bool safetyon;
		
		static int paramnumber();
		
	private:
	
		vector<double> olda;
};

#endif
