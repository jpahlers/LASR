//#include "../Jfunction.h"
#include "theoreticaltransit.h"

using namespace transit;

class besseltest : public Jcrap::function<double>
{
public:
	besseltest() {}
	
	double the_function(double x) { return Jbessj1(x); }
};


class refractedintensity : public Jcrap::function<double>
{
	public:
		refractedintensity(transit::Transit T, phasefunc P, double R, double locr, double OD) : 
			thistransit(T), Pfunc(P), starpixel_r(R), r(locr),tau(OD) {}

		double the_function(double theta) {
			double answer, alpha, projected_d, mu, F0;
			projected_d = sqrt(r*r+starpixel_r*starpixel_r -
					2.*r*starpixel_r*cos(theta))  /  thistransit.platescale();
			alpha = atan(projected_d/thistransit.Planet().semimajoraxis());
//			cout << "alpha = " << alpha << ", projected_d=" << projected_d << "\n";
			mu = cos(asin(starpixel_r/(double)thistransit.Star().radius_in_pixels())); // this is limb-darkening mu, not cos(incidence angle)

// this removed for efficiency purposes, and parts of it placed in refractedatlocation
//			F0 = thistransit.Star().limbdark(mu) * cos(theta)*cos(theta) /
//					(pow(thistransit.Planet().semimajoraxis()*platescale, 2.) * transit::pi);

			double ct(cos(alpha));
			F0 = 	thistransit.Star().limbdark(mu) * ct*ct;		
//			cout << "F0 = " << F0 << "\n";
			
// this calculates flux to the observer from French&Nicholson(2000) eq (13)
// by doing flux 
			answer = F0 * Pfunc(alpha);
			
			return answer;
		}
		
	private:
		transit::Transit thistransit;
		phasefunc Pfunc;
		double starpixel_r, r, tau;
};

class refracteddonut : public Jcrap::function<double>
{
	public:
		refracteddonut(transit::Transit T, phasefunc P, double locr, double OD) : 
			thistransit(T), Pfunc(P), loc_r(locr), tau(OD) {}
	
	double the_function(double rvalue) {
		refractedintensity Refrac(thistransit, Pfunc, rvalue, loc_r, tau);
		static double res(thistransit.Star().res()/thistransit.Star().sum());
		return rvalue*Refrac.integrate_smooth(0., 2.*transit::pi, 1./res);
	}

	private:
		transit::Transit thistransit;
		phasefunc Pfunc;
		double loc_r, tau;	
};

class refractedatlocation : public Jcrap::function<double>
{
	public:
		refractedatlocation(transit::Transit T, phasefunc P, double OD) : 
			thistransit(T), Pfunc(P), tau(OD) {}
	
	double the_function(double loc_r)
	{
		static double starrad(thistransit.Star().radius_in_pixels());
		double answer;
//		double omegabar(0.5);
		static double res(thistransit.Star().res()/thistransit.Star().sum());
//		double tau_g(tau/2.);

//		double a(fabs(atan( sin(thistransit.Planet().poleangle()) * 
//					tan(thistransit.Planet().obliquity()))));	// angle the planet is tilted toward you, for foreshortening purposes

		refracteddonut rd(thistransit, Pfunc, loc_r, tau);
		answer = 1.;  // FORCED TO WORK for 100% scattering case
						  // is same as French & Nicholson (2000), as their P(@)
						  // integrates to 4pi (mine forced to integrate to 1)
		              // and their final F_sc expression has a 2pi in the denom.
						  // Now, if I only understood where that 2pi came from, I'd
						  // be set.  Aha!  Its from the original equation 6.
						  // *sigh* -- that will learn me.  The 2. was wrong, now its back to 1..
//		answer*= (tau_g/fabs(sin(a))) * exp(-2.*tau_g/fabs(sin(a)))/pi;
		answer/= pow(thistransit.Planet().semimajoraxis()/
				          (2.*thistransit.Star().radius()), 2.);
		answer*= rd.integrate_smooth(0., starrad, 1./res, 5); 
		if (thistransit.Star().ctype == CARTESIAN) answer/=starrad*starrad*4.;
		return answer; 
	}

	private:
		transit::Transit thistransit;
		phasefunc Pfunc;
		double tau;	
};

class edgescatterintensity : public Jcrap::function<double>
{
public:
	edgescatterintensity(transit::Transit& t, double r) : T(t), Rval(r) {}
	
	double the_function(double partsize) {
		phasefunc Pfunc(value(partsize, "m"), value(0.5, "um"));
		refractedatlocation R(T, Pfunc, 1.0);
	
		return R(Rval);
	}
	
	transit::Transit T;
	double Rval;
};
