#include "valuespanel.h"
#include "fitter.h"

#include <string>

#include <qvalidator.h>
#include <qdialog.h>

#include "../../Jcrap.h"

#include "../theoreticaltransit.h"
#include "../transitfit.h"
#include "transitfitter.h"

using namespace std;



valuespanel::valuespanel(QWidget *pparent, const char *) :
	Q3HBox(pparent),
	
	uservalues(this),
	Rstar(&uservalues),
	Rstarcheck("R_star (R_Sun)", &Rstar),
	Rstarbox("1.00", &Rstar),
	Rplanet(&uservalues),
	Rplanetcheck("R_Planet (R_Jup)", &Rplanet),
	Rplanetbox("1.00", &Rplanet),
	Rratio(&uservalues),
	Rratiocheck("R_p/R_*", &Rratio),
	Rratiobox("0.1", &Rratio),
	inclination(&uservalues),
	inclinationcheck("Orbital Inclination(deg)", &inclination),
	inclinationbox("90.0", &inclination),
	b(&uservalues),
	blabel("Impact Parameter", &b),
	bbox("0.", &b),
	limb0(&uservalues),
	limb0check("Limb Darkening c1", &limb0),
	limb0box("0.64", &limb0),
	limb1(&uservalues),
	limb1check("Limb Darkening c2", &limb1),
	limb1box("0.00", &limb1),
	Tc(&uservalues),
	Tccheck("Time at Center (s)", &Tc),
	Tcbox("0", &Tc),
	F0(&uservalues),
	F0check("Normal Star Flux", &F0),
	F0box("1.00", &F0),
	Polartemp(&uservalues),
	Polartempcheck("Star Polar Temp(K)", &Polartemp),
	Polartempbox("5785", &Polartemp),
/*	Albedo(&uservalues),
	Albedocheck("Planet Albedo", &Albedo),
	Albedobox("0", &Albedo),
	Planettemp(&uservalues),
	Planettempcheck("Planet Temp(K)", &Planettemp),
	Planettempbox("1000", &Planettemp),*/
	starMOI(&uservalues),
	starMOIcheck("Star MOI C", &starMOI),
	starMOIbox("0.059", &starMOI),
	
	
	uservalues2(this),
	Mstar(&uservalues2),
	Mstarcheck("M_Star (M_Sun)", &Mstar),
	Mstarbox("1.00", &Mstar),
	Semimajoraxis(&uservalues2),
	Semimajoraxislabel("Semimajor", &Semimajoraxis),
	Semimajoraxisbox("0.", &Semimajoraxis),
	Period(&uservalues2),
	Periodcheck("Period(d)", &Period),
	Periodbox("3.52", &Period),
	Mplanet(&uservalues2),
	Mplanetcheck("M_Planet (M_Jup)", &Mplanet),
	Mplanetbox("0.", &Mplanet),
	Eccentricity(&uservalues2),
	Eccentricitycheck("Eccentricity", &Eccentricity),
	Eccentricitybox("0", &Eccentricity),
	Periapsis(&uservalues2),
	Periapsischeck("Arg of Periapsis", &Periapsis),
	Periapsisbox("90.", &Periapsis),
	Azimuthalangle(&uservalues2),
	Azimuthalanglecheck("Ascending node(degrees)", &Azimuthalangle),
	Azimuthalanglebox("180.", &Azimuthalangle),
	Rotationrate(&uservalues2),
	Rotationratecheck("Rotation Rate(hr)", &Rotationrate),
	Rotationratebox("0", &Rotationrate),
	Obliquity(&uservalues2),
	Obliquitycheck("Stellar Obliquity(deg)", &Obliquity),
	Obliquitybox("0", &Obliquity),
	Vsini(&uservalues2),
	Vsinicheck("V*Sin(i) (km/s)", &Vsini),
	Vsinibox("0", &Vsini),
	Oblateness(&uservalues2),
	Oblatenesslabel("Oblateness", &Oblateness),
	Oblatenessbox("0.", &Oblateness),
	Beta(&uservalues2),
	Betacheck("Beta", &Beta),
	Betabox("0.25", &Beta),
	
	
	fitbuttons(1,Qt::Horizontal,"Fit Actions", this),
	gofit("FIT!", &fitbuttons),
	goMCMCfit("MCMC fit", &fitbuttons),
	gotransfervalues("Transfer\nValues\n<-------", &fitbuttons),
	showguess("Plot\nGuess", &fitbuttons),
	guessmoviebutton("Guess Movie", &fitbuttons),
	addmoon("Add Moon", &fitbuttons),
	addring("Add Ring", &fitbuttons),
	
	fittedvalues(this),
	fitRstar("        R_Sun", &fittedvalues),
	fitRplanet("        R_Jup", &fittedvalues),
	fitinclination("        degrees", &fittedvalues),
	fitlimb0("        ", &fittedvalues),
	fitlimb1("        ", &fittedvalues),
	fitTc("        seconds", &fittedvalues),
	fitF0("        ", &fittedvalues),
	
	fittedvalues2(this),
	fitMstar("        M_Sun", &fittedvalues2),
	fitPeriod("        days", &fittedvalues2)
	
{
	setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
	
	Rstarcheck.setChecked(true);
	Rstarbox.setValidator(new QDoubleValidator( 0., 100., 100, &Rstarbox));
	Rplanetcheck.setChecked(true);
	inclinationcheck.setChecked(true);
	limb0check.setChecked(true);
	
	updatesemimajor();
	
	connect(&showguess, SIGNAL(clicked()), this, SIGNAL(plotguess()));
	connect(&gofit, SIGNAL(clicked()), this, SIGNAL(dothefit()));
	connect(&goMCMCfit, SIGNAL(clicked()), this, SIGNAL(doMCMCfit()));
	connect(&gotransfervalues, SIGNAL(clicked()), this, SLOT(transferthevalues()));
	connect(&guessmoviebutton, SIGNAL(clicked()), this, SLOT(guessmovie()));
	connect(&addmoon, SIGNAL(clicked()), this, SLOT(newmoon()));
	connect(&addring, SIGNAL(clicked()), this, SLOT(newring()));
		
	connect(&Semimajoraxisbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateperiod()));
	connect(&Mstarbox, SIGNAL(textChanged(const QString&)), this, SLOT(updatesemimajor()));
	connect(&Mplanetbox, SIGNAL(textChanged(const QString&)), this, SLOT(updatesemimajor()));
	connect(&Periodbox, SIGNAL(textChanged(const QString&)), this, SLOT(updatesemimajor()));
	
	connect(&Semimajoraxisbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateimpactparameter()));
	connect(&Rstarbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateimpactparameter()));
	connect(&inclinationbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateimpactparameter()));
	connect(&Eccentricitybox, SIGNAL(textChanged(const QString&)), this, SLOT(updateimpactparameter()));
	connect(&Periapsisbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateimpactparameter()));
	connect(&bbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateinclination()));
	
	connect(&Rotationratecheck, SIGNAL(stateChanged(int)), this, SLOT(vsinicalculate()));
	connect(&Vsinicheck, SIGNAL(stateChanged(int)), this, SLOT(vsinicalculate()));
	connect(&Obliquitycheck, SIGNAL(stateChanged(int)), this, SLOT(vsinicalculate()));
	
	connect(&Rotationratebox, SIGNAL(textChanged(const QString&)), this, SLOT(updateoblateness()));
	connect(&Rstarbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateoblateness()));
	connect(&Mstarbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateoblateness()));
	connect(&Rstarbox, SIGNAL(textChanged(const QString&)), this, SLOT(vsinicalculate()));
	
	connect(&Rplanetcheck, SIGNAL(clicked()), this, SLOT(turnoffratio()));
	connect(&Rratiocheck, SIGNAL(clicked()), this, SLOT(turnoffradius()));
	connect(&Rplanetbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateratio()));
	connect(&Rstarbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateratio()));
	connect(&Rratiobox, SIGNAL(textChanged(const QString&)), this, SLOT(updateradius()));
}

void valuespanel::turnoffratio() {Rratiocheck.setChecked(false);}
void valuespanel::turnoffradius() {Rplanetcheck.setChecked(false);}
void valuespanel::updateratio()
{
	double Rjup_Rsun(71492./695500.);
	double Rstar(str2double(Rstarbox.text().toStdString()));
	double Rplanet(str2double(Rplanetbox.text().toStdString()));
	disconnect(&Rratiobox, 0, this, 0);
	Rratiobox.setText(QString::fromStdString(double2fstr(Rjup_Rsun*Rplanet/Rstar)));
	connect(&Rratiobox, SIGNAL(textChanged(const QString&)), this, SLOT(updateradius()));
}
void valuespanel::updateradius()
{
	double Rjup_Rsun(71492./695500.);
	double Rstar(str2double(Rstarbox.text().toStdString()));
	double Rratio(str2double(Rratiobox.text().toStdString()));
	disconnect(&Rplanetbox, 0, this, 0);
	Rplanetbox.setText(QString::fromStdString(double2fstr(Rstar*Rratio/Rjup_Rsun)));
	connect(&Rplanetbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateratio()));
	
}

void valuespanel::updateperiod()
{
	double a(str2double(Semimajoraxisbox.text().toStdString())*1.496e11); // convert AU to m
	double M(str2double(Mstarbox.text().toStdString())*1.9891e30); // convert Msun to kg
	M += str2double(Mplanetbox.text().toStdString())*1.8986e27; // convert MJup to kg
	double P; 
	P = 2.*Jcrap::pi*sqrt(a*a*a/6.673e-11/M)/86400.;
	disconnect(&Periodbox, 0, 0, 0);
	Periodbox.setText(QString::fromStdString(double2str(P,19)));
	connect(&Periodbox, SIGNAL(textChanged(const QString&)), this, SLOT(updatesemimajor()));
}

void valuespanel::updatesemimajor()
{
	double P(str2double(Periodbox.text().toStdString())*86400.); // convert days to seconds
	double M(str2double(Mstarbox.text().toStdString())*1.9891e30); // convert Msun to kg
	M += str2double(Mplanetbox.text().toStdString())*1.8986e27; // convert MJup to kg
	double a;
	a = pow(6.673e-11*M*P*P/2./2./Jcrap::pi/Jcrap::pi,1./3.);
	disconnect(&Semimajoraxisbox, 0, 0, 0);
	Semimajoraxisbox.setText(QString::fromStdString(float2str(a/1.496e11,19)));
	//connect(&Semimajoraxisbox, SIGNAL(textChanged(const QString&)), this, SLOT(updatemass()));
	connect(&Semimajoraxisbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateperiod()));
	
}

void valuespanel::updateimpactparameter()
{
	double ratio(149597870.7/6.959910e5);
	double r(str2double(Semimajoraxisbox.text().toStdString())*ratio);  // fix later for eccentricity!
	double R_star(str2double(Rstarbox.text().toStdString()));
	double i(str2double(inclinationbox.text().toStdString())/180.*Jcrap::pi);
		
	
	double b(cos(i)*r/R_star);
	if (b>-2. && b<2.) {
		
		disconnect(&bbox, 0, 0, 0);
		bbox.setText(QString::fromStdString(double2fstr(b, 12)));	
		connect(&bbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateinclination()));
	}
}

void valuespanel::updateinclination()
{
	double ratio(149597870.7/6.959910e5);
	double r(str2double(Semimajoraxisbox.text().toStdString())*ratio);  // fix later for eccentricity!
	double R_star(str2double(Rstarbox.text().toStdString()));
	double b(str2double(bbox.text().toStdString()));
		
	
	double i(acos(R_star*b/r)*180./Jcrap::pi);
	if (i>=0. && i<=180.) {
		
		disconnect(&inclinationbox, 0, 0, 0);
		inclinationbox.setText(QString::fromStdString(double2fstr(i, 12)));	
		connect(&inclinationbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateimpactparameter()));
	}
}


void valuespanel::sett0(string t)
{
	Tcbox.clear(); 
	Tcbox.insert(QString::fromStdString(t)); 
	parent->cropvisual(); 
	parent->cropvisual();
}

value valuespanel::starmass()
{
	value answer(str2double(Mstarbox.text().toStdString()), "M_Sun");
	return answer;
}

value valuespanel::starradius()
{
	value answer(str2double(Rstarbox.text().toStdString()), "R_Sun");
	return answer;
}

void valuespanel::nothing()
{
	cout << "nothing\n";
}

QSize valuespanel::sizeHint() const
{	
	return QSize(900,300);
}

std::vector<double> valuespanel::values()
{
//	cout << "IN VALUES\n";
	std::vector<double> a;
	a.resize(transitfunc::paramnumber());
	a[0] = str2double(Rstarbox.text().toStdString());
	a[1] = str2double(Rplanetbox.text().toStdString());
	a[2] = str2double(inclinationbox.text().toStdString())/180.*3.1415926535897932384;
	a[3] = str2double(limb0box.text().toStdString());
	a[4] = str2double(limb1box.text().toStdString());
	a[5] = str2double(Mstarbox.text().toStdString());
	a[6] = str2double(Periodbox.text().toStdString()); 
			/*pow(pow(str2double(Periodbox.text().toStdString())*86400., 2.)*6.67e-11*
			(a[5]*1.9891e30+a[31]*1.8986e27)
			/(2.*Jcrap::pi)/(2.*Jcrap::pi), 1./3.)/1.496e11;*/
	a[7] = 0.; // planet oblateness
	a[8] = str2double(Rratiobox.text().toStdString());
	a[9] = 0.; // unused 
	if (Ringboxes.size()>=1) a[10]= str2double(Ringboxes.at(0)->Obliquitytext.text().toStdString())/180.*3.1415926535897932384;
	else a[10]= 0.; // planet obliquity
	a[11]= str2double(Tcbox.text().toStdString());
	a[12]= str2double(F0box.text().toStdString());
	if (Ringboxes.size()>=1) a[13]= str2double(Ringboxes.at(0)->Azimuthtext.text().toStdString())/180.*3.1415926535897932384;
	else a[13]= 0.; // planet pole azimuthal angle
	a[14]= 0.; // unused
	a[15]= str2double(Azimuthalanglebox.text().toStdString());
	a[16]= str2double(Rotationratebox.text().toStdString());  
	a[17]= str2double(Obliquitybox.text().toStdString());
	a[18]= str2double(Vsinibox.text().toStdString());
	a[19]= str2double(Eccentricitybox.text().toStdString());
	a[20]= str2double(Periapsisbox.text().toStdString())/180.*Jcrap::pi;
	if (Moonboxes.size()>=1) {
		a[21]= str2double(Moonboxes.at(0)->Rmoonbox.text().toStdString());
		a[22]= str2double(Moonboxes.at(0)->rhomoonbox.text().toStdString());
		a[23]= str2double(Moonboxes.at(0)->amoonbox.text().toStdString());
		a[24]= str2double(Moonboxes.at(0)->ascendingmoonbox.text().toStdString())/180.*Jcrap::pi;
		a[25]= str2double(Moonboxes.at(0)->tperimoonbox.text().toStdString());
	}
	if (Moonboxes.size()>=2) {
		a[26]= str2double(Moonboxes.at(1)->Rmoonbox.text().toStdString());
		a[27]= str2double(Moonboxes.at(1)->rhomoonbox.text().toStdString());
		a[28]= str2double(Moonboxes.at(1)->amoonbox.text().toStdString());
		a[29]= str2double(Moonboxes.at(1)->ascendingmoonbox.text().toStdString())/180.*Jcrap::pi;
		a[30]= str2double(Moonboxes.at(1)->tperimoonbox.text().toStdString());
	}
	a[31]= str2double(Mplanetbox.text().toStdString());
	a[32]= str2double(Polartempbox.text().toStdString());
	a[33]= str2double(Betabox.text().toStdString());
	if (Ringboxes.size()>=1) {
		a[34]= str2double(Ringboxes.at(0)->Rinnertext.text().toStdString());
		a[35]= str2double(Ringboxes.at(0)->Routertext.text().toStdString());
		a[36]= str2double(Ringboxes.at(0)->Tautext.text().toStdString());
	} else a[34]=a[35]=a[36]=0.;
	if (Ringboxes.size()>=2) {
		a[37]= str2double(Ringboxes.at(1)->Rinnertext.text().toStdString());
		a[38]= str2double(Ringboxes.at(1)->Routertext.text().toStdString());
		a[39]= str2double(Ringboxes.at(1)->Tautext.text().toStdString());
	} else a[37]=a[38]=a[39]=0.;
	if (Planetboxes.size()>=1) {
		a[40]= str2double(Planetboxes.at(0)->Rplanettext.text().toStdString());
		a[41]=str2double(Planetboxes.at(0)->itext.text().toStdString())*Jcrap::pi/180.;
		a[42]= str2double(Planetboxes.at(0)->Ptext.text().toStdString());
		a[43]= str2double(Planetboxes.at(0)->T0text.text().toStdString());
		a[44]= str2double(Planetboxes.at(0)->asctext.text().toStdString());  // gets converted to rad in transit::Transit::Transit(vector<double>)
		a[45]= str2double(Planetboxes.at(0)->etext.text().toStdString());
		a[46]= str2double(Planetboxes.at(0)->peritext.text().toStdString())/180.*Jcrap::pi;
		a[47]= str2double(Planetboxes.at(0)->albedotext.text().toStdString());
		a[48]= str2double(Planetboxes.at(0)->temptext.text().toStdString());
		a[49]= str2double(Planetboxes.at(0)->Mtext.text().toStdString());
				
		//cout << "Second planet in values() radius = " << a[40] << "\n";
		//cout << "Second planet in values() inclination = " << a[41] << "\n";
		//cout << "Second planet in values() b = " << b << "\n";
		//cout << "Second planet in values() r = " << r << "\n";
		//cout << "Second planet in values() a = " << semimajor.convert("AU") << "\n";
		
	} else {
		a[40]= 0.;
		a[41]= 0.;
		a[42]= 0.;
		a[43]= 0.;
		a[44]= 0.;
		a[45]= 0.;
		a[46]= 0.;
		a[47]= 0.;
		a[48]= 0.;
		a[49]= 0.;
		
	}
	a[50]= str2double(starMOIbox.text().toStdString());
	cout << "set MOI to " << a[50] << "\n";
	
	return a;
}

std::vector<int> valuespanel::tobefit()
{
	std::vector<int> ia;
	ia.resize(transitfunc::paramnumber());
	ia[0] = Rstarcheck.isChecked();
	ia[1] = Rplanetcheck.isChecked();
	ia[2] = inclinationcheck.isChecked();
	ia[3] = limb0check.isChecked();
	ia[4] = limb1check.isChecked();
	ia[5] = Mstarcheck.isChecked();
	ia[6] = Periodcheck.isChecked();
	ia[7] = 0;  // planet oblateness
	ia[8] = Rratiocheck.isChecked();
	ia[9] = 0;
	if (Ringboxes.size()>=1) ia[10] = Ringboxes.at(0)->Obliquitycheck.isChecked();  // planet obliquity
	ia[11]= Tccheck.isChecked();
	ia[12]= F0check.isChecked();
	if (Ringboxes.size()>=1) ia[13] = Ringboxes.at(0)->Azimuthcheck.isChecked();  // planet obliquity
	ia[14]= 0;
	ia[15]= Azimuthalanglecheck.isChecked();
	ia[16]= Rotationratecheck.isChecked(); 
	ia[17]= Obliquitycheck.isChecked();
	ia[18]= Vsinicheck.isChecked();
	ia[19]= Eccentricitycheck.isChecked();
	ia[20]= Periapsischeck.isChecked();
	if (Moonboxes.size()>=1) {
		ia[21]= Moonboxes.at(0)->Rmooncheck.isChecked();
		ia[22]= Moonboxes.at(0)->rhomooncheck.isChecked();
		ia[23]= Moonboxes.at(0)->amooncheck.isChecked();
		ia[24]= Moonboxes.at(0)->ascendingmooncheck.isChecked();
		ia[25]= Moonboxes.at(0)->tperimooncheck.isChecked();
	}
	if (Moonboxes.size()>=2) {
		ia[26]= Moonboxes.at(1)->Rmooncheck.isChecked();
		ia[27]= Moonboxes.at(1)->rhomooncheck.isChecked();
		ia[28]= Moonboxes.at(1)->amooncheck.isChecked();
		ia[29]= Moonboxes.at(1)->ascendingmooncheck.isChecked();
		ia[30]= Moonboxes.at(1)->tperimooncheck.isChecked();
	}
	ia[31]= Mplanetcheck.isChecked();
	ia[32]= Polartempcheck.isChecked();
	ia[33]= Betacheck.isChecked();
	if (Ringboxes.size()>=1) {
		ia[34]= Ringboxes.at(0)->Rinnercheck.isChecked();
		ia[35]= Ringboxes.at(0)->Routercheck.isChecked();
		ia[36]= Ringboxes.at(0)->Taucheck.isChecked();
	} else ia[34]=ia[35]=ia[36]=0;
	if (Ringboxes.size()>=2) {
		ia[37]= Ringboxes.at(1)->Rinnercheck.isChecked();
		ia[38]= Ringboxes.at(1)->Routercheck.isChecked();
		ia[39]= Ringboxes.at(1)->Taucheck.isChecked();
	} else ia[37]=ia[38]=ia[39]=0;
	if (Planetboxes.size()>=1) {
		ia[40]= Planetboxes.at(0)->Rplanetcheck.isChecked();
		ia[41]= Planetboxes.at(0)->icheck.isChecked();
		ia[42]= Planetboxes.at(0)->Pcheck.isChecked();
		ia[43]= Planetboxes.at(0)->T0check.isChecked();
		ia[44]= Planetboxes.at(0)->asccheck.isChecked();
		ia[45]= Planetboxes.at(0)->echeck.isChecked();
		ia[46]= Planetboxes.at(0)->pericheck.isChecked();
		ia[47]= Planetboxes.at(0)->albedocheck.isChecked();
		ia[48]= Planetboxes.at(0)->tempcheck.isChecked();
		ia[49]= Planetboxes.at(0)->Mcheck.isChecked();
	} else {
		ia[40]= 0;
		ia[41]= 0;
		ia[42]= 0;
		ia[43]= 0;
		ia[44]= 0;
		ia[45]= 0;
		ia[46]= 0;
		ia[47]= 0;
		ia[48]= 0;
		ia[49]= 0;
	}
	ia[50]= starMOIcheck.isChecked();
	
	return ia;
}

string dbl2str(double a)
{
	char outcstr[80];
	sprintf(outcstr, "%.3lf", a);  // used to have a \0 after the lf -- deleted to get rid of warning
	return string(outcstr);
}

void valuespanel::loadfit(pair<vector<double>,double> infit)
{
	Fit = infit;
	vector<int> ia(tobefit());  // which values were fit for
	
	if (ia[0]) fitRstar.setText(QString::fromStdString(double2fstr(Fit.first[0], 9)+string(" R_Sun")));
	else fitRstar.setText("        R_Sun");	
		
	if (ia[1]) fitRplanet.setText(QString::fromStdString(double2fstr(Fit.first[1], 9)+string(" R_Jup")));
	else fitRplanet.setText("        R_Jup");	

	if (ia[2]) fitinclination.setText(QString::fromStdString(double2fstr(Fit.first[2]*180./Jcrap::pi,9)+string(" deg")));
	else fitinclination.setText("        deg");	

	if (ia[3]) fitlimb0.setText(QString::fromStdString(double2fstr(Fit.first[3],9)));
	else fitlimb0.setText("        ");
	
	if (ia[4]) fitlimb1.setText(QString::fromStdString(double2fstr(Fit.first[4],9)));
	else fitlimb1.setText("        ");	
	
	if (ia[11]) fitTc.setText(QString::fromStdString(double2fstr(Fit.first[11],9)+string(" sec")));
	else fitTc.setText("        sec");
	
	if (ia[5]) fitMstar.setText(QString::fromStdString(double2str(Fit.first[5],9)+string(" M_Sun")));
	else fitMstar.setText("        ");
	
	if (ia[6]) fitPeriod.setText(QString::fromStdString(double2str(Fit.first[6]/86400.,9)+string(" days")));
	else fitPeriod.setText("        days");
	
	if (ia[12]) fitF0.setText(QString::fromStdString(double2fstr(Fit.first[12], 9)+string("")));
	else fitF0.setText("        ");
	
//	if (ia[15]) fit;
}

void valuespanel::transferthevalues()
{
	if (fitRstar.text().toStdString()[0] != ' ')
		Rstarbox.setText(fitRstar.text().left(fitRstar.text().toStdString().find(" ")));
	if (fitRplanet.text().toStdString()[0] != ' ')
		Rplanetbox.setText(fitRplanet.text().left(fitRplanet.text().toStdString().find(" ")));
	if (fitinclination.text().toStdString()[0] != ' ')
		inclinationbox.setText(fitinclination.text().left(fitinclination.text().toStdString().find(" ")));
	if (fitlimb0.text().toStdString()[0] != ' ')
		limb0box.setText(fitlimb0.text().left(fitlimb0.text().toStdString().find(" ")));
	if (fitlimb1.text().toStdString()[0] != ' ')
		limb1box.setText(fitlimb1.text().left(fitlimb1.text().toStdString().find(" ")));
	if (fitTc.text().toStdString()[0] != ' ')
		Tcbox.setText(fitTc.text().left(fitTc.text().toStdString().find(" ")));
	if (fitMstar.text().toStdString()[0] != ' ')
		Mstarbox.setText(fitMstar.text().left(fitMstar.text().toStdString().find(" ")));
	if (fitPeriod.text().toStdString()[0] != ' ')
		Periodbox.setText(fitPeriod.text().left(fitPeriod.text().toStdString().find(" ")));
	if (fitF0.text().toStdString()[0] != ' ')
		F0box.setText(fitF0.text().left(fitF0.text().toStdString().find(" ")));
	
}


void valuespanel::vsinicalculate()
{
	bool a(Rotationratecheck.isChecked());
	bool b(Obliquitycheck.isChecked());
	bool c(Vsinicheck.isChecked());

	if ((a==TRUE && b==FALSE && c==FALSE)  || 
		 (a==FALSE && c==FALSE && b==TRUE)  || 
		 (a==FALSE && b==FALSE && c==TRUE)  || 
		 (a==FALSE && b==FALSE && c==FALSE)) {
		return;
	}

		 
	else if (a==TRUE && b==TRUE && c==FALSE) //calculate VSin(i)
	{
		double R(str2double(Rstarbox.text().toStdString())*695500); //converts Rstar to km
		double O(str2double(Rotationratebox.text().toStdString())*3600); //converts Rotation rate to s
		double q(str2double(Obliquitybox.text().toStdString())*Jcrap::pi/180); //converts obliquity to radians
		double V;
		V = Jcrap::pi*2.*R*cos(q)/O;
		Vsinibox.setText(QString::fromStdString(float2str(V,19))); //replaces text with the correct VSin(i)
		
	}
	else if (a==TRUE && c==TRUE && b==FALSE) //calculate Obliquity
	{
		double R(str2double(Rstarbox.text().toStdString())*695500); //converts Rstar to km
		double O(str2double(Rotationratebox.text().toStdString())*3600); //converts Rotation rate to s
		double V(str2double(Vsinibox.text().toStdString()));
		double q;
		q = 180/Jcrap::pi *acos(V*O/(2.*Jcrap::pi*R)); //calculates obliquity in degrees
		Obliquitybox.setText(QString::fromStdString(float2str(q,19)));
		
	}
	else if (b==TRUE && c==TRUE && a==FALSE) //calculate rotation rate
	{
		double R(str2double(Rstarbox.text().toStdString())*695500); //converts Rstar to km	
		double q(str2double(Obliquitybox.text().toStdString())*Jcrap::pi/180); //converts obliquity to radians
		double V(str2double(Vsinibox.text().toStdString()));
		double O;
		O = 2.*Jcrap::pi*R*cos (q)/(V*3600); //calculates rotation rate in hours
		Rotationratebox.setText(QString::fromStdString(float2str(O,19)));
		
	}
	else if (a==TRUE && b==TRUE && c==TRUE) //if everyone is clicked then default back to original values
	{
		Rotationratebox.setText("0");
		Obliquitybox.setText("0");
		Vsinibox.setText("0");
		
	}
}

void valuespanel::updateoblateness()
{
	double O(str2double(Rotationratebox.text().toStdString())*3600);//convert hr to sec
	double R(str2double(Rstarbox.text().toStdString())*695500000);//convert solar radius to m
	double M(str2double(Mstarbox.text().toStdString())*1.9891e30);//convert solar mass to kg
	double f;
	f = (2*Jcrap::pi)*(2*Jcrap::pi)/O/O*R*R*R/2/6.671e-11/M;
	Oblatenessbox.setText(QString::fromStdString(float2str(f,19)));
}

void valuespanel::updatemass()
{
	double a(str2double(Semimajoraxisbox.text().toStdString())*1.496e11); //convert AU to m
	double P(str2double(Periodbox.text().toStdString())*86400); //convert hrs to seconds
	double M;
	M = a*a*a/6.671e-11*4*Jcrap::pi/P/P; //mass is in kg
	M = M/1.9891e30; //mass in mass of sun
	disconnect(&Mstarbox, 0,0,0);
	Mstarbox.setText(QString::fromStdString(float2str(M,19)));
	connect(&Mstarbox, SIGNAL(textChanged(const QString&)), this, SLOT(updatesemimajor()));
	connect(&Mstarbox, SIGNAL(textChanged(const QString&)), this, SLOT(updateoblateness()));
}

double valuespanel::periodvariable()
{
	double P;
	if (focusplanet()==0)
		P = str2double(Periodbox.text().toStdString());
	else
		P = str2double(Planetboxes.at(focusplanet()-1)->Ptext.text().toStdString());
	return P;
}

double valuespanel::Tcvariable()
{
	double t;
	if (focusplanet()==0)
		t = str2double(Tcbox.text().toStdString());
	else
		t = str2double(Planetboxes.at(focusplanet()-1)->T0text.text().toStdString());
	return t;	
}

void valuespanel::newmoon()
{
	moonpanel *m(new moonpanel(Moonboxes.size()));
	Moonboxes.push_back(m);
	cout << "New moon #" << m->moonnumber << "\n";
	m->show();
}


moonpanel::moonpanel(int moonno) :
		Q3HBox(0),
		parametervalues(this),
		boxtitle("Moon number ", &parametervalues),
		Rmoon(&parametervalues),
		Rmooncheck("R_moon (R_Earth)", &Rmoon),
		Rmoonbox("1.00", &Rmoon),
		rhomoon(&parametervalues),
		rhomooncheck("rho_moon (g/cm^3)", &rhomoon),
		rhomoonbox("5.52", &rhomoon),
		amoon(&parametervalues),
		amooncheck("a_moon (R_Jup)", &amoon),
		amoonbox("5.37", &amoon),
		ascendingmoon(&parametervalues),
		ascendingmooncheck("ascending (deg)", &ascendingmoon),
		ascendingmoonbox("180.00", &ascendingmoon),
		tperimoon(&parametervalues),
		tperimooncheck("tperi", &tperimoon),
		tperimoonbox("0.00", &tperimoon),
		moonnumber(moonno)
{
	char instr[80];
	sprintf(instr, "Moon number %d", moonno);	
	boxtitle.setText(instr);
}

void valuespanel::newring()
{
	ringpanel *m(new ringpanel(Ringboxes.size()));
	connect(m, SIGNAL(ringpanelclosed(ringpanel*)), this, SLOT(ringpanelclosed(ringpanel*)));
	Ringboxes.push_back(m);
	cout << "New ring #" << m->ringnumber << "\n";
	m->show();
}

ringpanel::ringpanel(int ringno) :
		Q3HBox(0),
		parametervalues(this),
		boxtitle("Ring number ", &parametervalues),
		Rinnerbox(&parametervalues),
		Rinnercheck("R_inner (R_Jup)", &Rinnerbox),
		Rinnertext("1.00", &Rinnerbox),
		Routerbox(&parametervalues),
		Routercheck("R_outer (R_Jup)", &Routerbox),
		Routertext("2.00", &Routerbox),
		Taubox(&parametervalues),
		Taucheck("Tau", &Taubox),
		Tautext("1.00", &Taubox),
		Obliquitybox(&parametervalues),
		Obliquitycheck("obliquity (deg)", &Obliquitybox),
		Obliquitytext("30.0", &Obliquitybox),
		Azimuthbox(&parametervalues),
		Azimuthcheck("azimuth (deg)", &Azimuthbox),
		Azimuthtext("90.00", &Azimuthbox),
		ringnumber(ringno)
{
	char instr[80];
	sprintf(instr, "Ring number %d", ringno);	
	boxtitle.setText(instr);
}

moviedialog::moviedialog(valuespanel& inpanel) : Q3VBox(0, "Movie Dialog"),
//	thisdialogarea(this),
	title("Generate Transit Movie", this),
	resolution(this),
	resolutionlabel("Pixels across:", &resolution),
	resolutionbox("100", &resolution),
	starttime(this),
	startimelabel("Start time:", &starttime),
	starttimebox("-30000", &starttime),
	endtime(this),
	endtimelabel("End time:", &endtime),
	endtimebox("30000", &endtime),
	frames(this),
	frameslabel("Frames:", &frames),
	framesbox("30", &frames),
	outputfile(this),
	outputfilelabel("Output file name:", &outputfile),
	outputfilebox("guessmovie.Jcube", &outputfile),
	excludebox(this),
	excludecheck("Exclude non-inferior-conjunction", &excludebox),
	buttonsarea(this),
	gobutton("Go", &buttonsarea),
	cancelbutton("Cancel", &buttonsarea)
{
	v = &inpanel;
	setCaption("Generate Transit Movie");
	
	
	connect(&gobutton, SIGNAL(clicked()), this, SLOT(gomovie()));
	connect(&cancelbutton, SIGNAL(clicked()), this, SLOT(cancelmovie()));

	
}

void moviedialog::starttimeset(string s)
{
	starttimebox.setText(QString::fromStdString(s));
}

void moviedialog::endtimeset(string e)
{
	endtimebox.setText(QString::fromStdString(e));
}

void moviedialog::gomovie()
{
	v->guessmovie(1, str2int(resolutionbox.text().toStdString()), str2double(starttimebox.text().toStdString()),
			str2double(endtimebox.text().toStdString()), str2int(framesbox.text().toStdString()), outputfilebox.text().toStdString());
}

void moviedialog::cancelmovie()
{
	v->guessmovie(0);
}

bool moviedialog::excludefaraways()
{
	return excludecheck.isChecked();
}

void valuespanel::guessmovie(int fork, int pixels, double starttime, 
		double endtime, int frames, string outputname)
{
	static moviedialog *m(0);

// if m is empty, on firstrun or after the window has closed, make a new window
	if (m==0) { 
		m=new moviedialog(*this);
		
		m->starttimeset(double2str(parent->timerange().first));
		m->endtimeset(double2str(parent->timerange().second));
		
		m->show();
	} else {
// if a window is already open, make the movie if fork=1, else just close the window
		if (fork==1) {
			transit::Transit t(values(), pixels, transit::CARTESIAN);
			t.precession(getparent()->parent()->precession());
			t.time(starttime);
			cube moviecube(t.movie(starttime, endtime, fabs(endtime-starttime)/(frames), 0, m->excludefaraways()));
			moviecube.write(outputname);
			moviecube.astype(gif).write(outputname);
		}
		
		delete m;
		m=0;
	}
}

void valuespanel::setparent(fitter* f)
{
	parent=f;
}

double valuespanel::impactparameter(unsigned int n)
{
	double answer(0.);
	if (n==0) answer=str2double(bbox.text().toStdString());
	else answer=str2double(Planetboxes.at(n-1)->btext.text().toStdString());
	return answer;
}

void valuespanel::newplanet()
// created 2014 May 20 JWB
{
	planetpanel *p(new planetpanel(Planetboxes.size()+1, this));
	Planetboxes.push_back(p);
	cout << "New Planet #" << p->planetnumber << "\n";
	p->show();
}

planetpanel::planetpanel(int planetno, valuespanel *vpanel) :
		Q3HBox(0),
		parametervalues(this),
		titlebox(&parametervalues),
		boxtitle("Moon number ", &titlebox),
		focuscheck("focus", &titlebox),
		Rplanetbox(&parametervalues),
		Rplanetcheck("R_planet (R_Jup)", &Rplanetbox),
		Rplanettext("1.00", &Rplanetbox),
		ibox(&parametervalues),
		icheck("Inclination (deg)", &ibox),
		itext("90", &ibox),
		bbox(&parametervalues),
		blabel("Impact Parameter b", &bbox),
		btext("0.5", &bbox),
		Pbox(&parametervalues),
		Pcheck("Period (days)", &Pbox),
		Ptext("3.52", &Pbox),
		T0box(&parametervalues),
		T0check("Time of Peri Passage (s)", &T0box),
		T0text("0.00", &T0box),
		ascbox(&parametervalues),
		asccheck("Ascending Node", &ascbox),
		asctext("0.00", &ascbox),		
		ebox(&parametervalues),
		echeck("Eccentricity", &ebox),
		etext("0.00", &ebox),
		peribox(&parametervalues),
		pericheck("Long of Periastron (deg)", &peribox),
		peritext("90.0", &peribox),
		albedobox(&parametervalues),
		albedocheck("Albedo", &albedobox),
		albedotext("0.0", &albedobox),
		tempbox(&parametervalues),
		tempcheck("Planet Temperature (K)", &tempbox),
		temptext("0.00", &tempbox),
		Mbox(&parametervalues),
		Mcheck("Planet Mass (M_Jup)", &Mbox),
		Mtext("6.953356e-310", &Mbox),
		planetnumber(planetno),
		parent(vpanel)
// created 2014 May 20 JWB
{
	char instr[80];
	sprintf(instr, "Planet number %d", planetno);	
	boxtitle.setText(instr);
	
	connect(&itext, SIGNAL(textEdited(const QString &)), this, SLOT(update_b(const QString &)));
	connect(&btext, SIGNAL(textEdited(const QString &)), this, SLOT(update_i(const QString &)));

	update_i(QString("0.5"));
}

unsigned int valuespanel::focusplanet()
{
	unsigned int answer(0);
	
	for (unsigned int i(0);i<Planetboxes.size();i++)
		if (Planetboxes.at(i)->focuscheck.isChecked())
			answer = i+1;
	
	return answer;
}

void ringpanel::closeEvent(QCloseEvent *event)
{
	emit ringpanelclosed(this);
	event->accept();
}

void valuespanel::ringpanelclosed(ringpanel *pringpanel)
{
	vector<ringpanel*> newRingboxes;
	for (unsigned int j(0);j<Ringboxes.size();j++)
		if (Ringboxes.at(j)!=pringpanel)
			newRingboxes.push_back(Ringboxes.at(j));
	Ringboxes = newRingboxes;
}

		
void planetpanel::update_b(const QString &)
{
	value G(6.673e-11, "s^-2 m^3 kg^-1");
	value period(str2double(Ptext.text().toStdString()), "day");
	value starmass(parent->starmass());
	value semimajor(starmass*G*period*period/(4.*Jcrap::pi*Jcrap::pi));
	semimajor=semimajor.pow(1./3.).convert("m kg s");
	cout << "in update_b \n";
	double e(str2double(etext.text().toStdString()));
	angle perilong(str2double(peritext.text().toStdString()), angle::DEG);
	value r(semimajor*(1.-e*e)/(1+e*perilong.cos()));
	value Rstar(parent->starradius());
	angle i(str2double(itext.text().toStdString()), angle::DEG);
	
//	a[41]= acos(b*(value(a[0], "R_Sun")/r).convert("m kg s"));
//	double b(str2double(Planetboxes.at(0)->btext.text().toStdString()));
	value b(r*i.cos()/Rstar);
	b=b.simplify("m g s");
	b=b.convert("m g s");
	cout << "b is equal to " << b << "\n";
	
	btext.setText(QString(double2str(double(b)).c_str()));
	
}	

void planetpanel::update_i(const QString &)
{
	value G(6.673e-11, "s^-2 m^3 kg^-1");
	value period(str2double(Ptext.text().toStdString()), "day");
	value starmass(parent->starmass());
	value semimajor(starmass*G*period*period/(4.*Jcrap::pi*Jcrap::pi));
	semimajor=semimajor.pow(1./3.).convert("m kg s");
	cout << "in update_i \n";
	double e(str2double(etext.text().toStdString()));
	angle perilong(str2double(peritext.text().toStdString()), angle::DEG);
	value r(semimajor*(1.-e*e)/(1+e*perilong.cos()));
	value Rstar(parent->starradius());
	double b(str2double(btext.text().toStdString()));
			
	angle i(acos((Rstar*b/r).convert("m g s")), angle::RAD);
	
	itext.setText(QString(double2str(double(i.degrees())).c_str()));
}

vector<planetpanel*> & valuespanel::planetboxes()
{
	return Planetboxes;
}

void valuespanel::setRplanet(unsigned int n, double r)
{
	setRplanet(n,double2fstr(r));
}

void valuespanel::setRplanet(unsigned int n, string r)
{
	Planetboxes.at(n-1)->Rplanettext.clear(); 
	Planetboxes.at(n-1)->Rplanettext.insert(QString::fromStdString(r));
}

void valuespanel::seteccentricity(unsigned int n, double e)
{
	seteccentricity(n,double2fstr(e));
}

void valuespanel::seteccentricity(unsigned int n, string e)
{
	Planetboxes.at(n-1)->etext.clear(); 
	Planetboxes.at(n-1)->etext.insert(QString::fromStdString(e));
	Planetboxes.at(n-1)->update_i(Planetboxes.at(n-1)->btext.text());
}

void valuespanel::setperiod(unsigned int n, double P)
{
	setperiod(n,double2fstr(P));
}

void valuespanel::setperiod(unsigned int n, string P)
{
	Planetboxes.at(n-1)->Ptext.clear(); 
	Planetboxes.at(n-1)->Ptext.insert(QString::fromStdString(P));
	Planetboxes.at(n-1)->update_i(Planetboxes.at(n-1)->btext.text());
}


void valuespanel::setb(unsigned int n, double b)
{
	setb(n,double2fstr(b));
}

void valuespanel::setb(unsigned int n, string b)
{
	Planetboxes.at(n-1)->btext.clear(); 
	Planetboxes.at(n-1)->btext.insert(QString::fromStdString(b));
	Planetboxes.at(n-1)->update_i(Planetboxes.at(n-1)->btext.text());
}

void valuespanel::sett0(unsigned int n, double t0)
{
	sett0(n,double2fstr(t0));
}

void valuespanel::sett0(unsigned int n, string t0)
{
	Planetboxes.at(n-1)->T0text.clear(); 
	Planetboxes.at(n-1)->T0text.insert(QString::fromStdString(t0));
}

void valuespanel::setascnode(unsigned int n, double l)
{
	setascnode(n,double2fstr(l));
}

void valuespanel::setascnode(unsigned int n, string l)
{
	Planetboxes.at(n-1)->asctext.clear(); 
	Planetboxes.at(n-1)->asctext.insert(QString::fromStdString(l));
}

void valuespanel::setperiapsis(unsigned int n, double f)
{
	setperiapsis(n,double2fstr(f));
}

void valuespanel::setperiapsis(unsigned int n, string f)
{
	Planetboxes.at(n-1)->peritext.clear(); 
	Planetboxes.at(n-1)->peritext.insert(QString::fromStdString(f));
}


