#ifndef fitter_h
#define fitter_h

#include <qstring.h>
#include <q3hbox.h>
#include <q3vbox.h>
#include <qslider.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qsplitter.h>
#include <qlabel.h>
#include <qtimer.h>
#include <qtoolbutton.h>
#include <qscrollarea.h>

#include "../../Jcrap.h"
#include "../transitfit.h"

#include "plotspace.h"
#include "ctrlpanel.h"
#include "valuespanel.h"
//#include "transitfitter.h"

class transitfitter;
class oscillationdialog;

class fitter : public Q3VBox
{
	Q_OBJECT

public:
	fitter(QWidget *parent=0, const char *name=0);
	void load(string loadfilename);
	void add(string addfilename);
	void savefit(string savefilename);
	void saveimage(string saveimagename);
	
	pair<double, double> timerange();
	vector<pair<double, double> >& clicklocations() {return Clicklocations;}
	
	transitfitter* parent() {return Parent;}
	
	void changeepoch(double);
	void graphvalues(int);
	void redrawplotspace();
	
	cube generateperiodogram();
	
	pair<vector<double>, double> oscillationfit(cube);


public slots:
	void plotguess();
	void dothefit();
	void doMCMCfit();
	void folddata();
	void cropdata();
	void splicedata();
	void filterdata();
	void normalizedata();
	void cleandata();
	void bindata();
	void baselinesub();
	void baselinesub_go(int);
	void baselinesub_subtract();
	void oscillationsub();
	void oscillationsub_fit();
	void oscillationperiodogram();
	void oscillationsub_subtract();
	void oscillation_calculatefreqstability();
	void orbitchange(double);
	void orbitadd();
	void orbitsub();
	void transitnext();
	void transitprev();
	void timemult();
	void foldvisual();
	void cropvisual();
	void residualvisual();
	void exportdata();
	void exportfit();
	void exportresiduals();
	void coordinatevalues(pair<double,double>);
	void periodogram();
	void graphobliquity();
	void graphascendingnode();
	void graphinclination();
	void outputprecessioninfo();
	void newmoon();
	void newring();
	void newplanet();
		
private:
	transitfitter *Parent;

	Q3HBox			 		Topwindow;
	plotspace 				Plotspace;
	ctrlpanel				Ctrlpanel;
	valuespanel				Valuespanel;
	
	
	vector<pair<double, double> > Clicklocations;
	
	friend class MCMCwindow;
	
	oscillationdialog* Oscillationdialog;
};


class MCMCwindow : public Q3VBox
{
	Q_OBJECT
			
	public:
		MCMCwindow(fitter&);
		~MCMCwindow();
		
		void size(double);
		
	public slots:
		void runMCMC();
		void MCMCstep();
		void MCMCdisplayupdate();
		void sizeup();
		void sizedown();
		void exportfit();
	
	private:
		Q3HBox display_layout;
		Q3VBox parameters;
		Q3ButtonGroup parameterbuttongroup;
		vector<QRadioButton*> parameterbuttons;
		QLabel stepnumberlabel;
		QLabel chisqlabel;
		plotspace Plotspace;
		Q3HBox controls;
		QRadioButton stopbutton;
		QPushButton sizeupbutton, sizedownbutton;
		QLineEdit burninbox;
		QPushButton exportfitbutton;
		
		fitter *f;
		transit::Transit t;
		transitfunc Tfunc;

		QTimer realtimer;
				
		cube data;
		
		long long stepnumber;
		
		cube MarkovChain;
		
		double overall;
};


class baselinedialog : public Q3HBox
{
	Q_OBJECT
			
public:
	baselinedialog();
	
signals:
	void cancelled();
	void go(int);
	void subtract();
	
public slots:
	void go();
	
	
private:
	Q3VBox	vertitemsbox;
	QLabel	instructions;
	Q3HBox	polyorderbox;
	QLabel	polyorderlabel;
	QButtonGroup	polyorderbuttons;
	QRadioButton	poly0button, poly1button, poly2button, poly3button, poly4button;
	Q3HBox	outcomebox;
	QPushButton	fitbutton, subtractbutton, cancelbutton;
};



int freqindex(unsigned int num_amplitudes, int n);
int ampindex(unsigned int num_amplitudes, int n, int i);
int phaseindex(unsigned int num_amplitudes, int n);

class oscillationdialog : public Q3HBox
{
	Q_OBJECT
			
public:
	oscillationdialog();
	
	int number_of_frequencies();
	int number_of_amplitudes();
	vector<double> initialvalues();
	vector<int> parameterstobefit();
	
	int freqindex(int n) {return ::freqindex(number_of_amplitudes(), n);}
	int phaseindex(int n) {return ::phaseindex(number_of_amplitudes(), n);}
	int ampindex(int n, int i=0) {return ::ampindex(number_of_amplitudes(), n, i);}
	
	
	void periodogramcube(cube);
	cube periodogramcube();
	
signals:
	void cancelled();
	void fit_clicked();
	void subtract();
	void generateperiodogram();
	void calculatefreqstability();
	
	
public slots:
	void go();
	void freqchanged();
	void loadperiodogram();
	void populatefreqs();
	void loadfrequencies();
	void savefrequencies();
	
	
	
private:
	Q3VBox	vertitemsbox;
	QLabel	instructions;
	Q3HBox	frequencynumberbox;
	QLabel	frequencynumberlabel;
	QLineEdit frequencynumberedit;
	QLabel	amplitudenumberlabel;
	QLineEdit amplitudenumberedit;
	Q3HBox	guessgeneratebox;
	QPushButton	generateperiodobutton, loadperiodobutton, populatefreqsbutton;
	Q3HBox	toolsbox;
	QPushButton freqstabilitybutton, loadfreqsbutton, savefreqsbutton;
	QScrollArea	valuesscroll;
	QVBoxLayout scrolllayout;
	QWidget	initialvaluesbox;
	QVBoxLayout	initialvalueslayout;
	Q3HBox	averagefluxbox;
	QLabel	averagefluxlabel;
	QLineEdit averagefluxedit;
	vector<Q3HBox*> frequencyvaluesboxes;
	vector<QCheckBox*> frequencyfitcheckboxes;
	vector<QCheckBox*> amplitudefitcheckboxes;
	vector<QCheckBox*> phasefitcheckboxes;
	vector<QLabel*> frequencyvalueslabels;
	vector<QLabel*> amplitudevalueslabels;
	vector<QLabel*> phasevalueslabels;
	vector<QLineEdit*> frequencyvaluesedits;
	vector<QLineEdit*> amplitudevaluesedits;
	vector<QLineEdit*> phasevaluesedits;
	Q3HBox	outcomebox;
	QPushButton	fitbutton, subtractbutton, cancelbutton;
	
	cube Periodocube;
};

class oscillations_function : public Jcrap::multifunction<double>
{
	public:
		unsigned int num_frequencies;
		unsigned int num_amplitudes;
		double upper_range, lower_range;
		
		int freqindex(int n) {return ::freqindex(num_amplitudes, n);}
		int phaseindex(int n) {return ::phaseindex(num_amplitudes, n);}
		int ampindex(int n, int i=0) {return ::ampindex(num_amplitudes, n, i);}
		
		double amplitude(double x, int i) {
//			cout << "in amplitude("<<x<<","<<i<<")\n";
			double thisamplitude;
			if (num_amplitudes==1  ||  (upper_range-lower_range)==0.) 
				thisamplitude = a.at(ampindex(i,0));
			else {
				vector<double> exes(num_amplitudes);
				double gap_size((upper_range-lower_range)/double(num_amplitudes));
				double midpoint((upper_range+lower_range)/2.);
				for (unsigned int j(0);j<num_amplitudes;j++) {
					exes.at(j) = lower_range+gap_size/2.+double(j)*gap_size-midpoint;
				}
				thisamplitude = Jpolint(&exes[-1], &a.at(ampindex(i,-1)), num_amplitudes, x-midpoint).first;
			}
//			cout << "amp is " << thisamplitude<<"\n";
			return thisamplitude;
		}
        
		oscillations_function(int n, int amps=1) : Jcrap::multifunction<double>(n*(2+amps)+1){
			num_frequencies = n; 
			num_amplitudes = amps;
			param_names.at(0)=string("const_offset");
			for (unsigned int i=0;i<num_frequencies;i++) {
				param_names.at(freqindex(i)) = string("f_") + int2str(int(i));
				for (unsigned int j=0;j<num_amplitudes;j++)
					param_names.at(ampindex(i,j)) = string("a_") + int2str(int(i)) + string("#") + int2str(int(j));
				param_names.at(phaseindex(i)) = string("p_") + int2str(int(i));
			}
			skiperroranalysis=true;
			upper_range = lower_range = 0.;
			chidiffstop=1.e-5;
		}
                
		double the_function(double x, vector<double>& newa, unsigned int=0) {
			double answer(0.);
			a=newa;
			answer += a.at(0);		// this is the constant term
			for (unsigned int i=0;i<num_frequencies;i++)				
				answer += amplitude(x,i)*sin(2.*Jcrap::pi*x*a.at(freqindex(i))*1.e-6+a.at(phaseindex(i)));
			return answer;
		}
		
		vector<double> the_derivitives(double x, vector<double>& aa, unsigned int=0)
		{
			vector<double> answer(aa.size());
			
// evaluate the derivitives analytically, thus saving a metric assload of time.
                                             
			answer.at(0)=1.;
#pragma omp parallel for
			for (unsigned int i=0;i<num_frequencies;i++) {
				answer.at(freqindex(i)) = x*2.*Jcrap::pi*amplitude(x,i)*cos(2.*Jcrap::pi*x*a.at(freqindex(i))*1.e-6+a.at(phaseindex(i))) * 1.e-6; //convert to uHz
				if (num_amplitudes == 1)
					answer.at(ampindex(i,0)) = sin(2.*Jcrap::pi*x*a.at(freqindex(i))*1.e-6+a.at(phaseindex(i)));
				else {
// numerical -- slow
					for (unsigned int j(0);j<num_amplitudes;j++)
						answer.at(ampindex(i,j)) = aderiv(ampindex(i,j),x,aa,h.at(i),0);
// analytical -- wrong
/*					for (unsigned int j(0);j<num_amplitudes;j++) {
						answer.at(ampindex(i,j)) = sin(2.*Jcrap::pi*x*a.at(freqindex(i))*1.e-6+a.at(phaseindex(i)));
						cout << "old slope = " << answer.at(ampindex(i,j)) << ", ";
						if (a.at(ampindex(i,j))!=0.) {
							double oldavalue(a.at(ampindex(i,j)));
							double fullamp(amplitude(x,i));
							a.at(ampindex(i,j)) *= 1.001;
							double deltaamp(amplitude(x,i));
							a.at(ampindex(i,j)) = oldavalue;
							double contribution = (fullamp-deltaamp)/0.001;
							answer.at(ampindex(i,j)) *= contribution;		
						}
						cout << "new slope = " <<  answer.at(ampindex(i,j)) << ", ";
						cout << "numerical slope = " << aderiv(ampindex(i,j),x,aa,h.at(i),0) << "\n";
					}*/
				}

				answer.at(phaseindex(i)) = amplitude(x,i)*cos(2.*Jcrap::pi*x*a.at(freqindex(i))*1.e-6+a.at(phaseindex(i)));
			}
//			cout << "anal deriv\n";
					
			return answer;
		}
		
		double aconvert(vector<double>& a, vector<int>&, int n)
		{
			double answer(a.at(n));
//			cout << "in oscillations_function::aconvert(" << n << ")\n";
			for (int f(0);f<int(num_frequencies);f++) {
//				cout << "phaseindex("<<f<<") = " << phaseindex(f) << "\n";
//				cout << "ampindex("<<f<<") = " << ampindex(f) << "\n";
//				cout << "freqindex("<<f<<") = " << freqindex(f) << "\n";
				
				if (a.at(ampindex(f)) < 0) {
					for (int j(0);j<int(num_amplitudes);j++) a.at(ampindex(f,j))*=-1.;
					a.at(phaseindex(f)) += Jcrap::pi;
				}
				
				while (a.at(phaseindex(f)) > Jcrap::pi) a.at(phaseindex(f))-=2.*Jcrap::pi;
				while (a.at(phaseindex(f)) <-Jcrap::pi) a.at(phaseindex(f))+=2.*Jcrap::pi;
			}
//			cout << "Exiting aconvert\n";
			return answer;
		}
};


#endif
