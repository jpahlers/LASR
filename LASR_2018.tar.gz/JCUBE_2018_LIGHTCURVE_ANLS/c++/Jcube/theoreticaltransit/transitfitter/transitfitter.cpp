#include <qaction.h>
#include <q3popupmenu.h>
#include <qstring.h>
#include <q3filedialog.h>
#include <q3strlist.h>
#include <qapplication.h>

#include "transitfitter.h"

using namespace std;

transitfitter::transitfitter(QWidget *parent, const char *name, const char *startfile) 
	: Q3MainWindow(parent, name), 
	Fitter(this, "Fitter"), 
	FILEmenu(this), 
	DATAmenu(this), MODIFYmenu(this), SETTINGSmenu(this), GRAPHmenu(this)
{
	setCentralWidget(&Fitter);

	QAction loadAct(QString("&Load"), this);
	connect(&loadAct, SIGNAL(activated()),
		this, SLOT(loadfile()));
	if (startfile) Fitter.load(startfile);
	
// creating the menus
	loadAct.addTo(&FILEmenu);
	menuBar()->insertItem( "&File", &FILEmenu);
	
	FILEmenu.insertItem( "Load", this, SLOT( loadfile() ), Qt::CTRL + Qt::Key_L );
	FILEmenu.insertItem( "Add Data", this, SLOT( addfile() ), Qt::CTRL + Qt::Key_A );
	FILEmenu.insertItem( "Save Cube", this, SLOT( savefile() ), Qt::CTRL + Qt::Key_V );
	FILEmenu.insertItem( "Save Image", this, SLOT( saveimage() ), Qt::CTRL + Qt::Key_S );
	FILEmenu.insertItem( "Quit", this, SLOT( quit() ), Qt::CTRL + Qt::Key_Q );
	
// creating the data menu
	loadAct.addTo(&DATAmenu);
	menuBar()->insertItem( "&Data", &DATAmenu);
	
	DATAmenu.insertItem( "Fold", &Fitter, SLOT( folddata() ), Qt::CTRL + Qt::Key_F );
	DATAmenu.insertItem( "Crop", &Fitter, SLOT( cropdata() ), Qt::CTRL + Qt::Key_C );
	DATAmenu.insertItem( "Filter", &Fitter, SLOT( filterdata() ), Qt::CTRL + Qt::Key_I );
	DATAmenu.insertItem( "Normalize", &Fitter, SLOT( normalizedata() ), Qt::CTRL + Qt::Key_N );
	DATAmenu.insertItem( "Clean", &Fitter, SLOT( cleandata() ), Qt::CTRL + Qt::Key_E );
	DATAmenu.insertItem( "Bin", &Fitter, SLOT( bindata() ), Qt::CTRL + Qt::Key_B );
	DATAmenu.insertItem( "Baseline Subtract", &Fitter, SLOT( baselinesub() ));
	
	loadAct.addTo(&MODIFYmenu);
	menuBar()->insertItem( "&Modify", &MODIFYmenu);
	
	MODIFYmenu.insertItem( "+1 orbit", &Fitter, SLOT( orbitadd() ), Qt::CTRL + Qt::Key_Plus );
	MODIFYmenu.insertItem( "-1 orbit", &Fitter, SLOT( orbitsub() ), Qt::CTRL + Qt::Key_Minus );
	MODIFYmenu.insertItem( "Next Transit", &Fitter, SLOT( transitnext() ), Qt::CTRL + Qt::Key_Asterisk );
	MODIFYmenu.insertItem( "Prev Transit", &Fitter, SLOT( transitprev() ), Qt::CTRL + Qt::Key_Slash );
	MODIFYmenu.insertItem( "Multiply Time", &Fitter, SLOT( timemult() ));
		
	
	loadAct.addTo(&ADDmenu);
	menuBar()->insertItem( "&Add", &ADDmenu);
	
	ADDmenu.insertItem( "Add Moon", &Fitter, SLOT( newmoon() ), Qt::CTRL + Qt::Key_M );
	ADDmenu.insertItem( "Add Ring", &Fitter, SLOT( newring() ), Qt::CTRL + Qt::Key_R );
	ADDmenu.insertItem( "Add Planet", &Fitter, SLOT( newplanet() ), Qt::CTRL + Qt::Key_P );
	
	
	loadAct.addTo(&SETTINGSmenu);
	menuBar()->insertItem( "&Settings", &SETTINGSmenu);
	
	SETTINGSmenu.insertItem( "Precession", this, SLOT( precessiontoggle() ), Qt::CTRL + Qt::Key_R );
	SETTINGSmenu.setCheckable(1);
	precession(0);
	SETTINGSmenu.insertItem( "Show Lightcurve", this, SLOT( showlightcurvetoggle() ), Qt::Key_0);
	SETTINGSmenu.setCheckable(2);
	showlightcurve(0);
	SETTINGSmenu.insertItem( "Show Inclination", this, SLOT( showinclinationtoggle() ), Qt::Key_1);
	SETTINGSmenu.setCheckable(3);
	showinclination(0);
	SETTINGSmenu.insertItem( "Show Ascnode", this, SLOT( showascendingnodetoggle() ), Qt::Key_2);
	SETTINGSmenu.setCheckable(4);
	showascendingnode(0);
	SETTINGSmenu.insertItem( "Show *Obliquity", this, SLOT( showstellarobliquitytoggle() ), Qt::Key_3);
	SETTINGSmenu.setCheckable(5);
	showstellarobliquity(0);
	
	loadAct.addTo(&GRAPHmenu);
	menuBar()->insertItem( "&Graph", &GRAPHmenu);
	
	GRAPHmenu.insertItem( "Star Obliquity", &Fitter, SLOT( graphobliquity() ));
	GRAPHmenu.insertItem( "Planet Asc Node", &Fitter, SLOT( graphascendingnode() ));
	GRAPHmenu.insertItem( "Planet Inclination", &Fitter, SLOT( graphinclination() ));
	
	loadAct.addTo(&OUTPUTmenu);
	menuBar()->insertItem( "&Output", &OUTPUTmenu);
	
	OUTPUTmenu.insertItem( "Precession Info", &Fitter, SLOT( outputprecessioninfo() ));
	
	
	
	startdir = string("./");
	
}

void transitfitter::loadfile()
{
	QString filename=Q3FileDialog::getOpenFileName(startdir.c_str(), "*.Jcube", this);
	if (filename.isEmpty()) return;
	loadfile(filename.toStdString());
	setstartdir(filename.toStdString());
}

void transitfitter::addfile()
{
	QString filename=Q3FileDialog::getOpenFileName(startdir.c_str(), "*.Jcube", this);
	if (filename.isEmpty()) return;
	Fitter.add(filename.toStdString());
	setstartdir(filename.toStdString());
}

void transitfitter::setstartdir(string filename)
{
	startdir = filename.substr(0, filename.find_last_of("/"));
}

void transitfitter::loadfile(string filename)
{
	cout << "Loading Cube\n";
	Fitter.load(filename);
	
	string strippedname(filename);
	strippedname = strippedname.substr(strippedname.find_last_of("/")+1);
	setCaption((string("Transitfitter -- ") + strippedname).c_str());
}

void transitfitter::savefile()
{
	cout << "Saving Cube\n";
	QString filename=Q3FileDialog::getSaveFileName(startdir.c_str(), "*.Jcube", this);
	if (filename.isEmpty()) return;
	Fitter.savefit(filename.toStdString());
	
	string strippedname(filename.ascii());
	strippedname = strippedname.substr(strippedname.find_last_of("/")+1);
	setCaption((string("Transitfitter -- ") + strippedname).c_str());
	
	setstartdir(filename.toStdString());
}

void transitfitter::saveimage()
{
	cout << "Saving Image\n";
	QString filename=Q3FileDialog::getSaveFileName(startdir.c_str(), "*.png", this);
	if (filename.isEmpty()) return;
	Fitter.saveimage(filename.toStdString());
	
	string strippedname(filename.ascii());
	strippedname = strippedname.substr(strippedname.find_last_of("/")+1);
	setCaption((string("Transitfitter -- ") + strippedname).c_str());
	
	setstartdir(filename.toStdString());
}

void transitfitter::quit()
{
	exit(0);
}

void transitfitter::precessiontoggle()
{
	static bool internalstate(0);
	internalstate = !internalstate;
	precession(internalstate);
//	precession(!precession());
}

void transitfitter::precession(bool b)
{
	SETTINGSmenu.setItemChecked(SETTINGSmenu.idAt(0), b);
//	cout << "Just set precession to " << precession() << " (should be " << b << ")\n";
}

bool transitfitter::precession()
{
//	cout << "returning that precession is set to " << SETTINGSmenu.isItemChecked(SETTINGSmenu.idAt(0)) << "\n";
	return SETTINGSmenu.isItemChecked(SETTINGSmenu.idAt(0));
}

void transitfitter::showlightcurvetoggle()
{
	static bool internalstate(0);
	internalstate = !internalstate;
	showlightcurve(internalstate);
}

void transitfitter::showlightcurve(bool b)	
{
	SETTINGSmenu.setItemChecked(SETTINGSmenu.idAt(1), b);
	Fitter.redrawplotspace();
}

bool transitfitter::showlightcurve()
{
	return SETTINGSmenu.isItemChecked(SETTINGSmenu.idAt(1));
}

void transitfitter::showinclinationtoggle()
{
	static bool internalstate(0);
	internalstate = !internalstate;
	showinclination(internalstate);
}

void transitfitter::showinclination(bool b)	
{
	SETTINGSmenu.setItemChecked(SETTINGSmenu.idAt(2), b);
	Fitter.redrawplotspace();
}

bool transitfitter::showinclination()
{
	return SETTINGSmenu.isItemChecked(SETTINGSmenu.idAt(2));
}


void transitfitter::showascendingnodetoggle()
{
	static bool internalstate(0);
	internalstate = !internalstate;
	showascendingnode(internalstate);
}

void transitfitter::showascendingnode(bool b)	
{
	SETTINGSmenu.setItemChecked(SETTINGSmenu.idAt(3), b);
	Fitter.redrawplotspace();
}

bool transitfitter::showascendingnode()
{
	return SETTINGSmenu.isItemChecked(SETTINGSmenu.idAt(3));
}


void transitfitter::showstellarobliquitytoggle()
{
	static bool internalstate(0);
	internalstate = !internalstate;
	showstellarobliquity(internalstate);
}

void transitfitter::showstellarobliquity(bool b)	
{
	SETTINGSmenu.setItemChecked(SETTINGSmenu.idAt(4), b);
	Fitter.redrawplotspace();
}

bool transitfitter::showstellarobliquity()
{
	return SETTINGSmenu.isItemChecked(SETTINGSmenu.idAt(4));
}





int main(int argc, char **argv)
{
	QApplication app(argc,argv);
		
	NR::JChisqdist cd(6);
	cout << "CD(6)=" << cd.invcdf(0.6827) << "\n";
	
	char *startfile;
	if (argc > 1) startfile = argv[1];
	else startfile=0;
	if (startfile) cout << "startfile: " << startfile << "\n";
	transitfitter j(0,"Transitfitter");
	if (startfile) j.loadfile(startfile);
	
	app.setMainWidget(&j);
	j.show();

	return app.exec();
}
