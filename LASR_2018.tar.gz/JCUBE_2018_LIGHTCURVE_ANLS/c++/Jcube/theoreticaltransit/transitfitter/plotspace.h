#ifndef plotspace_h
#define plotspace_h

#include <qpixmap.h>
#include <qwidget.h>
#include <qsize.h>
#include <qpainter.h>
//Added by qt3to4:
#include <QResizeEvent>
#include <QMouseEvent>
#include <QPaintEvent>
#include <utility>


#include "../../Jcrap.h"

class fitter;

class plotspace : public QWidget
{
	Q_OBJECT
	
public:
	plotspace(QWidget *parent=0, const char *name=0, Qt::WFlags flags=0);

	QSize sizeHint() const;
	
	void loaddata(cube);
	void loadguess(cube);
	void loadfit(cube);
	void savefit(string);
	void saveimage(string);
	cube& data();
	cube copyofdata() const;
	cube fit() const;
	double timeonleft() {return _timeonleft;}
	double timeonright() {return _timeonright;}
	double fluxmax(unsigned int=0); 
	double fluxmin(unsigned int=0);
	int plussize() {return 3;}
	void printData();
	void redraw();
	void drawDataLabels(QPainter*);
	void mousePressEvent(QMouseEvent*);
	void ShowContextMenu(const QPoint &pos);
	void contextMenuEvent(QContextMenuEvent *);
	pair<float,float> returncoordinates();
	pair<double,double> positionToTimeFlux(int,int);
	pair<int,int> timeFluxToPosition(double,double,unsigned int=0);
	pair<int,int> timeFluxToPosition(pair<double,double>,unsigned int=0);
		
	void toggleresidual();
	void togglefold(double, double);
	void togglecrop(double, double, double);
	
	void setGreyBox(pair<double, double>, pair<double, double>);
	void setGreyBox(bool=false);
	pair<double, double> getGreyBox();
	
	bool show(unsigned int);
	void show(unsigned int, bool);
	void parent(fitter*);
	fitter* parent();

	
	
signals:
	void updateCoordinates(pair<double,double>);
	void showchanged();
	
public slots:
	void deletePoint();


protected:
	void paintEvent(QPaintEvent*);
	void resizeEvent(QResizeEvent*);
		
private:
	void setlimits(cube);
	void refreshPixmap();
	void drawData(QPainter*);
	void drawGuess(QPainter*);
	void drawFit(QPainter*);
	void drawCube(QPainter*, cube, int);
	void drawGreyBox(QPainter*);
	
	
private:
	cube Data;
	cube Guess;
	cube Fit;
	
	bool fold;
	bool crop;
	bool residual;
	double _period, _centertime, _cropfraction;
	
	double _timeonleft, _timeonright;
	vector<double> _fluxmax, _fluxmin;
	double _xvaluecoordinate, _yvaluecoordinate;
	int _xpixelcoordinate, _ypixelcoordinate;
	
	double GreyBoxleft, GreyBoxright;
	bool GreyBoxon;
	
	QPixmap pixmap;
	
	fitter *Parent;
};


#endif
