/****************************************************************************
** Meta object code from reading C++ file 'valuespanel.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "valuespanel.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'valuespanel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_valuespanel[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      75,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x05,
      25,   12,   12,   12, 0x05,
      36,   12,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
      48,   12,   12,   12, 0x0a,
      63,   12,   12,   12, 0x0a,
      81,   12,   12,   12, 0x0a,
     105,   12,   12,   12, 0x0a,
     125,   12,   12,   12, 0x0a,
     140,   12,   12,   12, 0x0a,
     156,   12,   12,   12, 0x0a,
     170,   12,   12,   12, 0x0a,
     185,   12,   12,   12, 0x0a,
     195,   12,   12,   12, 0x0a,
     215,   12,   12,   12, 0x0a,
     232,   12,   12,   12, 0x0a,
     251,   12,   12,   12, 0x0a,
     264,   12,   12,   12, 0x0a,
     274,   12,   12,   12, 0x0a,
     284,   12,   12,   12, 0x0a,
     302,  296,   12,   12, 0x0a,
     352,  347,   12,   12, 0x2a,
     394,  390,   12,   12, 0x2a,
     431,  428,   12,   12, 0x2a,
     460,  458,   12,   12, 0x2a,
     480,   12,   12,   12, 0x2a,
     496,   12,   12,   12, 0x2a,
     511,  509,   12,   12, 0x0a,
     528,  509,   12,   12, 0x0a,
     545,  509,   12,   12, 0x0a,
     564,  509,   12,   12, 0x0a,
     585,  583,   12,   12, 0x0a,
     608,  583,   12,   12, 0x0a,
     633,  631,   12,   12, 0x0a,
     646,  631,   12,   12, 0x0a,
     661,  659,   12,   12, 0x0a,
     675,  659,   12,   12, 0x0a,
     691,  689,   12,   12, 0x0a,
     708,  689,   12,   12, 0x0a,
     727,  725,   12,   12, 0x0a,
     744,  725,   12,   12, 0x0a,
     761,  725,   12,   12, 0x0a,
     780,  725,   12,   12, 0x0a,
     801,  799,   12,   12, 0x0a,
     819,  799,   12,   12, 0x0a,
     839,  837,   12,   12, 0x0a,
     853,  837,   12,   12, 0x0a,
     870,  867,   12,   12, 0x0a,
     891,  867,   12,   12, 0x0a,
     914,  912,   12,   12, 0x0a,
     933,  912,   12,   12, 0x0a,
     954,  952,   12,   12, 0x0a,
     978,  952,   12,   12, 0x0a,
    1004, 1002,   12,   12, 0x0a,
    1029, 1002,   12,   12, 0x0a,
    1056, 1054,   12,   12, 0x0a,
    1077, 1054,   12,   12, 0x0a,
    1100, 1098,   12,   12, 0x0a,
    1124, 1098,   12,   12, 0x0a,
    1148,  952,   12,   12, 0x0a,
    1169,  952,   12,   12, 0x0a,
    1190,   12,   12,   12, 0x0a,
    1218,  458,   12,   12, 0x0a,
    1242,  458,   12,   12, 0x0a,
    1266,  458,   12,   12, 0x0a,
    1295,  458,   12,   12, 0x0a,
    1324,  458,   12,   12, 0x0a,
    1347,  458,   12,   12, 0x0a,
    1370,  458,   12,   12, 0x0a,
    1388,  458,   12,   12, 0x0a,
    1406,  458,   12,   12, 0x0a,
    1425,  458,   12,   12, 0x0a,
    1444,  458,   12,   12, 0x0a,
    1468,  458,   12,   12, 0x0a,
    1492,  458,   12,   12, 0x0a,
    1518,  458,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_valuespanel[] = {
    "valuespanel\0\0plotguess()\0dothefit()\0"
    "doMCMCfit()\0updateperiod()\0updatesemimajor()\0"
    "updateimpactparameter()\0updateinclination()\0"
    "turnoffratio()\0turnoffradius()\0"
    "updateratio()\0updateradius()\0nothing()\0"
    "transferthevalues()\0vsinicalculate()\0"
    "updateoblateness()\0updatemass()\0"
    "newmoon()\0newring()\0newplanet()\0,,,,,\0"
    "guessmovie(int,int,double,double,int,string)\0"
    ",,,,\0guessmovie(int,int,double,double,int)\0"
    ",,,\0guessmovie(int,int,double,double)\0"
    ",,\0guessmovie(int,int,double)\0,\0"
    "guessmovie(int,int)\0guessmovie(int)\0"
    "guessmovie()\0r\0setRstar(double)\0"
    "setRstar(string)\0setRplanet(double)\0"
    "setRplanet(string)\0i\0setinclination(double)\0"
    "setinclination(string)\0b\0setb(double)\0"
    "setb(string)\0t\0sett0(double)\0sett0(string)\0"
    "T\0setTpole(double)\0setTpole(string)\0"
    "M\0setMstar(double)\0setMstar(string)\0"
    "setMplanet(double)\0setMplanet(string)\0"
    "P\0setperiod(double)\0setperiod(string)\0"
    "f\0setf0(double)\0setf0(string)\0c1\0"
    "setlimbdark1(double)\0setlimbdark1(string)\0"
    "a\0setazimuth(double)\0setazimuth(string)\0"
    "p\0setstarrotation(double)\0"
    "setstarrotation(string)\0q\0"
    "setstarobliquity(double)\0"
    "setstarobliquity(string)\0v\0"
    "setstarVsini(double)\0setstarVsini(string)\0"
    "e\0seteccentricity(double)\0"
    "seteccentricity(string)\0setperiapsis(double)\0"
    "setperiapsis(string)\0ringpanelclosed(ringpanel*)\0"
    "setRplanet(uint,double)\0setRplanet(uint,string)\0"
    "seteccentricity(uint,double)\0"
    "seteccentricity(uint,string)\0"
    "setperiod(uint,double)\0setperiod(uint,string)\0"
    "setb(uint,double)\0setb(uint,string)\0"
    "sett0(uint,double)\0sett0(uint,string)\0"
    "setascnode(uint,double)\0setascnode(uint,string)\0"
    "setperiapsis(uint,double)\0"
    "setperiapsis(uint,string)\0"
};

void valuespanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        valuespanel *_t = static_cast<valuespanel *>(_o);
        switch (_id) {
        case 0: _t->plotguess(); break;
        case 1: _t->dothefit(); break;
        case 2: _t->doMCMCfit(); break;
        case 3: _t->updateperiod(); break;
        case 4: _t->updatesemimajor(); break;
        case 5: _t->updateimpactparameter(); break;
        case 6: _t->updateinclination(); break;
        case 7: _t->turnoffratio(); break;
        case 8: _t->turnoffradius(); break;
        case 9: _t->updateratio(); break;
        case 10: _t->updateradius(); break;
        case 11: _t->nothing(); break;
        case 12: _t->transferthevalues(); break;
        case 13: _t->vsinicalculate(); break;
        case 14: _t->updateoblateness(); break;
        case 15: _t->updatemass(); break;
        case 16: _t->newmoon(); break;
        case 17: _t->newring(); break;
        case 18: _t->newplanet(); break;
        case 19: _t->guessmovie((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< string(*)>(_a[6]))); break;
        case 20: _t->guessmovie((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5]))); break;
        case 21: _t->guessmovie((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4]))); break;
        case 22: _t->guessmovie((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 23: _t->guessmovie((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 24: _t->guessmovie((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 25: _t->guessmovie(); break;
        case 26: _t->setRstar((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 27: _t->setRstar((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 28: _t->setRplanet((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 29: _t->setRplanet((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 30: _t->setinclination((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 31: _t->setinclination((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 32: _t->setb((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 33: _t->setb((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 34: _t->sett0((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 35: _t->sett0((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 36: _t->setTpole((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 37: _t->setTpole((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 38: _t->setMstar((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 39: _t->setMstar((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 40: _t->setMplanet((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 41: _t->setMplanet((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 42: _t->setperiod((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 43: _t->setperiod((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 44: _t->setf0((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 45: _t->setf0((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 46: _t->setlimbdark1((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 47: _t->setlimbdark1((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 48: _t->setazimuth((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 49: _t->setazimuth((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 50: _t->setstarrotation((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 51: _t->setstarrotation((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 52: _t->setstarobliquity((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 53: _t->setstarobliquity((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 54: _t->setstarVsini((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 55: _t->setstarVsini((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 56: _t->seteccentricity((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 57: _t->seteccentricity((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 58: _t->setperiapsis((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 59: _t->setperiapsis((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 60: _t->ringpanelclosed((*reinterpret_cast< ringpanel*(*)>(_a[1]))); break;
        case 61: _t->setRplanet((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 62: _t->setRplanet((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2]))); break;
        case 63: _t->seteccentricity((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 64: _t->seteccentricity((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2]))); break;
        case 65: _t->setperiod((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 66: _t->setperiod((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2]))); break;
        case 67: _t->setb((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 68: _t->setb((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2]))); break;
        case 69: _t->sett0((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 70: _t->sett0((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2]))); break;
        case 71: _t->setascnode((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 72: _t->setascnode((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2]))); break;
        case 73: _t->setperiapsis((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 74: _t->setperiapsis((*reinterpret_cast< uint(*)>(_a[1])),(*reinterpret_cast< string(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData valuespanel::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject valuespanel::staticMetaObject = {
    { &Q3HBox::staticMetaObject, qt_meta_stringdata_valuespanel,
      qt_meta_data_valuespanel, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &valuespanel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *valuespanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *valuespanel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_valuespanel))
        return static_cast<void*>(const_cast< valuespanel*>(this));
    return Q3HBox::qt_metacast(_clname);
}

int valuespanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3HBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 75)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 75;
    }
    return _id;
}

// SIGNAL 0
void valuespanel::plotguess()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void valuespanel::dothefit()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void valuespanel::doMCMCfit()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}
static const uint qt_meta_data_moonpanel[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_moonpanel[] = {
    "moonpanel\0"
};

void moonpanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData moonpanel::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject moonpanel::staticMetaObject = {
    { &Q3HBox::staticMetaObject, qt_meta_stringdata_moonpanel,
      qt_meta_data_moonpanel, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &moonpanel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *moonpanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *moonpanel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_moonpanel))
        return static_cast<void*>(const_cast< moonpanel*>(this));
    return Q3HBox::qt_metacast(_clname);
}

int moonpanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3HBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_ringpanel[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_ringpanel[] = {
    "ringpanel\0\0ringpanelclosed(ringpanel*)\0"
};

void ringpanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ringpanel *_t = static_cast<ringpanel *>(_o);
        switch (_id) {
        case 0: _t->ringpanelclosed((*reinterpret_cast< ringpanel*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ringpanel::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ringpanel::staticMetaObject = {
    { &Q3HBox::staticMetaObject, qt_meta_stringdata_ringpanel,
      qt_meta_data_ringpanel, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ringpanel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ringpanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ringpanel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ringpanel))
        return static_cast<void*>(const_cast< ringpanel*>(this));
    return Q3HBox::qt_metacast(_clname);
}

int ringpanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3HBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void ringpanel::ringpanelclosed(ringpanel * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_planetpanel[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x0a,
      31,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_planetpanel[] = {
    "planetpanel\0\0update_b(QString)\0"
    "update_i(QString)\0"
};

void planetpanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        planetpanel *_t = static_cast<planetpanel *>(_o);
        switch (_id) {
        case 0: _t->update_b((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->update_i((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData planetpanel::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject planetpanel::staticMetaObject = {
    { &Q3HBox::staticMetaObject, qt_meta_stringdata_planetpanel,
      qt_meta_data_planetpanel, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &planetpanel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *planetpanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *planetpanel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_planetpanel))
        return static_cast<void*>(const_cast< planetpanel*>(this));
    return Q3HBox::qt_metacast(_clname);
}

int planetpanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3HBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
static const uint qt_meta_data_moviedialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      18,   13,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
      56,   12,   12,   12, 0x0a,
      66,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_moviedialog[] = {
    "moviedialog\0\0,,,,\0"
    "domovie(int,double,double,int,string)\0"
    "gomovie()\0cancelmovie()\0"
};

void moviedialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        moviedialog *_t = static_cast<moviedialog *>(_o);
        switch (_id) {
        case 0: _t->domovie((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< string(*)>(_a[5]))); break;
        case 1: _t->gomovie(); break;
        case 2: _t->cancelmovie(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData moviedialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject moviedialog::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_moviedialog,
      qt_meta_data_moviedialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &moviedialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *moviedialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *moviedialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_moviedialog))
        return static_cast<void*>(const_cast< moviedialog*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int moviedialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void moviedialog::domovie(int _t1, double _t2, double _t3, int _t4, string _t5)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
