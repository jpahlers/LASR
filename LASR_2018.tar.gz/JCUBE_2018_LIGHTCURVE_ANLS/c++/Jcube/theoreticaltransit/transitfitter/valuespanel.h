#ifndef valuespanel_h
#define valuespanel_h

#include <vector>
#include "../../Jcrap.h"

#include <q3vbox.h>
#include <q3hbox.h>
#include <qlineedit.h>
#include <qcheckbox.h>
#include <qlabel.h>
#include <q3buttongroup.h>
#include <qpushbutton.h>
#include <qdialog.h>

class moonpanel;
class ringpanel;
class planetpanel;
class fitter;

class valuespanel : public Q3HBox
{
	Q_OBJECT
			
public:
	valuespanel(QWidget *parent=0, const char *name=0);
	QSize sizeHint() const;
	std::vector<double> values();
	std::vector<int> tobefit();
	void loadfit(pair<vector<double>,double>);
	double periodvariable();
	double Tcvariable();
	double impactparameter(unsigned int=0);
	void setparent(fitter*);
	fitter* getparent() {return parent;}
	unsigned int focusplanet();
	value starmass();
	value starradius();
	vector<planetpanel*> & planetboxes();
	
signals:
	void plotguess();	
	void dothefit();
	void doMCMCfit();

public slots:
	void updateperiod();
	void updatesemimajor();
	void updateimpactparameter();
	void updateinclination();
	void turnoffratio();
	void turnoffradius();
	void updateratio();
	void updateradius();
	void nothing();
	void transferthevalues();
	void vsinicalculate();
	void updateoblateness();
	void updatemass();
	void newmoon();
	void newring();
	void newplanet();
	void guessmovie(int=0, int=0, double=0, double=0, int=0, string=string(""));
	
	void setRstar(double r) {setRstar(double2fstr(r));}
	void setRstar(string r) {Rstarbox.clear(); Rstarbox.insert(QString::fromStdString(r));}
	void setRplanet(double r){setRplanet(double2fstr(r));}
	void setRplanet(string r){Rplanetbox.clear(); Rplanetbox.insert(QString::fromStdString(r));}
	void setinclination(double i){setinclination(double2fstr(i));}
	void setinclination(string i){inclinationbox.clear(); inclinationbox.insert(QString::fromStdString(i));}
	void setb(double b){setb(double2fstr(b));}
	void setb(string b){bbox.setText(QString::fromStdString(b));}
	void sett0(double t){sett0(double2str(t));}
	void sett0(string t);
	void setTpole(double T){setTpole(double2fstr(T));}
	void setTpole(string T){Polartempbox.clear(); Polartempbox.insert(QString::fromStdString(T));}
	void setMstar(double M){setMstar(double2fstr(M));}
	void setMstar(string M){Mstarbox.clear(); Mstarbox.insert(QString::fromStdString(M));}
	void setMplanet(double M){setMplanet(double2fstr(M));}
	void setMplanet(string M){Mplanetbox.clear(); Mplanetbox.insert(QString::fromStdString(M));}
	void setperiod(double P){setperiod(double2fstr(P));}
	void setperiod(string P){Periodbox.clear(); Periodbox.insert(QString::fromStdString(P));}
	void setf0(double f){setf0(double2fstr(f));}
	void setf0(string f){F0box.clear(); F0box.insert(QString::fromStdString(f));}
	void setlimbdark1(double c1){setlimbdark1(double2fstr(c1));}
	void setlimbdark1(string c1){limb0box.clear(); limb0box.insert(QString::fromStdString(c1));}
	void setazimuth(double a){setazimuth(double2fstr(a,6));}
	void setazimuth(string a){Azimuthalanglebox.clear(); Azimuthalanglebox.insert(QString::fromStdString(a));}
	void setstarrotation(double p){setstarrotation(double2fstr(p,6));}
	void setstarrotation(string p){Rotationratebox.clear(); Rotationratebox.insert(QString::fromStdString(p));}
	void setstarobliquity(double q){setstarobliquity(double2fstr(q,6));}
	void setstarobliquity(string q){Obliquitybox.clear(); Obliquitybox.insert(QString::fromStdString(q));}
	void setstarVsini(double v){setstarVsini(double2fstr(v,6));}
	void setstarVsini(string v){Vsinibox.clear(); Vsinibox.insert(QString::fromStdString(v));}
	void seteccentricity(double e){seteccentricity(double2fstr(e,6));}
	void seteccentricity(string e){Eccentricitybox.clear(); Eccentricitybox.insert(QString::fromStdString(e));}
	void setperiapsis(double p){setperiapsis(double2fstr(p,6));}
	void setperiapsis(string p){Periapsisbox.clear(); Periapsisbox.insert(QString::fromStdString(p));}
	
	void ringpanelclosed(ringpanel*);

	void setRplanet(unsigned int, double);
	void setRplanet(unsigned int, string);
	void seteccentricity(unsigned int, double);
	void seteccentricity(unsigned int, string);
	void setperiod(unsigned int, double);
	void setperiod(unsigned int, string);
	void setb(unsigned int, double);
	void setb(unsigned int, string);
	void sett0(unsigned int, double);
	void sett0(unsigned int, string);
	void setascnode(unsigned int, double);
	void setascnode(unsigned int, string);
	void setperiapsis(unsigned int, double);
	void setperiapsis(unsigned int, string);
	
private:
	Q3VBox				uservalues;
	Q3HBox				Rstar;
	QCheckBox		Rstarcheck;
	QLineEdit		Rstarbox;
	Q3HBox				Rplanet;
	QCheckBox		Rplanetcheck;
	QLineEdit		Rplanetbox;
	Q3HBox				Rratio;
	QCheckBox		Rratiocheck;
	QLineEdit		Rratiobox;
	Q3HBox				inclination;	
	QCheckBox		inclinationcheck;
	QLineEdit		inclinationbox;
	Q3HBox				b;	
	QLabel			blabel;
	QLineEdit		bbox;
	Q3HBox				limb0;
	QCheckBox		limb0check;
	QLineEdit		limb0box;
	Q3HBox				limb1;
	QCheckBox		limb1check;
	QLineEdit		limb1box;
	Q3HBox				Tc;
	QCheckBox		Tccheck;
	QLineEdit		Tcbox;
	Q3HBox				F0;
	QCheckBox		F0check;
	QLineEdit		F0box;
	Q3HBox			Polartemp;
	QCheckBox		Polartempcheck;
	QLineEdit		Polartempbox;
/*	Q3HBox			Albedo;
	QCheckBox		Albedocheck;
	QLineEdit		Albedobox;
	Q3HBox			Planettemp;
	QCheckBox		Planettempcheck;
	QLineEdit		Planettempbox;*/
	Q3HBox			starMOI;
	QCheckBox		starMOIcheck;
	QLineEdit		starMOIbox;
	
	
	Q3VBox				uservalues2;
	Q3HBox				Mstar;
	QCheckBox		Mstarcheck;
	QLineEdit		Mstarbox;
	Q3HBox				Semimajoraxis;
	QLabel			Semimajoraxislabel;
	QLineEdit		Semimajoraxisbox;
	Q3HBox				Period;
	QCheckBox		Periodcheck;
	QLineEdit		Periodbox;
	Q3HBox				Mplanet;
	QCheckBox		Mplanetcheck;
	QLineEdit		Mplanetbox;
	Q3HBox			Eccentricity;
	QCheckBox		Eccentricitycheck;
	QLineEdit		Eccentricitybox;
	Q3HBox			Periapsis;
	QCheckBox		Periapsischeck;
	QLineEdit		Periapsisbox;
	Q3HBox			Azimuthalangle;
	QCheckBox		Azimuthalanglecheck;
	QLineEdit		Azimuthalanglebox;
	Q3HBox			Rotationrate;
	QCheckBox		Rotationratecheck;
	QLineEdit		Rotationratebox;
	Q3HBox			Obliquity;
	QCheckBox		Obliquitycheck;
	QLineEdit		Obliquitybox;
	Q3HBox			Vsini;
	QCheckBox		Vsinicheck;
	QLineEdit		Vsinibox;
	Q3HBox 			Oblateness;
	QLabel			Oblatenesslabel;
	QLineEdit		Oblatenessbox;
	Q3HBox				Beta;
	QCheckBox		Betacheck;
	QLineEdit		Betabox;
	
	
	Q3ButtonGroup	fitbuttons;
	QPushButton		gofit;
	QPushButton		goMCMCfit;
	QPushButton		gotransfervalues;	
	QPushButton		showguess;	
	QPushButton		guessmoviebutton;
	QPushButton		addmoon;	
	QPushButton		addring;	
	
	
	Q3VBox				fittedvalues;
	QLabel			fitRstar;
	QLabel			fitRplanet;
	QLabel			fitinclination;
	QLabel			fitlimb0;
	QLabel			fitlimb1;
	QLabel			fitTc;
	QLabel			fitF0;
	
	Q3VBox				fittedvalues2;
	QLabel			fitMstar;
	QLabel			fitPeriod;
	
	pair<vector<double>,double> Fit;
	vector<moonpanel*> Moonboxes;
	vector<ringpanel*> Ringboxes;
	vector<planetpanel*> Planetboxes;
	
	fitter *parent;
};

class moonpanel : public Q3HBox
{
	Q_OBJECT
			
public:
	moonpanel(int moonno);

public:
	Q3VBox parametervalues;
	QLabel			boxtitle;
	Q3HBox				Rmoon;
	QCheckBox		Rmooncheck;
	QLineEdit		Rmoonbox;
	Q3HBox				rhomoon;
	QCheckBox		rhomooncheck;
	QLineEdit		rhomoonbox;
	Q3HBox				amoon;
	QCheckBox		amooncheck;
	QLineEdit		amoonbox;
	Q3HBox				ascendingmoon;
	QCheckBox		ascendingmooncheck;
	QLineEdit		ascendingmoonbox;
	Q3HBox				tperimoon;
	QCheckBox		tperimooncheck;
	QLineEdit		tperimoonbox;
	
public:
	int moonnumber;
	
};


class ringpanel : public Q3HBox
{
	Q_OBJECT
			
public:
	ringpanel(int ringno);
	
	void closeEvent(QCloseEvent *);
	
signals:
	void ringpanelclosed(ringpanel*);

public:
	Q3VBox 			parametervalues;
	QLabel			boxtitle;
	Q3HBox			Rinnerbox;
	QCheckBox		Rinnercheck;
	QLineEdit		Rinnertext;
	Q3HBox			Routerbox;
	QCheckBox		Routercheck;
	QLineEdit		Routertext;
	Q3HBox			Taubox;
	QCheckBox		Taucheck;
	QLineEdit		Tautext;
	Q3HBox			Obliquitybox;
	QCheckBox		Obliquitycheck;
	QLineEdit		Obliquitytext;
	Q3HBox			Azimuthbox;
	QCheckBox		Azimuthcheck;
	QLineEdit		Azimuthtext;
	
public:
	int ringnumber;
	
};


class planetpanel : public Q3HBox
{
	Q_OBJECT
			
public:
	planetpanel(int planetno, valuespanel*);

public:
	Q3VBox 			parametervalues;
	Q3HBox			titlebox;
	QLabel			boxtitle;
	QCheckBox		focuscheck;
	Q3HBox			Rplanetbox;
	QCheckBox		Rplanetcheck;
	QLineEdit		Rplanettext;
	Q3HBox			ibox;
	QCheckBox		icheck;
	QLineEdit		itext;
	Q3HBox			bbox;
	QLabel			blabel;
	QLineEdit		btext;
	Q3HBox			Pbox;
	QCheckBox		Pcheck;
	QLineEdit		Ptext;
	Q3HBox			T0box;
	QCheckBox		T0check;
	QLineEdit		T0text;
	Q3HBox			ascbox;
	QCheckBox		asccheck;
	QLineEdit		asctext;
	Q3HBox			ebox;
	QCheckBox		echeck;
	QLineEdit		etext;
	Q3HBox			peribox;
	QCheckBox		pericheck;
	QLineEdit		peritext;
	Q3HBox			albedobox;
	QCheckBox		albedocheck;
	QLineEdit		albedotext;
	Q3HBox			tempbox;
	QCheckBox		tempcheck;
	QLineEdit		temptext;
	Q3HBox			Mbox;
	QCheckBox		Mcheck;
	QLineEdit		Mtext;
	
public slots:
	void update_b(const QString &);
	void update_i(const QString &);
	
public:
	int planetnumber;

private:
	valuespanel *parent;  //needed to figure out star mass
	
};

class moviedialog : public Q3VBox
{
	Q_OBJECT
			
	public:
		moviedialog(valuespanel&);
	
		void starttimeset(string);
		void endtimeset(string);
		bool excludefaraways();
	
	signals:
		void domovie(int, double, double, int, string);
	
	public slots:
		void gomovie();
		void cancelmovie();
	
	private:
//		QVBox thisdialogarea;
		QLabel title;
		Q3HBox resolution;
		QLabel resolutionlabel;
		QLineEdit resolutionbox;
		Q3HBox starttime;
		QLabel startimelabel;
		QLineEdit starttimebox;
		Q3HBox endtime;
		QLabel endtimelabel;
		QLineEdit endtimebox;
		Q3HBox frames;
		QLabel frameslabel;
		QLineEdit framesbox;
		Q3HBox outputfile;
		QLabel outputfilelabel;
		QLineEdit outputfilebox;
		Q3HBox excludebox;
		QCheckBox excludecheck;
		Q3HBox buttonsarea;
		QPushButton gobutton;
		QPushButton cancelbutton;
		
		valuespanel *v;
};

#endif
