#include "fitter.h"
#include "transitfitter.h"

#include <qstring.h>

fitter::fitter(QWidget *parent, const char *name) : 
	Q3VBox(parent, name),
	Topwindow(this),
	Plotspace(&Topwindow), 
	Ctrlpanel(&Topwindow),
	Valuespanel(this)
{
	connect(&Valuespanel, SIGNAL(plotguess()), this, SLOT(plotguess()));
	connect(&Valuespanel, SIGNAL(doMCMCfit()), this, SLOT(doMCMCfit()));
	connect(&Valuespanel, SIGNAL(dothefit()), this, SLOT(dothefit()));
	connect(&Ctrlpanel, SIGNAL(foldVisual()), this, SLOT(foldvisual()));
	connect(&Ctrlpanel, SIGNAL(cropVisual()), this, SLOT(cropvisual()));
	connect(&Ctrlpanel, SIGNAL(residualVisual()), this, SLOT(residualvisual()));
	connect(&Ctrlpanel, SIGNAL(exportData()), this, SLOT(exportdata()));
	connect(&Ctrlpanel, SIGNAL(exportFit()), this, SLOT(exportfit()));
	connect(&Ctrlpanel, SIGNAL(exportResiduals()), this, SLOT(exportresiduals()));
	connect(&Plotspace, SIGNAL(updateCoordinates()), this, SLOT(coordinatevalues()));
		
	Valuespanel.setparent(this);
	Parent=(transitfitter*)(parent);
}


void fitter::load(string loadfilename)
{
	cube indata;
	if (loadfilename.size()) {
		indata = cube(loadfilename.c_str());
		Plotspace.loaddata(indata);
	}
	if (indata.keyword("star_radius").size()) {
		Valuespanel.setRstar(double(str2double(indata.keyword("star_radius"))));
		cout << " Setting R_star to \"" << indata.keyword("star_radius") << "\"\n";
	}
	if (indata.keyword("planet1_radius").size()) {
		value r(str2double(indata.keyword("planet1_radius")), "R_Earth");
		r = r.convert("R_Jup");
		Valuespanel.setRplanet(double(r));
	}	
	if (indata.keyword("planet1_t0").size()) {
		double t0(str2double(indata.keyword("planet1_t0")));
		double Toffset(str2double(indata.keyword("Toffset")));
		
		t0 *= 86400.;
		t0 -= Toffset;
		Valuespanel.sett0(t0); 
	}
	if (indata.keyword("star_teff").size())
		Valuespanel.setTpole(indata.keyword("star_teff"));
	if (indata.keyword("star_mass").size())
		Valuespanel.setMstar(indata.keyword("star_mass"));
	if (indata.keyword("planet1_period").size())
		Valuespanel.setperiod(indata.keyword("planet1_period"));
	if (indata.keyword("planet1_duration").size() && indata.keyword("planet1_period").size()) {
		double duration(str2double(indata.keyword("planet1_duration")));
		double period(str2double(indata.keyword("planet1_period")));
		double fraction(duration/(period*24.));
		Ctrlpanel.setcrop(fraction);
	}
	if (indata.keyword("planet1_b").size()) {
		Valuespanel.setb(indata.keyword("planet1_b"));
	}
	if (indata.keyword("planet1_mass").size()) {
		Valuespanel.setMplanet(indata.keyword("planet1_mass"));
	}
	if (indata.keyword("star_blendfraction").size()) {
		double blendfraction(str2double(indata.keyword("star_blendfraction")));
		for (int z(0);z<indata.N(Z);z++) {
			indata(0,0,z) = (indata(0,0,z)-(1.-blendfraction))/blendfraction;
			indata(1,0,z)/= blendfraction;
		}
		indata.keyword("star_blendfraction", double2str(1.0));  // reset blendfraction now that it has
																	//been corrected for
		cout << "Doing blendfraction\n";
		Plotspace.loaddata(indata);
	}
	if (indata.keyword("star_f0").size())
		Valuespanel.setf0(str2double(indata.keyword("star_f0")));
	if (indata.keyword("star_limbdark1").size())
		Valuespanel.setlimbdark1(str2double(indata.keyword("star_limbdark1")));
	if (indata.keyword("planet1_azimuth").size())
		Valuespanel.setazimuth(str2double(indata.keyword("planet1_azimuth")));
	if (indata.keyword("star_rotationperiod").size())
		Valuespanel.setstarrotation(str2double(indata.keyword("star_rotationperiod")));
	if (indata.keyword("star_obliquity").size())
		Valuespanel.setstarobliquity(str2double(indata.keyword("star_obliquity")));
	if (indata.keyword("star_Vsini").size())
		Valuespanel.setstarVsini(str2double(indata.keyword("star_Vsini")));
	if (indata.keyword("planet1_eccentricity").size())
		Valuespanel.seteccentricity(str2double(indata.keyword("planet1_eccentricity")));
	if (indata.keyword("planet1_periapsis").size())
		Valuespanel.setperiapsis(str2double(indata.keyword("planet1_periapsis")));
}

void fitter::add(string loadfilename)
{
	cube indata;
	if (loadfilename.size()) {
		indata = Plotspace.data().blocksz(cube(loadfilename.c_str()));
		indata = indata.dirinc();
		Plotspace.loaddata(indata);
	}
}
	
void fitter::savefit(string savefilename)
{
//	cout << savefilename;
	
	Plotspace.data().keyword("star_radius", double2str(Valuespanel.values().at(0)));
	Plotspace.data().keyword("star_mass", double2str(Valuespanel.values().at(5)));
	Plotspace.data().keyword("planet1_radius", double2str(Valuespanel.values().at(1)/6378.*71492.));
	Plotspace.data().keyword("planet1_b", double2str(Valuespanel.impactparameter()));
	Plotspace.data().keyword("star_limbdark1", double2str(Valuespanel.values().at(3)));
	Plotspace.data().keyword("star_limbdark2", double2str(Valuespanel.values().at(4)));
	Plotspace.data().keyword("star_f0", double2str(Valuespanel.values().at(12)));
	Plotspace.data().keyword("planet1_t0", double2str(Valuespanel.values().at(11)/86400.));
	Plotspace.data().keyword("star_teff", double2str(Valuespanel.values().at(32)));
	Plotspace.data().keyword("planet1_period", double2str(Valuespanel.periodvariable()));
	Plotspace.data().keyword("planet1_mass", double2str(Valuespanel.values().at(31)));
	Plotspace.data().keyword("planet1_azimuth", double2str(Valuespanel.values().at(15)));
	Plotspace.data().keyword("star_rotationperiod", double2str(Valuespanel.values().at(16)));
	Plotspace.data().keyword("star_obliquity", double2str(Valuespanel.values().at(17)));
	Plotspace.data().keyword("star_Vsini", double2str(Valuespanel.values().at(18)));
	Plotspace.data().keyword("planet1_eccentricity", double2str(Valuespanel.values().at(19)));
	Plotspace.data().keyword("planet1_periapsis", double2str(Valuespanel.values().at(20)/Jcrap::pi*180.));
	
	Plotspace.savefit(savefilename);
}

void fitter::saveimage(string saveimagename)
{	
	Plotspace.saveimage(saveimagename);
}

void fitter::plotguess()
{
	double points(double(Ctrlpanel.guesspoints()));
	
	double accuracy(expf(Ctrlpanel.accuracy_ln()));
	
	transit::calctype c(int2calctype(Ctrlpanel.calcmethod()));
	transit::Transit::Transit t(Valuespanel.values(), accuracy, c);
	t.precession(parent()->precession());
	t.time(Plotspace.timeonleft());
	t.timestep = (Plotspace.timeonright()-Plotspace.timeonleft())/points;
	t.Star().wavelength(Ctrlpanel.wavelength());
	cout << "In plotguess, Beta=" << t.Star().Beta() << "\n";
	t.Star().normalize();
	
	
//	transitfunc Tfunc(t);
	
	
	cout << "Generating lightcurve from " << Plotspace.timeonleft() << " to "
			<< Plotspace.timeonright() << " interval " << t.timestep << "\n";
	cube guesscurve;
	if (points != 0.)
		guesscurve = t.lightcurve(Plotspace.timeonleft(), Plotspace.timeonright(),
				t.timestep, Ctrlpanel.timeintegration()*60.);
	else if (Plotspace.data().N(X) > 2)
		guesscurve = t.lightcurve(Plotspace.data());
	else
		guesscurve = t.lightcurve(Plotspace.data(), Ctrlpanel.timeintegration()*60.);
	
	guesscurve.keyword("star_radius", double2str(Valuespanel.values().at(0)));
	guesscurve.keyword("star_mass", double2str(Valuespanel.values().at(5)));
	guesscurve.keyword("planet1_radius", double2str(Valuespanel.values().at(1)/6378.*71492.));
	guesscurve.keyword("planet1_b", double2str(Valuespanel.impactparameter()));
	guesscurve.keyword("star_limbdark1", double2str(Valuespanel.values().at(12)));
	guesscurve.keyword("star_f0", double2str(Valuespanel.values().at(3)));
	
		
/*	cout << "Star rad = " << t.Star().radius() << "\n";
	cout << "Star mass= " << t.Star().mass() << "\n";
	cout << "Star c1  = " << t.Star().c1() << "\n"; 
	cout << "Planet radius = " << t.Planet().Radius() << "\n";
	cout << "Inclination = " << t.Planet().inclination() << "\n";
	cout << "Semimajor = " << t.Planet().semimajoraxis() << "\n";
	cout << "ROTation rate = " << t.Star().rotationperiod() << "\n";
	cout << "eccentricity = " << t.Planet().eccentricity() << "\n";
	cout << "arg.of.periapsis = " << t.Planet().argumentofpericenter() << "\n";
	cout << "ascending node = " << t.Planet().ascendingnode() << "\n";
	cout << "Star obliquity = " << t.Star().stellarobliquity() << "\n";
	cout << "Wavelength = " << t.Star().wavelength() << "\n";*/
	
	Plotspace.loadguess(guesscurve);
}
 
void fitter::dothefit()
{
	double accuracy(expf(Ctrlpanel.accuracy_ln()));
	cout << "Fitting as ordered!!! \n";
	transit::calctype c(int2calctype(Ctrlpanel.calcmethod()));
	transit::Transit::Transit t(Valuespanel.values(), accuracy, c);
	t.precession(parent()->precession());
	t.time(Plotspace.timeonleft());
	t.timestep = (Plotspace.timeonright()-Plotspace.timeonleft())/100.;
	t.Star().wavelength(Ctrlpanel.wavelength());
	t.Star().normalize();
	
	cout << "Star rad = " << t.Star().radius() << "\n";
	cout << "Star mass= " << t.Star().mass() << "\n";
	cout << "Star c1  = " << t.Star().c1() << "\n"; 
	cout << "Planet radius = " << t.Planet().Radius() << "\n";
	cout << "Inclination = " << t.Planet().inclination() << "\n";
	cout << "Semimajor = " << t.Planet().semimajoraxis() << "\n";
	cout << "ROTation rate = " << t.Star().rotationperiod() << "\n";
	cout << "eccentricity = " << t.Planet().eccentricity() << "\n";
	cout << "argument.of.periapsis = " << t.Planet().argumentofpericenter() << "\n";
		
	
	transitfunc Tfunc(t);
	Tfunc.ia=Valuespanel.tobefit();
	pair<vector<double>,double> fit;
	Tfunc.chidiffstop = 0.001;
	
	cout << "transitfunc a=" << t.Planet().semimajoraxis() << "\n";
	t.Planet().name("transitfuncplanet");

	cube datawitherror(Plotspace.data());
	if (datawitherror.N(X) == 1) 
		datawitherror = datawitherror.blocks(X,datawitherror.pow(0.5)/accuracy/100.);
	if (datawitherror.N(X) == 2) {
		datawitherror = datawitherror.blocks(X,datawitherror.plane(X,0));
		for (int z(0);z<datawitherror.N(Z);z++)
			datawitherror(2,0,z)=Ctrlpanel.timeintegration()*60.;
	}
	datawitherror.write("datawitherror.Jcube");
	
	fit = Tfunc.fit_withtimeintegration(datawitherror, Valuespanel.values(), Valuespanel.tobefit());

	Valuespanel.loadfit(fit);
	
	Tfunc.a = fit.first;
	cube fitcube;
	if (Ctrlpanel.guesspoints()==0) {
		cout.flush();
		fitcube = Tfunc.Transit().lightcurve(datawitherror);
	} else {
		Tfunc.timeintegrationdatabase[0.] = Ctrlpanel.timeintegration()*60.;
		fitcube = Tfunc.plot(Plotspace.timeonleft(),Plotspace.timeonright(), Ctrlpanel.guesspoints());
	}
	Plotspace.loadfit(fitcube);
}

MCMCwindow::MCMCwindow(fitter &fitterpointer) : Q3VBox(0, "MCMC Universe, baby"), 
		display_layout(this),
		parameterbuttongroup(1, Qt::Horizontal, &display_layout),
		parameterbuttons(0),
		stepnumberlabel("", &parameterbuttongroup),
		chisqlabel("", &parameterbuttongroup),
		Plotspace(&display_layout),
		controls(this),
		stopbutton("GO!", &controls),
		sizeupbutton("Bigger zone", &controls),
		sizedownbutton("Smaller zone", &controls),
		burninbox("1000", &controls),
		exportfitbutton("Export Fit", &controls),
		f(0),
		t(vector<double>(0), 1000, POLAR_INTEGRAL2),
		Tfunc(t),
		realtimer(this),
		data(0,0,0),
		stepnumber(0),
		overall(1.)
{
	f = &fitterpointer;
	data = f->Plotspace.data();
	
	
//	stopbutton.setToggleButton(true);
	
	double accuracy(expf(f->Ctrlpanel.accuracy_ln()));
	cout << "Fitting as ordered!!! \n";
	transit::calctype c(int2calctype(f->Ctrlpanel.calcmethod()));
	transit::Transit newt(f->Valuespanel.values(), accuracy, c);
	newt.precession(fitterpointer.parent()->precession());
	t=newt;
	t.time(f->Plotspace.timeonleft());
	t.timestep = (f->Plotspace.timeonright()-f->Plotspace.timeonleft())/100.;
	t.Star().wavelength(f->Ctrlpanel.wavelength());
	t.Star().normalize();
	
	Tfunc = transitfunc(t);

	for (unsigned int i(0);i<f->Valuespanel.tobefit().size();i++) {
		if (f->Valuespanel.tobefit().at(i)) {
			string buttonlabel(Tfunc.param_names[i]);
			buttonlabel += "  --  none +/- none";
			QRadioButton *newbutton(new QRadioButton(buttonlabel.c_str(), &parameterbuttongroup));
			parameterbuttons.push_back(newbutton);
			Tfunc.ia.at(i)=1;
			
		}
	}
	
	for (int i(0);i<data.N(Z);i++)
		Tfunc.timeintegrationdatabase[data.Axis(Z,i)]=data(2,0,i);
	
	MarkovChain = cube(parameterbuttons.size(), 1, 1);
	for (unsigned int i(0), j(0);i<f->Valuespanel.tobefit().size();i++) {
		if (f->Valuespanel.tobefit().at(i)) {
			MarkovChain(int(j),0,0) = f->Valuespanel.values().at(i);
			j++;
		}
	}	
	
	connect(&realtimer, SIGNAL(timeout()), this, SLOT(MCMCstep()));
	connect(&stopbutton, SIGNAL(pressed()), this, SLOT(runMCMC()));
	connect(&sizeupbutton, SIGNAL(pressed()), this, SLOT(sizeup()));
	connect(&sizedownbutton, SIGNAL(pressed()), this, SLOT(sizedown()));
	connect(&exportfitbutton, SIGNAL(pressed()), this, SLOT(exportfit()));
	
	show();
}

MCMCwindow::~MCMCwindow()
{
	for (unsigned int i(0);i<parameterbuttons.size();i++)
		delete parameterbuttons.at(i);
	realtimer.stop();
}

void fitter::doMCMCfit()
{
	MCMCwindow *mcmc;
	mcmc=(new MCMCwindow(*this));
	
}

void MCMCwindow::runMCMC()
{
	cout << "running MCMC, stopbuttonstate = " << stopbutton.isChecked() << "\n";
	if (stopbutton.isChecked()!=0) 
		realtimer.stop();
	else {
		MCMCstep();
		realtimer.start(10.);
	}
	

}

void MCMCwindow::sizeup()
{
	size(sqrt(10.));
}


void MCMCwindow::sizedown()
{
	size(sqrt(0.1));
}

void MCMCwindow::size(double v)
{
	for (unsigned int i(0);i<Tfunc.ia.size();i++)
		Tfunc.h.at(i)*=v;
	overall*=v;
}

void MCMCwindow::exportfit()
{
	transitfunc newT(Tfunc);	
	transitfunc *T(&newT);
	int burnin(str2int(burninbox.text().toStdString()));
	int n(-1);
	cout << "exporting fit.  ";
	for (unsigned int i(0);i<newT.ia.size();i++) {
		if (newT.ia.at(i)) {
			n++;
			if (burnin > MarkovChain.Axis(Z,MarkovChain.N(Z)-1)) continue;
			
			osuppress++;
			cube measurement(MarkovChain(n,n,0,0,float(burnin),MarkovChain.Axis(Z,MarkovChain.N(Z)-1)));
			double mean(measurement.mean());
			osuppress--;
			
			newT.a.at(i) = mean;
			cout << newT.param_names.at(i) << "=" << mean << "  ";
		}
	}
	cout << " -- chisq=" << newT.chisquared(data) << ", reduced-X^2=" << newT.reducedchisquared(data) << "\n";
	
//	cout << "First point = " << newT(data.Axis(Z,0)) << "; Transitfirstpoint=" << newT.Transit().lightflux(data.Axis(Z,0)) << "\n";
	cube fitcube(newT.plot(data));
	f->Plotspace.loadfit(fitcube);
	
	cout << "Parameters for fit:  ";
	for (unsigned int i(0);i<T->ia.size();i++) 
		cout << T->param_names.at(i) << "=" << T->a.at(i) << " ";
	cout << "\n";
	
	
}

void MCMCwindow::MCMCstep()
{
	cube thislink(parameterbuttons.size(), 1, 1);
	
	double result;
	result = (Tfunc.MCMCstep(data));
/*	if (result > 0.5) {
		cout << "MCMCstep #" << stepnumber;
		cout << ":  ";
		cout << "SUCCESS!!  chisq=" << Tfunc.chisquared(data) << ", reducedX^2=" << Tfunc.reducedchisquared(data) << "\n";
	} else;// cout << "nope";*/
	stepnumber++;
	
	int n(-1);
	for (unsigned int i(0);i<Tfunc.ia.size();i++) {
		if (Tfunc.ia.at(i)) {
			thislink(++n,0,0) = Tfunc.a.at(i);
		}
	}
	
	
	if (stepnumber%10==0 && stepnumber!=0) {
		thislink.Axis(Z,0)=stepnumber;
		MarkovChain=MarkovChain.blocksz(thislink);
//		MarkovChain.write("state.Jcube");
//		cout << "ABout to update\n";
		MCMCdisplayupdate();
	}
}

void MCMCwindow::MCMCdisplayupdate()
{
	int buttonnum(parameterbuttongroup.selectedId());
//	cout << "Buttonid=" << buttonnum << "\n";
	
	if (buttonnum<0) return;
	
	cube displaydata(MarkovChain(buttonnum,buttonnum,0,0,-1,-1));
//	cout << "Plotspace loaddata coming\n"; cout.flush();
	if (displaydata.N(Z)>1) {
//		displaydata.write("displaydata.Jcube");
		Plotspace.loaddata(displaydata);
	}
//	cout << "done\n";
	

	int burnin(str2int(burninbox.text().toStdString()));
	int n(-1);
	for (unsigned int i(0);i<Tfunc.ia.size();i++) {
		if (Tfunc.ia.at(i)) {
			n++;
			if (burnin > MarkovChain.Axis(Z,MarkovChain.N(Z)-1)) continue;
			
//			cout << "About to subcube, MC: " << MarkovChain.info() << "\n";
			osuppress++;
			cube measurement(MarkovChain(n,n,0,0,float(burnin),MarkovChain.Axis(Z,MarkovChain.N(Z)-1)));
//			cout << "About to mean\n";
			double mean(measurement.mean());
//			cout << "About to stdev\n";
			double sigma(0);
			sigma = (measurement.sigma()(0,0,0));
			osuppress--;
			
			string newlabel(Tfunc.param_names.at(i));
			newlabel += string(" -- ");
			newlabel += double2str(mean);
			newlabel += string(" +/- ");
			newlabel += double2str(sigma);
			parameterbuttons.at(n)->setText(QString::fromStdString(newlabel));
		}
	}
	
	string chisqstr("X^2=");
	chisqstr+=double2fstr(Tfunc.chisquared(data));
	chisqstr+=string("; reduced_X^2=");
	chisqstr+=double2fstr(Tfunc.reducedchisquared(data));
	chisqlabel.setText(QString::fromStdString(chisqstr));
	
	string stepnumberstr("Step #");
	stepnumberstr+=int2str(stepnumber);
	stepnumberstr+=string("    zonesize: ");
	stepnumberstr+=double2str(overall);
	stepnumberlabel.setText(QString::fromStdString(stepnumberstr));
	
}

void fitter::folddata()
{
	
	cube NewData(Plotspace.data());	
	double P (Valuespanel.periodvariable()*86400);	
	double t (Valuespanel.Tcvariable());
	
	for (int i(0); i<= (NewData.N(Z)-1); i++)
	{		
		
		double &x(NewData.Axis(Z,i));
		float &y(NewData(0,0,i));		
		
		if (x>=(t-(.5*P)) && x < (t+(.5*P)))
		{
			x=x;
			y=y;
		}else if (x >= (t+(.5*P)))
		{
			do{
				x = (x-P);
				y = y;
			}while (x >= (t+ (.5*P)));
		}else if (x < (t-(.5*P)))
		{
			do{
				x = (x+P);
				y = y;
			}while (x < (t-(.5*P)));
		}
		
		
	}
	
//	NewData.write("beforedirinc.Jcube");
	Plotspace.loaddata(NewData.dirinc(Z));
	
}

//double lowerlimit, upperlimit;   // ugly globals

bool isoutside(cube& c, axis A, int a)
{
	bool answer(1);
	double lowerlimit, upperlimit;
		
	if (A==X) answer = 1;
	else if (A==Y) answer = 1;
	else if (A==Z) {
		lowerlimit = str2double(c.keyword("croplowerlimit"));
		upperlimit = str2double(c.keyword("cropupperlimit"));
		if ((double(c.Axis(Z,a)) > upperlimit)  ||  (double(c.Axis(Z,a)) < lowerlimit))
			answer = 0;
	}
	
//	cout << "upperlimit = " << upperlimit << "\n";
//	cout << ", lowerlimit = " << lowerlimit << "\n";
//	cout << "In evaluator for A=" << A << ", a=" << a << ".  answer=" << answer;
//	cout << ", value=" << c(0,0,a) << ",  z=" << c.Axis(Z,a) << "\n";
	
	return answer;
}


void fitter::cropdata()
{
	double P (Valuespanel.periodvariable()*86400.);
	double t (Valuespanel.Tcvariable());
	double ca (Ctrlpanel.cropamountvariable());
	
	cout << "P=" << P << "\n";
	cout << "t=" << t << "\n";
	cout << "ca=" << ca << "\n";
	cout << "lowerlimit = " << t-ca*P << "\n";
	cout << "upperlimit = " << t+ca*P << "\n";
	
	Plotspace.data().keyword("croplowerlimit", double2str(t-ca*P));
	Plotspace.data().keyword("cropupperlimit", double2str(t+ca*P));
//	lowerlimit = t-ca*P;
//	upperlimit = t+ca*P;
		
	Plotspace.loaddata(Plotspace.data().smartselectivespliceout(&isoutside));
}


void fitter::filterdata ()
{
	cube OldData(Plotspace.data().dirinc());
	cube NewData(OldData);
	
	
	double manualwidth;
	cout << "\n\nENTER WIDTH OF BOXCAR FILTER, IN HOURS:  ";
	cin >> manualwidth;
	
	double windowsize = 3600.*manualwidth;
	
	cout << "okay, resizing with " << windowsize << " seconds\n";
	
//	cout<<"There are: "<<OldData.N(Z)-1<<endl;
	
	
	
	cout << "Filtering:   00%"; cout.flush();
	for (long i(0); i <= OldData.N(Z)-1; i++)
	{
		printpercent(i,OldData.N(Z)-1);
		cube TempData;		
		
//		cout<<"On Number: "<<i<<endl;
		
		long lowerlimit;
		long higherlimit;
		
		lowerlimit = OldData.Jlocate(OldData.Axis(Z,i) - windowsize, Z);
		if (lowerlimit < 0) lowerlimit = 0;
		
		higherlimit = OldData.Jlocate(OldData.Axis(Z,i) + windowsize, Z);
		if (higherlimit > OldData.N(Z)-1) higherlimit = OldData.N(Z)-1;
		
		
		osuppress++;
		TempData = OldData.chunk(Z, lowerlimit, higherlimit);
		osuppress--;
//		cout << "Chunked " << lowerlimit << " to " << higherlimit << "\n";
		
		double continuum(TempData.skewer(Z,0,0).median());
//		cout << "continuum = " << continuum << "\n";
//		cout << "Old value = " << OldData(0,0,i);
		
			
//		x = x;
		NewData(0,0,i) = OldData(0,0,i)/continuum;
		NewData(1,0,i) = OldData(1,0,i)/continuum;
//		cout << "  New value = " << NewData(0,0,i) << "\n";
	
	
	}
	printpercent(1,1);
	cout << "\n";
	Plotspace.loaddata(NewData);
	
}

void fitter::normalizedata ()
{
	cube NewData(Plotspace.data());
	
	double mediumvalue(NewData.skewer(Z,0,0).median());
	
	cout<<"Median Value Is: "<<mediumvalue<<endl;
	
	for (int i(0); i<=NewData.N(Z)-1; i++)
	{
		double &x(NewData.Axis(Z,i));
		float &y(NewData(0,0,i));
		float &err(NewData(1,0,i));
		
		x = x;
		y = y/mediumvalue;
		err= err/mediumvalue;
	}
	
	Plotspace.loaddata(NewData);
}


bool iswayoutthere(cube& c, axis A, int a)
{
	bool answer(1);
	double cliplimit;
		
	if (A==X) answer = 1;
	else if (A==Y) answer = 1;
	else if (A==Z) {
		double median(0.);
		int li(a-3), ui(a+3);
		if (li<0) {li=0; ui=6;}
		if (ui>=c.N(Z)) {li=c.N(Z)-7; ui=c.N(Z)-1;}
		for (int i(li);i<=ui;i++) {
			if (i<0) i=0;
			if (i>=c.N(Z)) break;
			median+=c(0,0,i);
		}
		median = (median-c(0,0,a))/6.;
		double truesigma(c(1,0,a));
		
		cliplimit = str2double(c.keyword("cliplimit"));  // above how many sigmas to clip
		if (cliplimit==0.) cliplimit = 3.;
		
		if (fabs((c(0,0,a)-median)/truesigma) > cliplimit)
			answer = 0;
	}
	
//	cout << "upperlimit = " << upperlimit << "\n";
//	cout << ", lowerlimit = " << lowerlimit << "\n";
//	cout << "In evaluator for A=" << A << ", a=" << a << ".  answer=" << answer;
//	cout << ", value=" << c(0,0,a) << ",  z=" << c.Axis(Z,a) << "\n";
	
	return answer;
}

void fitter::cleandata()
{

	Plotspace.data().keyword("windowsize", "3600.");
	Plotspace.data().keyword("cliplimit", "5.");
	
	Plotspace.loaddata(Plotspace.data().smartselectivespliceout(&iswayoutthere));
	
	return;
}

void fitter::bindata()
{
	double lo(Plotspace.data().Axis(Z,0));
	double hi(Plotspace.data().Axis(Z,Plotspace.data().N(Z)-1));
	int n((hi-lo)/Ctrlpanel.binamountvariable() + 1);
	cout << "n=" << n << "\n";
	
	cube binned(Plotspace.data().N(X), Plotspace.data().N(Y), n);
	binned.copymetadatafrom(Plotspace.data());
	for (int z(0);z<binned.N(Z);z++)
		binned.Axis(Z,z) = lo+(Ctrlpanel.binamountvariable()*(double(z)+0.5));
	
	for (int z(0);z<binned.N(Z);z++) {
		vector<pair<double, double> > inthisbin;
		cout << "Bin centered at " << double(binned.Axis(Z,z)) << " -- ";
		for (int i(0);i<Plotspace.data().N(Z);i++) 
			if (Plotspace.data().Axis(Z,i) >= double(binned.Axis(Z,z))-0.5*Ctrlpanel.binamountvariable()  &&
				 Plotspace.data().Axis(Z,i) <= double(binned.Axis(Z,z))+0.5*Ctrlpanel.binamountvariable())
				inthisbin.push_back(pair<double, double>(Plotspace.data()(0,0,i), Plotspace.data()(1,0,i)));
		cout << inthisbin.size() << " points found -- ";
		if (inthisbin.size() == 0) {
			binned = binned.spliceout(Z, z, z);
			z--;
		} else {
			double sum(0.), variance(0.);
			for (unsigned int i(0);i<inthisbin.size();i++) {
				sum += inthisbin.at(i).first;
				variance += pow(inthisbin.at(i).second, 2.);
			}
			binned(0,0,z) = sum / double(inthisbin.size());
			binned(1,0,z) = sqrt(variance) / double(inthisbin.size());
			if (binned.N(Z)>=2) binned(2,0,z) = Plotspace.data()(2,0,0);
		}
		cout << "\n";
	}
	
	Plotspace.loaddata(binned);
}


baselinedialog::baselinedialog() : 
		Q3HBox(0),
		vertitemsbox(this),
		instructions("Subtracting Baseline\n Left-click at the left end of the transit,\n"
				"then at the right-hand end of the transit.\n", &vertitemsbox),
		polyorderbox(&vertitemsbox),
		polyorderlabel("Polynomial Order: ", &polyorderbox),
		poly0button("0", &polyorderbox),
		poly1button("1", &polyorderbox),
		poly2button("2", &polyorderbox),
		poly3button("3", &polyorderbox),
		poly4button("4", &polyorderbox),
		outcomebox(&vertitemsbox),
		fitbutton("Fit!", &outcomebox),
		subtractbutton("Subtract", &outcomebox),
		cancelbutton("Cancel", &outcomebox)		
{
	polyorderbuttons.addButton(&poly0button, 0);
	polyorderbuttons.addButton(&poly1button, 1);
	polyorderbuttons.addButton(&poly2button, 2);
	polyorderbuttons.addButton(&poly3button, 3);
	polyorderbuttons.addButton(&poly4button, 4);
	
	poly1button.click();
	
	subtractbutton.setEnabled(false);
	
	connect(&cancelbutton, SIGNAL(clicked()), this, SIGNAL(cancelled()));
	connect(&fitbutton, SIGNAL(clicked()), this, SLOT(go()));
	connect(&subtractbutton, SIGNAL(clicked()), this, SIGNAL(subtract()));
	
	
	show();
}

void baselinedialog::go()
{
	emit go(polyorderbuttons.checkedId());
	subtractbutton.setEnabled(true);
}

void fitter::baselinesub()
{	
	static baselinedialog* Baselinedialog(0);
	
	if (Baselinedialog==0) {
		Plotspace.setGreyBox(true);
		Baselinedialog = new baselinedialog;
		
		connect(Baselinedialog, SIGNAL(cancelled()), this, SLOT(baselinesub()));
		connect(Baselinedialog, SIGNAL(go(int)), this, SLOT(baselinesub_go(int)));
		connect(Baselinedialog, SIGNAL(subtract()), this, SLOT(baselinesub_subtract()));
		
		
		
	} else {  // if there already is a dialog box, then kill it and close everything
		Plotspace.setGreyBox(false);
		delete(Baselinedialog);
		Baselinedialog=0;
	}
	
}

void fitter::baselinesub_go(int o)
{
	cout << "Would be doing the fit and subtraction here order " << o << "\n";
	
	cube baselinepoints(Plotspace.data()(0,1,-1,-1,-1,-1));
	
	for (int z(0);z<baselinepoints.N(Z);z++) {
		pair<double,double> greyboxrange(Plotspace.getGreyBox());
		if (baselinepoints.Axis(Z,z) > greyboxrange.first   &&
			 baselinepoints.Axis(Z,z) < greyboxrange.second) {
			baselinepoints = baselinepoints.spliceout(Z,z);
			cout << "splicing out flux #" << z << "\n";
			z--;
		}
	}
	
	double firsttime(baselinepoints.Axis(Z,0));
	double lasttime(baselinepoints.Axis(Z,baselinepoints.N(Z)-1));
	for (int z(0);z<baselinepoints.N(Z);z++) baselinepoints.Axis(Z,z)-=firsttime;
	for (int z(0);z<baselinepoints.N(Z);z++) baselinepoints.Axis(Z,z)/=(lasttime-firsttime);
	
	if (baselinepoints.N(Z) >= o+1) {
		polynomial Polynomial(o);
		
		vector<int> tobefit(o+1);
		for (unsigned int i(0);i<tobefit.size();i++) tobefit.at(i)=1;
		
		vector<double> initialguesses(o+1);
		for (unsigned int i(0);i<initialguesses.size();i++) initialguesses.at(i)=0.;
		
		pair<vector<double>, double> fitanswer;
		fitanswer = Polynomial.fit(baselinepoints, initialguesses, tobefit);
			
		cube baselinefit(Plotspace.data()(0,0,-1,-1,-1,-1));
		for (int z(0);z<baselinefit.N(Z);z++) baselinefit.Axis(Z,z)-=firsttime;
		for (int z(0);z<baselinefit.N(Z);z++) baselinefit.Axis(Z,z)/=(lasttime-firsttime);
		
		for (int z(0);z<baselinefit.N(Z);z++)  {
			baselinefit(0,0,z) = Polynomial(baselinefit.Axis(Z,z));
			baselinefit.Axis(Z,z) = firsttime+(lasttime-firsttime)*baselinefit.Axis(Z,z);
		}
		Plotspace.loadfit(baselinefit);
		
	}

}

void fitter::baselinesub_subtract()
{
	Plotspace.loaddata(Plotspace.data()-Plotspace.fit()+1.);
	baselinesub();
}

void fitter::changeepoch(double t)
{
	if (parent()->precession()==true) {
		transit::Transit tr(Valuespanel.values(), 1000, POLAR_INTEGRAL2);
		tr.precession(parent()->precession());
		tr.time(t);
		Valuespanel.setinclination(tr.Planet().inclination()/Jcrap::pi*180.); // precess the planet inclination in valuespanel
		Valuespanel.setazimuth(tr.Planet().ascendingnode()/Jcrap::pi*180.); // precess the ascending node
		Valuespanel.setstarobliquity(tr.Star().stellarobliquity()); // precess the stellar obliquity
	}
	Valuespanel.sett0(t);
	
}

void fitter::orbitchange(double n)
{
	double oldtime(Valuespanel.Tcvariable());
	double period(86400.*Valuespanel.periodvariable());
	double newtime(oldtime+n*period);
	changeepoch(newtime);
	Plotspace.redraw();
}

void fitter::transitnext() 
{
	if (str2double(Plotspace.data().keyword("croplowerlimit")) <  // only if not already beyond data
			Plotspace.data().Axis(Z,Plotspace.data().N(Z)-1)) {
		double lowerlimit(str2double(Plotspace.data().keyword("croplowerlimit")));
		double upperlimit(str2double(Plotspace.data().keyword("cropupperlimit")));
		double period(86400.*Valuespanel.periodvariable());
		double oldtime(Valuespanel.Tcvariable());
		double newtime(oldtime+period), newlowerlimit(lowerlimit), newupperlimit(upperlimit);
	
		double n(0);
		int q;
		do {
			n+=1.;
			newlowerlimit = lowerlimit+n*period;
			newupperlimit = upperlimit+n*period;
			newtime = oldtime+n*period;
			
			if (newlowerlimit > Plotspace.data().Axis(Z,Plotspace.data().N(Z)-1)) {
				n-=1.;
				newlowerlimit = lowerlimit+n*period;
				newupperlimit = upperlimit+n*period;
				newtime = oldtime+n*period;				
				break;
			}
			q=0;
			for (int z(0);z<Plotspace.data().N(Z);z++)
				if (Plotspace.data().Axis(Z,z) < newupperlimit  &&
						Plotspace.data().Axis(Z,z)>newlowerlimit) q++;
//			cout << "n=" << n <<", q=" << q << "\n";
		} while (q==0);
		
		Plotspace.data().keyword("croplowerlimit")=double2str(newlowerlimit);
		Plotspace.data().keyword("cropupperlimit")=double2str(newupperlimit);
		changeepoch(newtime);
		
	}
}

void fitter::transitprev() 
{
	if (str2double(Plotspace.data().keyword("cropupperlimit")) >  // only if not already beyond data
			Plotspace.data().Axis(Z,0)) {
		double lowerlimit(str2double(Plotspace.data().keyword("croplowerlimit")));
		double upperlimit(str2double(Plotspace.data().keyword("cropupperlimit")));
		double period(86400.*Valuespanel.periodvariable());
		double oldtime(Valuespanel.Tcvariable());
		double newtime(oldtime+period), newlowerlimit(lowerlimit), newupperlimit(upperlimit);
	
		double n(0);
		int q;
		do {
			n-=1.;
			newlowerlimit = lowerlimit+n*period;
			newupperlimit = upperlimit+n*period;
			newtime = oldtime+n*period;
			
			if (newupperlimit < Plotspace.data().Axis(Z,0)) {
				n+=1.;
				newlowerlimit = lowerlimit+n*period;
				newupperlimit = upperlimit+n*period;
				newtime = oldtime+n*period;					
				break;
			}
			
			q=0;
			for (int z(0);z<Plotspace.data().N(Z);z++)
				if (Plotspace.data().Axis(Z,z) < newupperlimit  &&
						Plotspace.data().Axis(Z,z)>newlowerlimit) q++;
//			cout << "n=" << n <<", q=" << q << "\n";
			
		} while (q==0);
		
		Plotspace.data().keyword("croplowerlimit")=double2str(newlowerlimit);
		Plotspace.data().keyword("cropupperlimit")=double2str(newupperlimit);
		changeepoch(newtime);
		
	}
}

void fitter::orbitadd()
{
	orbitchange(+1);
}

void fitter::orbitsub()
{
	orbitchange(-1);
}

void fitter::timemult() 
{
	cube answer(Plotspace.data());
	for (int i(0);i<answer.N(Z);i++) {
		answer.Axis(Z,i) *= 86400.;
	}
	Plotspace.loaddata(answer);
}

void fitter::foldvisual()
{
	Plotspace.togglefold(Valuespanel.Tcvariable(),Valuespanel.periodvariable()*86400.);
}

void fitter::cropvisual()
{
	Plotspace.togglecrop(Valuespanel.Tcvariable(),Valuespanel.periodvariable()*86400.,
			Ctrlpanel.cropamountvariable());
}

void fitter::residualvisual()
{
	Plotspace.toggleresidual();
}





void fitter::exportdata()
{
	cube Data(Plotspace.data());
	
	Data.graph();
}

void fitter::exportfit()
{
	cube Fit(Plotspace.fit());
	
	Fit.graph();	
}

void fitter::exportresiduals()
{
	cube Data(Plotspace.data());
	cube Fit(Plotspace.fit());
	cube Residuals = Data - Fit;
	
	Residuals.graph();
}

void fitter::coordinatevalues()
{

	pair<double,double> coordinates = Plotspace.returncoordinates();
	double time = coordinates.first;
	double flux = coordinates.second;

	Ctrlpanel.inputflux(flux);
	Ctrlpanel.inputtime(time);

	Clicklocations.push_back(coordinates);
	if (Clicklocations.size()>=2)
		Plotspace.setGreyBox(Clicklocations.at(Clicklocations.size()-1),
				Clicklocations.at(Clicklocations.size()-2));
}

pair<double, double> fitter::timerange()
{
	pair<double, double> answer;
	cout << "interrogating Plotspace about its times\n";
	answer.first = Plotspace.timeonleft();
	answer.second= Plotspace.timeonright();
	return answer;
}


void fitter::graphobliquity()
// 2012 December 21 JWB
{
	graphvalues(0);
}

void fitter::graphascendingnode()
// 2012 December 21 JWB
{
	graphvalues(1);
}

void fitter::graphinclination()
// 2012 December 21 JWB
{
	graphvalues(2);
}

void fitter::graphvalues(int which)
// 2012 December 21 JWB
{
	unsigned long points(double(Ctrlpanel.guesspoints()));
	
	cube tobegraphed;
	if (points == 0) {
		tobegraphed = Plotspace.data().plane(X,0)*0.;
	} else {
		tobegraphed = cube(1,1,points);
		double increment((Plotspace.timeonright()-Plotspace.timeonleft())/double(points));
		for (int z(0);z<tobegraphed.N(Z);z++)
			tobegraphed.Axis(Z,z) = Plotspace.timeonleft()+double(z)*increment;
	}
	
	
	transit::Transit::Transit t(Valuespanel.values(), 1000, POLAR_INTEGRAL2);
	t.precession(parent()->precession());
	
	for (int z(0);z<tobegraphed.N(Z);z++) {
		t.time(tobegraphed.Axis(Z,z));
		if (which == 0) {
			tobegraphed(0,0,z) = t.Star().stellarobliquity();
		} else if (which == 1) {
			tobegraphed(0,0,z) = angle(t.Planet().ascendingnode(), angle::RADIANS).degrees();
		} else if (which == 2) {
			tobegraphed(0,0,z) = angle(t.Planet().inclination(), angle::RADIANS).degrees();
		}
	}
	
	if (which==0) tobegraphed.keyword("title", "Stellar Obliquity");
	if (which==1) tobegraphed.keyword("title", "Ascending node");
	if (which==2) tobegraphed.keyword("title", "Inclination");
	
	tobegraphed.graph();
	
}

void fitter::outputprecessioninfo()
// 2012 December 21 JWB
{
	transit::Transit::Transit t(Valuespanel.values(), 1000, POLAR_INTEGRAL2);
	t.precession(parent()->precession());
	
	cout << "Full Precession rate = " << t.Omegadot() << " rad/s\n";
	cout << "Full Precession period = " << t.precessionperiod() << " s, ";
	cout << t.precessionperiod().convert("year") << "\n";
	cout << "(Planetonly precession period = " << t.precessionperiod_planetonly().convert("year") << "\n";
	cout << "Spin-orbit angle = " << t.Psi().as(angle::DEGREES) << "\n";	
	cout << "Psi_p = " << t.Psi_p().as(angle::DEGREES) << ", Psi_*= = " << t.Psi_s().as(angle::DEGREES) << "\n";
	cout << "L_total_sky[x]=" << t.Ltotal().at(0) << ", [y]=";
	cout << t.Ltotal().at(1) << ", [z]=" << t.Ltotal().at(2) << "\n";
	cout << "L_total_sky[xy]=" << sqrt(t.Ltotal().at(0)*t.Ltotal().at(0)+
			t.Ltotal().at(1)*t.Ltotal().at(1)) << "\n";
	cout << "L_po_sky[x]=" << t.Lpo().at(0) << ", [y]=";
	cout << t.Lpo().at(1) << ", [z]=" << t.Lpo().at(2) << "\n";
}

void fitter::newmoon()
// 2014 May 20 JWB
{
	Valuespanel.newmoon();
}


void fitter::newring()
// 2014 May 20 JWB
{
	Valuespanel.newring();
}


void fitter::newplanet()
// 2014 May 20 JWB
{
	Valuespanel.newplanet();
}


