#include "Jcrap.h"
#include <math.h>

template <class Datatype>
Datatype jabs(Datatype x)
{
	if (x >=0) return x;
	else return (-x);
}

template <class Datatype>
Datatype Jsqr(Datatype x)
{return x*x;};

template <class Datatype>
Datatype Jsign(Datatype a, Datatype b) { return (b) >= 0.0 ? fabs(a) : -fabs(a); }

template <class Datatype>
Datatype Jmax(Datatype a, Datatype b)
{
	if (a < b) return b;
	else return a;
}

template <class Datatype>
Datatype Jmin(Datatype a, Datatype b)
{
	if (a > b) return b;
	else return a;
}

#define NRANSI
template <class Datatype>
pair<Datatype, Datatype> Jpolint(Datatype *xa, Datatype *ya, int n, Datatype x)
// ASSUMES offset of 1 for arrays!
{
	int i,m,ns=1;
	Datatype den,dif,dift,ho,hp,w;
	vector<Datatype> c(n+1), d(n+1);
	pair<Datatype, Datatype> answer;
	Datatype &y(answer.first), &dy(answer.second);

	
	dif=jabs(x-xa[1]);	
//	cout << "inside Jpolint, dif=" << dif << "\n";
//	cout << "jabs(-3.14) = " << jabs(-3.14) << "\n";

	for (i=1;i<=n;i++) {
		if ( (dift=jabs(x-xa[i])) < dif) {
			ns=i;
			dif=dift;
		}
		c[i]=ya[i];
		d[i]=ya[i];
	}
	y=ya[ns--];
	for (m=1;m<n;m++) {
		for (i=1;i<=n-m;i++) {
			ho=xa[i]-x;
			hp=xa[i+m]-x;
			w=c[i+1]-d[i];
			if ( (den=ho-hp) == 0.0) cout << "Error in routine Jpolint\n";
			den=w/den;
			d[i]=hp*den;
			c[i]=ho*den;
		}
		y += (dy=(2*ns < (n-m) ? c[ns+1] : d[ns--]));
	}
	return answer;
}
#undef NRANSI




namespace NR {
	
	
class JChisqdist {
public:
	JChisqdist(double);
		
	int ngau;
	vector<double> y;
	vector<double> w;
	int ASWITCH;
	double EPS;
	double FPMIN;
	double gln;
	
	double gammp(const double, const double);
	double gammq(const double, const double);
	double gser(const double, const double);
	double gcf(const double, const double);
	double gammpapprox(double, double, int);
	double invgammp(double, double);


	double invcdf(double);

	double nu,fac;
};
	
	inline const double& MAX(const double &a, const double &b)
       	 {return b > a ? (b) : (a);}
	
	
	inline const double& MIN(const double &a, const double &b)
    	    {return b < a ? (b) : (a);}
	

}
