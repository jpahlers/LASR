#include "Jcrap.h"

namespace Jcrap {

cube addlatlonlines(const cube&, float, float, cube);
		
}
