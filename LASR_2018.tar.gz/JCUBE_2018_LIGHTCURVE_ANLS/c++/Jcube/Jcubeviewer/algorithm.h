#include <qwidget.h>
//Added by qt3to4:
#include <QMouseEvent>
#include "../Jcrap.h"
#include "controlpanel.h"


#include <qdialog.h>
#include <qpushbutton.h>
#include <q3buttongroup.h>
#include <q3buttongroup.h>
//#include <qhbuttongroup.h>
#include <qradiobutton.h>
#include <qlayout.h>
#include <qcheckbox.h>
#include <q3hbox.h>
#include <q3vbox.h>
#include <qlayout.h>
#include <qsplitter.h>
#include <qpushbutton.h>

#include "../Jprojections.h"
#ifndef ALGORITHM_H
#define ALGORITHM_H 1

class radiusdialog : public QDialog
{
	Q_OBJECT

public:
	radiusdialog(int, int, int, QWidget *parent=0, const char *name=0);
	int getxradius();
	int getyradius();
	int getzradius();
	double getsetvalue();
	
		
signals:
	void setradii();
	
private:
	QVBoxLayout dials;
	QHBoxLayout valuearea;
	QLabel valuelabel;
	QLineEdit valuebox;
	Jcrap::slidedial xdial;
	Jcrap::slidedial ydial;
	Jcrap::slidedial zdial;
	QPushButton	setbutton;
};

class algorithm : public QObject
{
	Q_OBJECT
	
	public:
		virtual ~algorithm() {;}
			
		virtual void action(QMouseEvent* e) = 0;
		virtual void releaseaction(QMouseEvent*) {}
	
		imagespace *ispace;	
};

class donothing : public algorithm
{
	public:
		donothing() {;}
	
		void action(QMouseEvent* e);
};

class dohazecontrast;


class clean : public algorithm
{
	public:
		clean();
		~clean() {;}
		
		void action(QMouseEvent* e);
		
	private:
		int xradius, yradius, zradius;
};


class makegraph : public algorithm
{
	public:
		makegraph(imagespace *);
		~makegraph() {;}
		
		void action(QMouseEvent* e);
};


class mosaic;

class mosaiccontrol : public Q3VBox
{
	Q_OBJECT
			
	public:
		mosaiccontrol(mosaic*);
		~mosaiccontrol();
	
	public slots:
			
		void load();
		void mesh();
		void save();
		void display();
		void display(int) {display();}
	
	public:
		Q3HBox 			buttonbox;
		QPushButton		loadbutton, meshbutton, savebutton;
		Q3VButtonGroup	addorreplace;
		QRadioButton	replacebutton, addbutton, smartbutton;	
		
		imagespace *addimage, *comboimage;
		
		mosaic* parentmosaic;
		
};

class mosaic : public algorithm
{
	
	public: 
		mosaic(imagespace *);
		~mosaic() {;}
	
		void action(QMouseEvent* e);
		
		void mosaicload();
		void mosaicsave();
		void mosaicmesh();
		void mosaicdisplay();
		
		mosaiccontrol& panel() {return mosaicpanel;}
		
	private:
		cube mosaicmerit, addedmerit, combomerit;
		cube mosaiccube, tobeadded, combo;
		mosaiccontrol mosaicpanel;
		int xoffset, yoffset;
		
};

class zero : public algorithm
{
	Q_OBJECT
			
	public:
		zero(int, int, int);
		~zero();
		
		void action(QMouseEvent* e);
		
	public slots:
		void getradiivalues();
		
	private:
		int xradius, yradius, zradius;
		double value_to_set;
		radiusdialog r;
};

class Jmask;

class maskcontrol : public Q3VBox
{
	Q_OBJECT
			
	public:
		maskcontrol(cube&, Jmask*);
	
		void reload(cube&);
		
		int behavior();
			
	public slots:
			
		void color();
		void graph();
		void load();
		void save();
		
	private:
		imagespace *maskspace;
		Jmask *thismask;
		Q3HButtonGroup	addsub;
		QRadioButton	addbutton, subtractbutton, invertbutton;	
		QPushButton		colorbutton, graphbutton, loadbutton, savebutton;
		
};

class Jmask : public algorithm
{
	public:
		Jmask(imagespace*);
		~Jmask() {;}
		
		void action(QMouseEvent* e);
		void releaseaction(QMouseEvent* e);
		cube& maskimage() { return imagemask; }
		cube spectrum();
		cube maskedimage();
		imagespace& masterimagespace();
		
	private:
		cube imagemask;
		maskcontrol Maskcontrol;
		pair<int, int> corner;
		
	public:
		float R, G, B;
};


/* class polygoncoordview : public Q3Grid
{
	Q_OBJECT
			
	public:
		polygoncoordview(QWidget *parent=0, const char *name=0);
			
	public slots:
		void writepolycoordinfo(double, double);

	private:
		QLabel		latlabel;
		QLabel		lonlabel;
		QLCDNumber	latnum;
		QLCDNumber	lonnum;
	
}; */

class Jpolygon;

class polygoncontrol : public Q3VBox
{
	Q_OBJECT
			
	public:
		polygoncontrol(cube&, Jpolygon*);
	
		void reload(cube&);
		void reload();
		
		//polygoncoordview& polygoncoordinfo() {return polycoordinfo;}
		
		void setpolygonnumber(unsigned int);
		
	public slots:
			
		void deletelast(); 
		void color();
		void togglefill();
		void load();
		void save();
		
		void addnewpolygon();
		void deletepolygon();
		void nextpolygon();
		
		
				
		unsigned int polygonnumber() {return polygonN;}
		
	private:
		imagespace *polygonspace;
		Jpolygon *thispolygon;	
		
		
		
		QPushButton nextpolygonbutton, addpolygonbutton, deletethispolygonbutton;
		QPushButton	subtractbutton, colorbutton, filledbutton, loadbutton, savebutton;
		unsigned int polygonN;
	//	polygoncoordview polycoordinfo;
};

class Jpolygon : public algorithm
{
	public:
		Jpolygon(imagespace*);
		~Jpolygon() {;}
		
		void action(QMouseEvent* e);
		cube& polygonimage() { return imagepolygon; }
		cube polygonedimage();
		imagespace& masterimagespace();
		void filled(bool);
		bool filled() {return _filled;}
		void generateimagepolygon();
	
		void deletelast();
		
		unsigned int size();
		void addnewpolygon();
		void deletepolygon(unsigned int);
		void set_Jpolygon_projtype(cube);//smack 3.16
		void Jpolygon_projtype(projtype); //smack 3.16
		projtype Jpolygon_projtype(){return _Jpolygon_projtype;} //smack 3.16
		
		void Jpolygon_projection(projection*);//smack 3.16
		projection* Jpolygon_projection(){return _Jpolygon_projection;}//smack 3.16
		
		void Jpolygon_lonconvention(lonconvention);
		lonconvention Jpolygon_lonconvention(){return _Jpolygon_lonconvention;}
		
		cube polygonvertexcube();
		void polygonvertexcube(cube);
		

		
	private:
		cube imagepolygon;
		projtype _Jpolygon_projtype; //smack 3.16
		projection* _Jpolygon_projection; //smack 3.16
		lonconvention _Jpolygon_lonconvention; //smack 3.16
	
		polygoncontrol Polygoncontrol;
		vector<vector<pair<lonangle, latangle> > > polygon; //smack 3.16
		bool _filled;
		
		
	
	public:
		float R, G, B;
};

#endif
