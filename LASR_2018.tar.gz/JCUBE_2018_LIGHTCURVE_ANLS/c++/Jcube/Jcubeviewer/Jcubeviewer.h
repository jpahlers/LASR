#ifndef Jcubeviewer_h 
#define Jcubeviewer_h 1

#include <Q3MainWindow>
#include <Q3PopupMenu>
#include <qmenubar.h>

#include <Jcubeview.h>
#include "../Jcrap.h"

class Jcrap::cubeviewer : public Q3MainWindow
{
	Q_OBJECT

public:
	cubeviewer(QWidget *parent=0, const char *name=0, const char *startfile=0);

private slots:
	void loadfile();
	void savefile();
	void saveimage();
	void quit();
	
	void loadwave();
	void createcolor();
	void createclassify();
	void loadmapoffsets();
	void subtracthelper();

	void loadmosaic();
	void loadmask();
	void loadpolygon();
	void loadclean();
	void loadzero();
	void loadgraph();
	
	void crop();
	void splice();

private:
	Jcrap::cubeview Cubeview;
	Q3PopupMenu FILEmenu;
	Q3PopupMenu ACTIONSmenu;
	Q3PopupMenu ALGORITHMSmenu;
	Q3PopupMenu MANIPULATIONSmenu;
};

#endif
