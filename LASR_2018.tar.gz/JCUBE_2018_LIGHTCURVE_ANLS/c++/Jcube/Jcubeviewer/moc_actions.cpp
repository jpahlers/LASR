/****************************************************************************
** Meta object code from reading C++ file 'actions.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "actions.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'actions.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_colorassign[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x05,

 // slots: signature, parameters, type, tag, flags
      35,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_colorassign[] = {
    "colorassign\0\0clicked(colorassign&)\0"
    "emitclicked()\0"
};

void colorassign::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        colorassign *_t = static_cast<colorassign *>(_o);
        switch (_id) {
        case 0: _t->clicked((*reinterpret_cast< colorassign(*)>(_a[1]))); break;
        case 1: _t->emitclicked(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData colorassign::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject colorassign::staticMetaObject = {
    { &Q3HBox::staticMetaObject, qt_meta_stringdata_colorassign,
      qt_meta_data_colorassign, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &colorassign::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *colorassign::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *colorassign::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_colorassign))
        return static_cast<void*>(const_cast< colorassign*>(this));
    return Q3HBox::qt_metacast(_clname);
}

int colorassign::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3HBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void colorassign::clicked(colorassign & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_colorcube[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x0a,
      20,   10,   10,   10, 0x0a,
      46,   10,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_colorcube[] = {
    "colorcube\0\0reject()\0assignimage(colorassign&)\0"
    "colorsave(colorassign&)\0"
};

void colorcube::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        colorcube *_t = static_cast<colorcube *>(_o);
        switch (_id) {
        case 0: _t->reject(); break;
        case 1: _t->assignimage((*reinterpret_cast< colorassign(*)>(_a[1]))); break;
        case 2: _t->colorsave((*reinterpret_cast< colorassign(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData colorcube::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject colorcube::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_colorcube,
      qt_meta_data_colorcube, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &colorcube::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *colorcube::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *colorcube::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_colorcube))
        return static_cast<void*>(const_cast< colorcube*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int colorcube::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}
static const uint qt_meta_data_classifycube[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x0a,
      27,   13,   13,   13, 0x0a,
      39,   13,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_classifycube[] = {
    "classifycube\0\0colorgraph()\0stabilize()\0"
    "savemap()\0"
};

void classifycube::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        classifycube *_t = static_cast<classifycube *>(_o);
        switch (_id) {
        case 0: _t->colorgraph(); break;
        case 1: _t->stabilize(); break;
        case 2: _t->savemap(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData classifycube::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject classifycube::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_classifycube,
      qt_meta_data_classifycube, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &classifycube::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *classifycube::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *classifycube::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_classifycube))
        return static_cast<void*>(const_cast< classifycube*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int classifycube::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}
static const uint qt_meta_data_colordialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_colordialog[] = {
    "colordialog\0\0RGBset()\0"
};

void colordialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        colordialog *_t = static_cast<colordialog *>(_o);
        switch (_id) {
        case 0: _t->RGBset(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData colordialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject colordialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_colordialog,
      qt_meta_data_colordialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &colordialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *colordialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *colordialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_colordialog))
        return static_cast<void*>(const_cast< colordialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int colordialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_mapoffsets[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x0a,
      27,   11,   11,   11, 0x0a,
      40,   11,   11,   11, 0x0a,
      48,   11,   11,   11, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_mapoffsets[] = {
    "mapoffsets\0\0loadtemplate()\0loadoffset()\0"
    "shift()\0blink()\0"
};

void mapoffsets::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        mapoffsets *_t = static_cast<mapoffsets *>(_o);
        switch (_id) {
        case 0: _t->loadtemplate(); break;
        case 1: _t->loadoffset(); break;
        case 2: _t->shift(); break;
        case 3: _t->blink(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData mapoffsets::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject mapoffsets::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_mapoffsets,
      qt_meta_data_mapoffsets, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &mapoffsets::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *mapoffsets::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *mapoffsets::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_mapoffsets))
        return static_cast<void*>(const_cast< mapoffsets*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int mapoffsets::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
static const uint qt_meta_data_subhelper[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_subhelper[] = {
    "subhelper\0\0recalculate(int)\0"
};

void subhelper::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        subhelper *_t = static_cast<subhelper *>(_o);
        switch (_id) {
        case 0: _t->recalculate((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData subhelper::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject subhelper::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_subhelper,
      qt_meta_data_subhelper, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &subhelper::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *subhelper::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *subhelper::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_subhelper))
        return static_cast<void*>(const_cast< subhelper*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int subhelper::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
