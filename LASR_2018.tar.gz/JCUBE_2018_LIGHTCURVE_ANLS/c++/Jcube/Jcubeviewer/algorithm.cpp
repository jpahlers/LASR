#include <iostream>
#include <q3filedialog.h>
//Added by qt3to4:
#include <QMouseEvent>

#include "algorithm.h"
#include "actions.h"
#include "imagespace.h"

radiusdialog::radiusdialog(int xhi, int yhi, int zhi, 
									QWidget *parent, const char *name)
	: QDialog(parent, name),
	dials(this),
	xdial("Xradius: ", this),
	ydial("Yradius: ", this),
	zdial("Zradius: ", this),
	setbutton("Set Radius", this)
{
	dials.addWidget(&xdial);
	dials.addWidget(&ydial);
	dials.addWidget(&zdial);
	dials.addWidget(&setbutton);
	setLayout(&dials);
	
	xdial.rerange(-1, xhi);
	xdial.value(1);
	ydial.rerange(-1, yhi);
	ydial.value(1);	
	zdial.rerange(-1, zhi);
	zdial.value(1);
	
	connect(&setbutton, SIGNAL(clicked()), this, SIGNAL(setradii()));
}

int radiusdialog::getxradius() { return xdial.value(); }
int radiusdialog::getyradius() { return ydial.value(); }
int radiusdialog::getzradius() { return zdial.value(); }


void donothing::action(QMouseEvent* e)
{
	e->x();
}


clean::clean()
{
	xradius = 1;
	yradius = 1;
	zradius = 0;
}

void clean::action(QMouseEvent* e)
{
	pair<int, int> xy(ispace->spacecoordinates(e));  // get x, y for e
	
	float n=0., &answer(ispace->imagecube()(xy.first, xy.second,
			ispace->startplane()));
	answer = 0.;
	
	for (int z=ispace->startplane()-zradius;z<=ispace->startplane()+zradius;z++) {
		for (int y=xy.second-yradius;y<=xy.second+yradius;y++) {
			for (int x=xy.first-xradius;x<=xy.first+xradius;x++) {
				if (x>=0 && x<ispace->imagecube().N(X)  &&
					 y>=0 && y<ispace->imagecube().N(Y)  &&
					 z>=0 && z<ispace->imagecube().N(Z)  &&
					 !(x==xy.first && y==xy.second && z==ispace->startplane()) ) {
					n+=1.;
					answer += ispace->imagecube()(x,y,z);
				}
			}
		}
	}
	
	answer /= n;
	
	ispace->setimageplane(ispace->dimension());
}

zero::zero(int xhi, int yhi, int zhi) : r(xhi, yhi, zhi, 0)
{	
	connect(&r, SIGNAL(setradii()), this, SLOT(getradiivalues()));
	
	r.show();
	r.raise();
	r.setActiveWindow();
	getradiivalues();
}


void zero::getradiivalues()
{
	xradius = r.getxradius();
	yradius = r.getyradius();
	zradius = r.getzradius();
	cout << "Assigning radii values x=" << xradius << "; y=" << yradius << "; z=";
	cout << zradius << "\n";
}

void zero::action(QMouseEvent* e)
{
	pair<int, int> xy(ispace->spacecoordinates(e));  // get x, y for e
	
	float &answer(ispace->imagecube()(xy.first, xy.second, ispace->startplane()));
	answer = 0.;
	
	if (xradius==-1) xradius = ispace->imagecube().N(X);
	if (yradius==-1) yradius = ispace->imagecube().N(Y);
	int zstart, zstop;
	if (zradius == -1) {
		zstart = 0;
		zstop = ispace->imagecube().N(Z)-1;
	} else {
		zstart = ispace->startplane()-zradius;
		zstop  = ispace->startplane()+zradius;
	}
	if (zstart < 0) zstart = 0;
	if (zstop >= ispace->imagecube().N(Z)) zstart = ispace->imagecube().N(Z)-1;
	
	for (int z=zstart;z<=zstop;z++) {
		for (int y=xy.second-yradius;y<=xy.second+yradius;y++) {
			for (int x=xy.first-xradius;x<=xy.first+xradius;x++) {
				if (x>=0 && x<ispace->imagecube().N(X)  &&
					 y>=0 && y<ispace->imagecube().N(Y)  &&
					 z>=0 && z<ispace->imagecube().N(Z)  &&
					 !(x==xy.first && y==xy.second && z==ispace->startplane()) ) {
					ispace->imagecube()(x,y,z) = 0.;
				}
			}
		}
	}
		
	ispace->setimageplane(ispace->dimension());
}

makegraph::makegraph(imagespace* i)
{
	ispace = i;
}

void makegraph::action(QMouseEvent* e)
{
	pair<int, int> xy(ispace->spacecoordinates(e));  // get x, y for e
	
	cube plotcube;
	plotcube = ispace->imagecube().skewer(ispace->dimension(), xy.first, xy.second);
//	plotcube = plotcube.stripneg();
	
	string title(string("Pixel ")+int2str(xy.first)+", "+int2str(xy.second));
	plotcube.keyword("title", title);
	
	char limits[1000];
	sprintf(limits, "-y %f %f", ispace->scaling().first,
			ispace->scaling().second);
	
	plotcube.graph(limits);
}

mosaiccontrol::mosaiccontrol(mosaic *m) :
	Q3VBox(0, "Mosaic Control Center"),
	buttonbox(this, "Buttonholder"),
	loadbutton("Load", &buttonbox, "Loading Button"),
	meshbutton("Mesh", &buttonbox, "Meshing Button"),
	savebutton("Save", &buttonbox, "Saving Button"),
	addorreplace("Behavior", &buttonbox, "Addorreplace Buttongroup"),
	replacebutton("Replace", &addorreplace, "Replacing Button"),
	addbutton("Add", &addorreplace, "Adding Button"),
	smartbutton("Smart", &addorreplace, "Smarting Button"),
	addimage(0),
	comboimage(0),
	parentmosaic(m)
{
	cout << "Creating mosaiccontrol\n";
	addorreplace.insert(&replacebutton,0);
	addorreplace.insert(&addbutton,1);
	addorreplace.insert(&smartbutton,2);
	addorreplace.setButton(2);
	
	cout << "Adding imagespace\n";
	addimage = new imagespace(this,"Add Image Space");
	comboimage = new imagespace(this,"Combo Image Space");
	
	cout << "Connecting signals/slots\n";
	connect(&loadbutton, SIGNAL(clicked()), 
			this, SLOT(load()));
	connect(&savebutton, SIGNAL(clicked()), 
			this, SLOT(save()));
	connect(&meshbutton, SIGNAL(clicked()), 
			this, SLOT(mesh()));
	connect(&addorreplace, SIGNAL(clicked(int)), 
			this, SLOT(display(int)));
	
	cout << "show()\n";
	show();
	cout << "Created mosaiccontrol\n";
}

void mosaiccontrol::load() { parentmosaic->mosaicload(); }
void mosaiccontrol::mesh() { parentmosaic->mosaicmesh(); }
void mosaiccontrol::save() { parentmosaic->mosaicsave(); }
void mosaiccontrol::display() { parentmosaic->mosaicdisplay(); }

mosaic::mosaic(imagespace *i) :
	mosaicpanel(this),
	xoffset(0),
	yoffset(0)
{
	ispace = i;
	panel().addimage->Algorithm = this;
}

mosaiccontrol::~mosaiccontrol() { delete addimage; delete comboimage;}

void mosaic::action(QMouseEvent *e)
{
	static int clickno(0);
	static pair<int, int> firstxy;

	cout << "Mosaic Mouse Click, main window\n";	
// if this is a click:
	if (clickno == 0) {
		firstxy = panel().addimage->spacecoordinates(e);
		clickno = 1;
	} else {
		pair<int, int> secondxy(ispace->spacecoordinates(e));
		xoffset = secondxy.first-firstxy.first;
		yoffset = secondxy.second-firstxy.second;
		clickno = 0;
		mosaicdisplay();
	}
		
}

void mosaic::mosaicload()
{
	QString filename=Q3FileDialog::getOpenFileName("./", "*cyl*Jcube *mosaic*Jcube", &mosaicpanel);
	
	if (filename.length()) {
		tobeadded = cube(filename.toStdString());
		string meritname, origname=filename.toStdString();
		if (origname.find(".cyl.Jcube") != string::npos)
			meritname = origname.substr(0, origname.find(".cyl.Jcube"));
		if (origname.find(".mosaic.Jcube") != string::npos)
			meritname = origname.substr(0, origname.find(".mosaic.Jcube"));
		cout << "Orig name=" << origname << "\n";
		cout << "Meritroot name=" << meritname << "\n";
		meritname+= ".merit.Jcube";
		cout << "Meritname = " << meritname << "\n";
		addedmerit = cube(meritname);
		
		if (mosaiccube.N(X) == 1) { // if this is the first one, set stuff up
			mosaiccube=tobeadded * 0.;
			mosaicmerit = addedmerit * 0.;
			combo=tobeadded * 0.;
			combomerit = addedmerit *0.;
		}
	}
		
	mosaicdisplay();
}

void mosaic::mosaicmesh()
{
	mosaiccube = combo;
	mosaicmerit = combomerit;
	mosaicdisplay();
}

void mosaic::mosaicsave()
{	
	QString filename=Q3FileDialog::getSaveFileName("./", "*.mosaic.Jcube", &mosaicpanel);

	if (filename.length()) mosaiccube.write(filename.ascii());	
	string meritname, origname=filename.toStdString();
	meritname = origname.substr(0, origname.find(".mosaic.Jcube")) ;
	cout << "Orig name=" << origname << "\n";
	cout << "Meritroot name=" << meritname << "\n";
	meritname+= ".merit.Jcube";
	cout << "Meritname = " << meritname << "\n";
	mosaicmerit.write(meritname.c_str());

}

void mosaic::mosaicdisplay()
{
	int superresolution=
			mosaicpanel.addorreplace.id(mosaicpanel.addorreplace.selected());
	cout << "Superresolution = " << superresolution << " : " <<
			mosaicpanel.addorreplace.selected() << "\n";
	
// first, mesh the cubes
	combo = mosaiccube;
	combomerit = mosaicmerit;
	for (int x=0;x<mosaiccube.N(X);x++) {
		for (int y=0;y<mosaiccube.N(Y);y++) {
			int addx=x-xoffset;
			int addy=y-yoffset;
			if (addy>tobeadded.N(Y)-1 || addy<0) continue;
			if (addx>tobeadded.N(X)-1 || addx<0) continue;
		// superimpose good pixels over less-good pixels
			if ((!superresolution  &&  addedmerit(addx,addy,0) > mosaicmerit(x,y,0))) {
				for (int z=0;z<mosaiccube.N(Z);z++) {
					if (tobeadded(addx,addy,z) > 0.) { // leave out zeroes and saturated pixels
						combo(x,y,z) = tobeadded(addx,addy,z);
						combomerit(x,y,1+z) = addedmerit(addx,addy,z);
					}
				}	
				combomerit(x,y,0) = addedmerit(addx,addy,0);
			}
		// add frames together, or smart
			if (superresolution) {
				for (int z=0;z<mosaiccube.N(Z);z++) {
					if (mosaiccube(x,y,z) && 
							(superresolution==1 || 
								(superresolution==2 && // "smart"
									(addedmerit(addx,addy,0)>0.5*mosaicmerit(x,y,0) &&
									 addedmerit(addx,addy,0)<2.0*mosaicmerit(x,y,0))))) {
						double newintegrationtime(mosaicmerit(x,y,1+z)+addedmerit(addx,addy,1+z));
						combo(x,y,z) = (mosaiccube(x,y,z)*mosaicmerit(x,y,1+z) +
							tobeadded(addx,addy,z)*addedmerit(addx,addy,1+z))/newintegrationtime;
						combomerit(x,y,1+z) = newintegrationtime;
					} else if (tobeadded(addx,addy,z) > 0 && (superresolution==1 ||
								  (superresolution==2 && 
									addedmerit(addx,addy,0)>mosaicmerit(x,y,0)))) { // replace, if there's nothing there yet, or if this is
								// way better (smart only on the 2nd part).
						combo(x,y,z) = tobeadded(addx,addy,z);
						combomerit(x,y,1+z) = addedmerit(addx,addy,z);
					}
				}
				if (addedmerit(addx,addy,0) > mosaicmerit(x,y,0)){					
					combomerit(x,y,0) = addedmerit(addx,addy,0);
				}
			}
		}
	}
	
	cube r, g, b, colorcube;
	if (mosaiccube.N(Z) == 352) {
		r = mosaiccube.plane(Z,336,351) / (0.07*16);
		g = mosaiccube.plane(Z,165) / 0.22;
		b = mosaiccube.plane(Z,139) / 0.27;	
	} else {
		r = mosaiccube(-1,-1,-1,-1,4.84 , 5.2).plane(Z) / (0.07*16);
		g = mosaiccube(-1,-1,-1,-1,1.995, 2.00) / 0.22;
		b = mosaiccube(-1,-1,-1,-1,1.569, 1.571) / 0.27;
	}
		
	colorcube = r.blocksz(g).blocksz(b);
	
	ispace->load(colorcube);	
	ispace->setscaling(0., 1.);
	
	if (tobeadded.N(Z) == 352) {
		r = tobeadded.plane(Z,336,351) / (0.07*16);
		g = tobeadded.plane(Z,165) / 0.22;
		b = tobeadded.plane(Z,139) / 0.27;	
	} else {
		r = tobeadded(-1,-1,-1,-1,4.84 , 5.2).plane(Z) / (0.07*16);
		g = tobeadded(-1,-1,-1,-1,1.995, 2.00) / 0.22;
		b = tobeadded(-1,-1,-1,-1,1.569, 1.571) / 0.27;
	}
		
	colorcube = r.blocksz(g).blocksz(b);
	
	panel().addimage->load(colorcube);
	panel().addimage->setscaling(0., 1.);	
	
	if (combo.N(Z) == 352) {
		r = combo.plane(Z,336,351) / (0.07*16);
		g = combo.plane(Z,165) / 0.22;
		b = combo.plane(Z,139) / 0.27;	
	} else {
		r = combo(-1,-1,-1,-1,4.84 , 5.2).plane(Z) / (0.07*16);
		g = combo(-1,-1,-1,-1,1.995, 2.00) / 0.22;
		b = combo(-1,-1,-1,-1,1.569, 1.571) / 0.27;
	}
		
	colorcube = r.blocksz(g).blocksz(b);
	
	panel().comboimage->load(colorcube);
	panel().comboimage->setscaling(0., 1.);
}

changeclassify::changeclassify(imagespace *i, classifycube *c)
{
	ispace = i;
	classifywindow = c;
}

void changeclassify::action(QMouseEvent *e)
{
	static pair<int, int> xy;

	cout << "Classify tree mouse click:  ";
	xy = ispace->spacecoordinates(e);
	cout << xy.first << ", " << xy.second << "\n";
	
	classifywindow->reclassify(xy.first, xy.second);
}

maskcontrol::maskcontrol(cube &c, Jmask *t) : 
	Q3VBox(0, "Mask Control Center"),
	maskspace(new imagespace(c, this, "Mask Imagespace")),
	thismask(t),
	addsub("Behavior", this, "Mask Behavior Buttongroup"),
	addbutton("Add", &addsub, "Add Button"),
	subtractbutton("Sub", &addsub, "Sub Button"),
	invertbutton("Inv", &addsub, "Inv Button"),
	colorbutton("Color", this, "Loading Button"),
	graphbutton("Graph", this, "Graphing Button"),
	loadbutton("Load", this, "Loading Button"),
	savebutton("Save", this, "Saving Button")
{
	addsub.insert(&addbutton,0);
	addsub.insert(&subtractbutton,1);
	addsub.insert(&invertbutton,2);
	addsub.setButton(0);
	addsub.setMaximumSize(4000,70);
	
	connect(&colorbutton, SIGNAL(clicked()), 
			this, SLOT(color()));
	connect(&graphbutton, SIGNAL(clicked()), 
			this, SLOT(graph()));
	connect(&loadbutton, SIGNAL(clicked()), 
			this, SLOT(load()));
	connect(&savebutton, SIGNAL(clicked()), 
			this, SLOT(save()));
	
	thismask->maskimage().copyaxis(c, X);
	thismask->maskimage().copyaxis(c, Y);
	
	
	show();
}

void maskcontrol::reload(cube&) 
{ 
	maskspace->load(thismask->maskedimage()); 
	maskspace->setscaling(0.,1.);
}

void maskcontrol::color()
{
	colordialog cd(this, thismask->R, thismask->G, thismask->B);
	thismask->R = cd.R;
	thismask->G = cd.G;
	thismask->B = cd.B;
	
	cube &m(thismask->maskimage());
	for (int x=0;x<m.N(X);x++) {
		for (int y=0;y<m.N(Y);y++) {
			if ((m(x,y,0)!=0. && m(x,y,0) != thismask->R)  ||
				 (m(x,y,1)!=0. && m(x,y,1) != thismask->G)  ||
				 (m(x,y,2)!=0. && m(x,y,2) != thismask->B)) {
				m(x,y,0) = thismask->R;
				m(x,y,1) = thismask->G;
				m(x,y,2) = thismask->B;
			}	
		}
	}
	
	reload(m);
}

void maskcontrol::graph()
{
	thismask->spectrum().graph();
}

void maskcontrol::load()
{
	QString filename=Q3FileDialog::getOpenFileName("./", 
			"*mask.Jcube", this);
	
	if (filename.length()) {
		thismask->maskimage() = cube(filename.toStdString());
		reload(thismask->maskimage());
	}
}

void maskcontrol::save()
{
	QString filename=Q3FileDialog::getSaveFileName("./", "*mask.Jcube", this);

	if (filename.length()) {
		
		thismask->maskimage().write(filename.ascii());	
	}
	
	string specname, origname=filename.toStdString();
	specname = origname.substr(0, origname.find(".mask.Jcube")) ;
	cout << "Orig name=" << origname << "\n";
	cout << "Specroot name=" << specname << "\n";
	specname+= ".maskspectrum.Jcube";
	cout << "Specname = " << specname << "\n";
	thismask->spectrum().write(specname.c_str());
	
	string maskedname;
	maskedname = origname.substr(0, origname.find(".mask.Jcube")) ;
	maskedname+= ".masked.tif";
	thismask->maskedimage().totif().write(maskedname.c_str(),0., 1.);	
	
	string masktifname;
	masktifname = origname.substr(0, origname.find(".mask.Jcube")) ;
	masktifname+= ".mask.tif";
	thismask->maskimage().totif().write(masktifname.c_str(),0., 1.);
}

int maskcontrol::behavior() 
{ 
	if (addbutton.isChecked()) return 0;
	if (subtractbutton.isChecked()) return 1;
	if (invertbutton.isChecked()) return 2;
	return 0; // just in case
}


Jmask::Jmask(imagespace *i) :
	imagemask(),
	Maskcontrol(imagemask, this),
	R(1.), G(1.), B(1.)
{
	ispace = i;
	imagemask = cube(ispace->imagecube().N(X),ispace->imagecube().N(Y),3,0.);
	imagemask.copyaxis(ispace->imagecube(), X);
	imagemask.copyaxis(ispace->imagecube(), Y);
	Maskcontrol.reload(imagemask);
}

cube Jmask::spectrum()
{
	cube answer(ispace->imagecube().skewer(Z,0,0)*0.);
	int n=0;
	for (int x=0;x<ispace->imagecube().N(X);x++) {
		for (int y=0;y<ispace->imagecube().N(Y);y++) {
			if (imagemask(x,y,0)!=0.  ||  imagemask(x,y,1)!=0.  ||
				 imagemask(x,y,2)!=0.) {
				n++;
				answer += ispace->imagecube().skewer(Z,x,y);
			}
		}
	}	
	return answer/float(n);
}

void Jmask::action(QMouseEvent *e)
{
	corner = ispace->spacecoordinates(e);
}

void Jmask::releaseaction(QMouseEvent *e)
{
	static pair<int, int> xy;
	
	xy = ispace->spacecoordinates(e);
	
	cout << "filling in from (" << corner.first << "," << corner.second << ") to (";
	cout << xy.first << "," << xy.second << ")\n";
	
	// these are to allow for boxes that don't go from upper left to lower right.
	int xpm(xy.first-corner.first); 
	if (xpm) xpm/=abs(xpm);
	int ypm(xy.second-corner.second);
	if (ypm) ypm/=abs(ypm);
	xy.first += xpm;  // to make the != line work in the loops
	xy.second+= ypm;
	
	for (int x=corner.first;;x+=xpm) {
		for (int y=corner.second;;y+=ypm) {
			if (Maskcontrol.behavior() == 0) {
				imagemask(x, y, 0) = R;
				imagemask(x, y, 1) = G;
				imagemask(x, y, 2) = B;
			}
			if (Maskcontrol.behavior() == 1) {
				imagemask(x, y, 0) = 0.;
				imagemask(x, y, 1) = 0.;
				imagemask(x, y, 2) = 0.;
			}
			if (Maskcontrol.behavior() == 2) {
				if (imagemask(x,y,0) == 0.  &&
					 imagemask(x,y,1) == 0.  &&
					 imagemask(x,y,2) == 0.) {
					imagemask(x, y, 0) = R;
					imagemask(x, y, 1) = G;
					imagemask(x, y, 2) = B;
				}
				else
					imagemask(x, y, 0) = 0.;
			}
			if (y==xy.second) break;
			
		}
		if (x==xy.first) break;
	}
		
	Maskcontrol.reload(imagemask);
	
}

cube Jmask::maskedimage()
{
	cube answer(masterimagespace().imageplane());
	if (answer.N(Z) == 1)
		answer = answer.blocksz(answer).blocksz(answer);
	
	answer += imagemask;
	answer -= masterimagespace().scaling().first;
	answer /= masterimagespace().scaling().second;
	
	return answer;
}

imagespace& Jmask::masterimagespace() { return *ispace; }


polygoncontrol::polygoncontrol(cube &c, Jpolygon *t) : 
	Q3VBox(0, "Polygon Control Center"),
	polygonspace(new imagespace(c, this, "Polygon Imagespace")),
	thispolygon(t),
	nextpolygonbutton("Next Polygon (presently 0)", this, "NextPolygon Button"),
	addpolygonbutton("Add New Polygon", this, "AddPolygon Button"),
	deletethispolygonbutton("Delete This Polygon", this, "DeletePolygon Button"),
	subtractbutton("Delete last point", this, "Subtract Button"),
	colorbutton("Color", this, "Loading Button"),
	filledbutton("Unfilled", this, "Filling Button"),
	loadbutton("Load", this, "Loading Button"),
	savebutton("Save", this, "Saving Button"),
	polygonN(0)
{
	connect(&nextpolygonbutton, SIGNAL(clicked()),
			this, SLOT(nextpolygon()));
	connect(&addpolygonbutton, SIGNAL(clicked()),
			this, SLOT(addnewpolygon()));
	connect(&deletethispolygonbutton, SIGNAL(clicked()),
			this, SLOT(deletepolygon()));	
	
	connect(&subtractbutton, SIGNAL(clicked()), 
			this, SLOT(deletelast()));
	connect(&colorbutton, SIGNAL(clicked()), 
			this, SLOT(color()));
	connect(&filledbutton, SIGNAL(clicked()), 
			this, SLOT(togglefill()));
	connect(&loadbutton, SIGNAL(clicked()), 
			this, SLOT(load()));
	connect(&savebutton, SIGNAL(clicked()), 
			this, SLOT(save()));
	
	thispolygon->polygonimage().copyaxis(c, X);
	thispolygon->polygonimage().copyaxis(c, Y);
	
	show();
}

void polygoncontrol::setpolygonnumber(unsigned int inN)
{
	polygonN=inN;
	if (polygonN >= thispolygon->size()-1)
		polygonN = thispolygon->size()-1;
	string newbuttontext("Next Polygon (presently ");
	newbuttontext+=int2str(int(polygonN));
	newbuttontext+=string(")");
	nextpolygonbutton.setText(QString::fromStdString(newbuttontext));
}

void polygoncontrol::nextpolygon()
{
	unsigned int newN(polygonN+1);
	if (polygonN >= thispolygon->size()-1) newN=0;
	setpolygonnumber(newN);
}

void polygoncontrol::addnewpolygon()
{
	thispolygon->addnewpolygon();
	setpolygonnumber(thispolygon->size()-1);
}


void polygoncontrol::deletepolygon()
{
	thispolygon->deletepolygon(polygonN);
	setpolygonnumber(polygonN-1);
	if (thispolygon->size()==0) addnewpolygon();
	reload();
}



void polygoncontrol::deletelast() 
{
	thispolygon->deletelast();
	reload();
}

void polygoncontrol::reload(cube&) 
{ 
	polygonspace->load(thispolygon->polygonedimage()); 
	cout << "polygon Reloading\n";
	thispolygon->polygonedimage().write("polygoned.Jcube");
	polygonspace->setscaling(0.,1.);
}


void polygoncontrol::reload() 
{ 
	thispolygon->generateimagepolygon();
	reload(thispolygon->polygonimage());
}

void polygoncontrol::color()
{
	colordialog cd(this, thispolygon->R, thispolygon->G, thispolygon->B);
	thispolygon->R = cd.R;
	thispolygon->G = cd.G;
	thispolygon->B = cd.B;
	
	cube &m(thispolygon->polygonimage());
	for (int x=0;x<m.N(X);x++) {
		for (int y=0;y<m.N(Y);y++) {
			if ((m(x,y,0)!=0. && m(x,y,0) != thispolygon->R)  ||
				 (m(x,y,1)!=0. && m(x,y,1) != thispolygon->G)  ||
				 (m(x,y,2)!=0. && m(x,y,2) != thispolygon->B)) {
				m(x,y,0) = thispolygon->R;
				m(x,y,1) = thispolygon->G;
				m(x,y,2) = thispolygon->B;
			}	
		}
	}
	
	reload(m);
}

void polygoncontrol::togglefill()
{
	thispolygon->filled(!(thispolygon->filled()));
	if (thispolygon->filled()) filledbutton.setText("Filled");
	else filledbutton.setText("Unfilled");
	thispolygon->generateimagepolygon();
}

void polygoncontrol::load()
{
	QString filename=Q3FileDialog::getOpenFileName("./", 
			"*polygonvertex.Jcube", this);
	
	if (filename.length()) {
		thispolygon->polygonvertexcube(cube(filename.toStdString()));
		reload();
	}
}

void polygoncontrol::save()
{
	QString filename=Q3FileDialog::getSaveFileName("./", "*polygon.Jcube", this);

	string origname=filename.toStdString();
	if (origname.find(".polygon.Jcube")==string::npos)
		origname += string(".polygon.Jcube");
	
	if (filename.length()) {
		
		thispolygon->polygonimage().write(filename.ascii());	
	}
	

	
	string polygonedname;
	polygonedname = origname.substr(0, origname.find(".polygon.Jcube")) ;
	polygonedname+= ".polygoned.tif";
	thispolygon->polygonedimage().totif().write(polygonedname.c_str(),0., 1.);	
	
	string polygontifname;
	polygontifname = origname.substr(0, origname.find(".polygon.Jcube")) ;
	polygontifname+= ".polygon.tif";
	thispolygon->polygonimage().totif().write(polygontifname.c_str(),0., 1.);
	
	
	string polygonvertexname;
	polygonvertexname = origname.substr(0, origname.find(".polygon.Jcube")) ;
	polygonvertexname+= ".polygonvertex.Jcube";
	cube outcube(thispolygon->polygonvertexcube());
	outcube.keyword("Name", polygonvertexname);
	outcube.write(polygonvertexname.c_str());
	
}


Jpolygon::Jpolygon(imagespace *i) :
	imagepolygon(),
	Polygoncontrol(imagepolygon, this),
	_filled(false),
	R(1.), G(1.), B(1.)
{
	ispace = i;
	imagepolygon = cube(ispace->imagecube().N(X),ispace->imagecube().N(Y),3,0.);
	imagepolygon.copyaxis(ispace->imagecube(), X);
	imagepolygon.copyaxis(ispace->imagecube(), Y);
	addnewpolygon();
	Polygoncontrol.reload(imagepolygon);
}

void Jpolygon::filled(bool b)
{
	_filled=b;
}

void Jpolygon::action(QMouseEvent *e)
{
	polygon.at(Polygoncontrol.polygonnumber()).push_back(ispace->interpolatedcoordinates(e));
	
	generateimagepolygon();
}

void Jpolygon::generateimagepolygon()
{
	imagepolygon = masterimagespace().imageplane() * 0.;
	imagepolygon = imagepolygon.blocks(Z,imagepolygon).blocks(Z,imagepolygon);
	
	if (filled()==false) {
		for (unsigned int j(0);j<polygon.size();j++) {
			for (unsigned int i(1);i<polygon.at(j).size();i++) {
				int x1(imagepolygon.Jlocate(polygon.at(j).at(i-1).first, X));
				int y1(imagepolygon.Jlocate(polygon.at(j).at(i-1).second, Y));
				int x2(imagepolygon.Jlocate(polygon.at(j).at(i).first, X));
				int y2(imagepolygon.Jlocate(polygon.at(j).at(i).second, Y));
				cout << "Drawing line from " << x1 << ", " << y1 << " to ";
				cout << x2 << ", " << y2 << "  RGB=" << R << " " << G << " " << B << "\n";
				imagepolygon=imagepolygon.draw_line(x1, y1, x2, y2, R, G, B);
			}
		}
	} else {
		for (unsigned int j(0);j<polygon.size();j++) 
			imagepolygon = imagepolygon.draw_filled_polygon(polygon.at(j),R,G,B);
	}
	
	Polygoncontrol.reload(imagepolygon);
}

cube Jpolygon::polygonedimage()
{
	cube answer(masterimagespace().imageplane());
	if (answer.N(Z) == 1)
		answer = answer.blocksz(answer).blocksz(answer);
	
	answer += imagepolygon;
	answer -= masterimagespace().scaling().first;
	answer /= masterimagespace().scaling().second;
	
	return answer;
}

void Jpolygon::deletelast()
{
	if (polygon.at(Polygoncontrol.polygonnumber()).size()) 
		polygon.at(Polygoncontrol.polygonnumber()).pop_back();
}

unsigned int Jpolygon::size() {return polygon.size();}

void Jpolygon::addnewpolygon()
{
	vector<pair<double, double> > newentry;
	polygon.push_back(newentry);
}

void Jpolygon::deletepolygon(unsigned int toast)
{
	vector<vector<pair<double, double> > > newpolygon;
	for (unsigned int i(0);i<polygon.size();i++)
		if (i!=toast) newpolygon.push_back(polygon.at(i));
	polygon = newpolygon;
}

cube Jpolygon::polygonvertexcube()
{
	unsigned int maxsize(0);
	for (unsigned int j(0);j<polygon.size();j++)
		if (polygon.at(j).size() > maxsize)
			maxsize = polygon.at(j).size();
	cube answer(2,polygon.size(),maxsize,-1.);
	
	for (unsigned int j(0);j<polygon.size();j++) {
		for (int i(0);i<int(polygon.at(j).size());i++) {
			answer(0,int(j),i) = polygon.at(j).at(i).first; // longitude
			answer(1,int(j),i) = polygon.at(j).at(i).second; // latitude
		}
	}
	answer.keyword("R", double2str(R));
	answer.keyword("G", double2str(G));
	answer.keyword("B", double2str(B));
	
	
	return answer;
}


void Jpolygon::polygonvertexcube(cube c)
{
	polygon.clear();
	
	for (int j(0);j<c.N(Y);j++) {
		vector<pair<double, double> > newgon;
		for (int i(0);i<int(c.N(Z));i++) {
			pair<double, double> newentry;
			newentry.first = c(0,j,i);  // longitude
			newentry.second= c(1,j,i);  // latitude
			if (newentry.first==-1. && newentry.second==-1.) continue; 
			newgon.push_back(newentry);
		}
		polygon.push_back(newgon);
	}
	R = str2double(c.keyword("R"));
	G = str2double(c.keyword("G"));
	B = str2double(c.keyword("B"));
}

imagespace& Jpolygon::masterimagespace() { return *ispace; }

