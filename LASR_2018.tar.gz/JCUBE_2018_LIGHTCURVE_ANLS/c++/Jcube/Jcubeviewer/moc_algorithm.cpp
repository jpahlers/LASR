/****************************************************************************
** Meta object code from reading C++ file 'algorithm.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "algorithm.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'algorithm.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_radiusdialog[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_radiusdialog[] = {
    "radiusdialog\0\0setradii()\0"
};

void radiusdialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        radiusdialog *_t = static_cast<radiusdialog *>(_o);
        switch (_id) {
        case 0: _t->setradii(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData radiusdialog::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject radiusdialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_radiusdialog,
      qt_meta_data_radiusdialog, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &radiusdialog::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *radiusdialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *radiusdialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_radiusdialog))
        return static_cast<void*>(const_cast< radiusdialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int radiusdialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void radiusdialog::setradii()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
static const uint qt_meta_data_algorithm[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_algorithm[] = {
    "algorithm\0"
};

void algorithm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData algorithm::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject algorithm::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_algorithm,
      qt_meta_data_algorithm, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &algorithm::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *algorithm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *algorithm::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_algorithm))
        return static_cast<void*>(const_cast< algorithm*>(this));
    return QObject::qt_metacast(_clname);
}

int algorithm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_mosaiccontrol[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x0a,
      22,   14,   14,   14, 0x0a,
      29,   14,   14,   14, 0x0a,
      36,   14,   14,   14, 0x0a,
      46,   14,   14,   14, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_mosaiccontrol[] = {
    "mosaiccontrol\0\0load()\0mesh()\0save()\0"
    "display()\0display(int)\0"
};

void mosaiccontrol::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        mosaiccontrol *_t = static_cast<mosaiccontrol *>(_o);
        switch (_id) {
        case 0: _t->load(); break;
        case 1: _t->mesh(); break;
        case 2: _t->save(); break;
        case 3: _t->display(); break;
        case 4: _t->display((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData mosaiccontrol::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject mosaiccontrol::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_mosaiccontrol,
      qt_meta_data_mosaiccontrol, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &mosaiccontrol::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *mosaiccontrol::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *mosaiccontrol::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_mosaiccontrol))
        return static_cast<void*>(const_cast< mosaiccontrol*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int mosaiccontrol::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
static const uint qt_meta_data_zero[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       6,    5,    5,    5, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_zero[] = {
    "zero\0\0getradiivalues()\0"
};

void zero::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        zero *_t = static_cast<zero *>(_o);
        switch (_id) {
        case 0: _t->getradiivalues(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData zero::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject zero::staticMetaObject = {
    { &algorithm::staticMetaObject, qt_meta_stringdata_zero,
      qt_meta_data_zero, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &zero::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *zero::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *zero::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_zero))
        return static_cast<void*>(const_cast< zero*>(this));
    return algorithm::qt_metacast(_clname);
}

int zero::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = algorithm::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_maskcontrol[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x0a,
      21,   12,   12,   12, 0x0a,
      29,   12,   12,   12, 0x0a,
      36,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_maskcontrol[] = {
    "maskcontrol\0\0color()\0graph()\0load()\0"
    "save()\0"
};

void maskcontrol::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        maskcontrol *_t = static_cast<maskcontrol *>(_o);
        switch (_id) {
        case 0: _t->color(); break;
        case 1: _t->graph(); break;
        case 2: _t->load(); break;
        case 3: _t->save(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData maskcontrol::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject maskcontrol::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_maskcontrol,
      qt_meta_data_maskcontrol, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &maskcontrol::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *maskcontrol::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *maskcontrol::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_maskcontrol))
        return static_cast<void*>(const_cast< maskcontrol*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int maskcontrol::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}
static const uint qt_meta_data_polygoncontrol[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      16,   15,   15,   15, 0x0a,
      29,   15,   15,   15, 0x0a,
      37,   15,   15,   15, 0x0a,
      50,   15,   15,   15, 0x0a,
      57,   15,   15,   15, 0x0a,
      64,   15,   15,   15, 0x0a,
      80,   15,   15,   15, 0x0a,
      96,   15,   15,   15, 0x0a,
     115,   15,  110,   15, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_polygoncontrol[] = {
    "polygoncontrol\0\0deletelast()\0color()\0"
    "togglefill()\0load()\0save()\0addnewpolygon()\0"
    "deletepolygon()\0nextpolygon()\0uint\0"
    "polygonnumber()\0"
};

void polygoncontrol::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        polygoncontrol *_t = static_cast<polygoncontrol *>(_o);
        switch (_id) {
        case 0: _t->deletelast(); break;
        case 1: _t->color(); break;
        case 2: _t->togglefill(); break;
        case 3: _t->load(); break;
        case 4: _t->save(); break;
        case 5: _t->addnewpolygon(); break;
        case 6: _t->deletepolygon(); break;
        case 7: _t->nextpolygon(); break;
        case 8: { uint _r = _t->polygonnumber();
            if (_a[0]) *reinterpret_cast< uint*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObjectExtraData polygoncontrol::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject polygoncontrol::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_polygoncontrol,
      qt_meta_data_polygoncontrol, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &polygoncontrol::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *polygoncontrol::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *polygoncontrol::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_polygoncontrol))
        return static_cast<void*>(const_cast< polygoncontrol*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int polygoncontrol::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
