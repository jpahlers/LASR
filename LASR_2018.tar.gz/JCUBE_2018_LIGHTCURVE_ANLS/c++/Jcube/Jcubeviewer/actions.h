#include <qdialog.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <q3hbox.h>
#include <q3vbox.h>
#include <qpushbutton.h>
#include <q3filedialog.h>
#include <qimage.h>
#include <q3popupmenu.h>
//Added by qt3to4:
#include <QMouseEvent>
#include <memory>
#include "imagespace.h"
#include "controlpanel.h"

#ifndef ACTIONS_H
#define ACTIONS_H 1



class colorassign : public Q3HBox
{
	Q_OBJECT
	
	public:
		colorassign(QWidget*, string);
	
	signals:
		void clicked(colorassign&);
	
	public slots:
		void emitclicked();
	
	private:
		QPushButton					color;
//		Jcrap::imagespace			image;
		
	public:
		imagespace	image;
		string buttname;
};

class colorcube : public Q3VBox
{
	Q_OBJECT
	
	public:
		colorcube(imagespace*);
	
	public slots:
		void reject();
		void assignimage(colorassign&);
		void colorsave(colorassign&);
	
	private:
		
		colorassign		r, g, b, composite;
		imagespace* ispace;
};

class classifycube;

class changeclassify : public algorithm
{
	public:
		changeclassify(imagespace *, classifycube *);
		~changeclassify() {;}
		
		void action(QMouseEvent* e);
		
		classifycube *classifywindow;
};

class classifycube : public Q3VBox
{
	Q_OBJECT
			
	public:
		classifycube(imagespace*);
	
		void classtreefill(cube&,int,int);
		void reclassify(int,int);
		
	public slots:
		void colorgraph();
		void stabilize();
		void savemap();
	
	private:
		imagespace* ispace;
		pixelnode treeroot;
		imagespace treespace;
		imagespace classmap;
		
		Q3VBox ACTIONSmenu;
		QPushButton graphbutton;
		QPushButton stabilizebutton;
		QPushButton savemapbutton;
		
		cube treecolors;
		pair<cube,cube> classes;
		
		int depth, size;
};

class colordialog : public QDialog
{
	Q_OBJECT
		
	public:
		colordialog(QWidget *parent=0,double=0., double=0., double=0.);
	
	public slots:
		void RGBset();

	public:
	QLabel *Rlabel;
	QLineEdit *Redit;
	QLabel *Glabel;
	QLineEdit *Gedit;
	QLabel *Blabel;
	QLineEdit *Bedit;
	QLabel *Flabel;
	QCheckBox *Flag;
	QPushButton *cancelbutton;
	QPushButton *donebutton;
	
	double R, G, B;
	bool flag;
	
};

class mapoffsets : public Q3VBox
{
	Q_OBJECT
	
	public:
		mapoffsets(imagespace*);
	
	public slots:
		void loadtemplate();
		void loadoffset();
		void shift();
		void blink();
	
	private:
		auto_ptr<Q3VBox> E;
		auto_ptr<Q3HBox> E1;
		auto_ptr<QLabel> E1label;
		auto_ptr<QLineEdit> E1edit;
		auto_ptr<Q3HBox> E2;
		auto_ptr<QLabel> E2label;
		auto_ptr<QLineEdit> E2edit;
		auto_ptr<Q3HBox> E3;
		auto_ptr<QLabel> E3label;
		auto_ptr<QLineEdit> E3edit;
	
		auto_ptr<QPushButton> loadgeotemplatebutt;
		auto_ptr<QPushButton> loadtobeoffsetbutt;
		auto_ptr<QPushButton> shiftbutt;
		auto_ptr<QPushButton> blinkbutt;
		
		auto_ptr<Q3HBox>        whichbox;
		auto_ptr<Q3ButtonGroup> whichscale;
		auto_ptr<QRadioButton> whichgeo;
		auto_ptr<QRadioButton> whichtobe;
		
		auto_ptr<imagespace> iarea;
		
		cube geotemplate, geotemplateorig;
		cube tobeoffset, tobeoffsetorig;
		cube offset;
		double geoscale;
};

class subhelper : public Q3VBox
{
	Q_OBJECT
	
	public:
		subhelper(imagespace*);
	
	public slots:
		void recalculate(int);
	
	private:
		auto_ptr<imagespace> imgorig;
		auto_ptr<imagespace> img2bsub;
		auto_ptr<slidedial> multslider;
		auto_ptr<imagespace> imgdiff;

};

#endif
