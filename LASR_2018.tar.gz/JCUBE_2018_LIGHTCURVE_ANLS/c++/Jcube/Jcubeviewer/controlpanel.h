#include <qslider.h>
#include <qlabel.h>
#include <qlcdnumber.h>
#include <qspinbox.h>
#include <q3hbox.h>
#ifndef CONTROLPANEL_H
#define CONTROLPANEL_H 1

#include <q3vbox.h>
#include <q3grid.h>
#include <qlineedit.h>
#include <q3buttongroup.h>
#include <qradiobutton.h>

#include "../Jcrap.h"

#include "../slidedial.h"

class scaler : public Q3Grid
{
	Q_OBJECT
			
	public:
		scaler(QWidget *parent=0, const char *name=0);

	signals:
		void valueChanged(float, float);
			
	public slots:
		void writescalinginfo(float, float);
		void change();

			
	private:
		QLabel		scaling;
		QLabel		low;
		QLabel		hi;
		QLabel		dummy;
		QLineEdit	lowtext;
		QLineEdit	hightext;
	
};

class pixdataview : public Q3Grid
{
	Q_OBJECT
			
	public:
		pixdataview(QWidget *parent=0, const char *name=0);

			
	public slots:
		void writepixelinfo(float, float, float);

			
	private:
		QLabel		xlabel;
		QLabel		ylabel;
		QLabel		valuelabel;
		QLCDNumber	xnum;
		QLCDNumber	ynum;
		QLCDNumber	valnum;
	
};

class planedecider : public Q3ButtonGroup
{
	Q_OBJECT
			
	public:
		planedecider(QWidget *parent=0, const char *name=0);
	
	public slots:
		void planechange();
		
	signals:
		void planeaxisChanged(int);
	
	private:
		QRadioButton	Xbutton;
		QRadioButton	Ybutton;
		QRadioButton	Zbutton;
};

class Jcrap::controlpanel : public Q3VBox
{
	Q_OBJECT

	public:
		controlpanel(QWidget *parent=0, const char *name=0);
		void Zrerange(int, int);
		scaler& scaling();
		pixdataview& pixel();
		void setWavecal(double*);
		planedecider& planing();
		QSize sizeHint();
		int coadds();
		int zstart();


	public slots:
		void wavewrite(int);
		void changecoaddlimits(int);

	signals:
		void ZvalueChanged(int);
		void coaddsChanged(int);
		void scaleChanged(float, float);


	private:	
		pixdataview			pixelinfo;
		scaler				scale;
		Jcrap::slidedial  Zstart_sd;
		Jcrap::slidedial  coadds_sd;
		QLCDNumber			wavdisplay;
		planedecider		Planer;
		double*				wavecal;
	
};

#endif
