/****************************************************************************
** Meta object code from reading C++ file 'controlpanel.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "controlpanel.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'controlpanel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_scaler[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      10,    8,    7,    7, 0x05,

 // slots: signature, parameters, type, tag, flags
      36,    8,    7,    7, 0x0a,
      66,    7,    7,    7, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_scaler[] = {
    "scaler\0\0,\0valueChanged(float,float)\0"
    "writescalinginfo(float,float)\0change()\0"
};

void scaler::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        scaler *_t = static_cast<scaler *>(_o);
        switch (_id) {
        case 0: _t->valueChanged((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 1: _t->writescalinginfo((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 2: _t->change(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData scaler::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject scaler::staticMetaObject = {
    { &Q3Grid::staticMetaObject, qt_meta_stringdata_scaler,
      qt_meta_data_scaler, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &scaler::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *scaler::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *scaler::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_scaler))
        return static_cast<void*>(const_cast< scaler*>(this));
    return Q3Grid::qt_metacast(_clname);
}

int scaler::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3Grid::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void scaler::valueChanged(float _t1, float _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_pixdataview[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      16,   13,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_pixdataview[] = {
    "pixdataview\0\0,,\0writepixelinfo(float,float,float)\0"
};

void pixdataview::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        pixdataview *_t = static_cast<pixdataview *>(_o);
        switch (_id) {
        case 0: _t->writepixelinfo((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData pixdataview::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject pixdataview::staticMetaObject = {
    { &Q3Grid::staticMetaObject, qt_meta_stringdata_pixdataview,
      qt_meta_data_pixdataview, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &pixdataview::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *pixdataview::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *pixdataview::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_pixdataview))
        return static_cast<void*>(const_cast< pixdataview*>(this));
    return Q3Grid::qt_metacast(_clname);
}

int pixdataview::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3Grid::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
static const uint qt_meta_data_planedecider[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      14,   13,   13,   13, 0x05,

 // slots: signature, parameters, type, tag, flags
      36,   13,   13,   13, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_planedecider[] = {
    "planedecider\0\0planeaxisChanged(int)\0"
    "planechange()\0"
};

void planedecider::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        planedecider *_t = static_cast<planedecider *>(_o);
        switch (_id) {
        case 0: _t->planeaxisChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->planechange(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData planedecider::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject planedecider::staticMetaObject = {
    { &Q3ButtonGroup::staticMetaObject, qt_meta_stringdata_planedecider,
      qt_meta_data_planedecider, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &planedecider::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *planedecider::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *planedecider::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_planedecider))
        return static_cast<void*>(const_cast< planedecider*>(this));
    return Q3ButtonGroup::qt_metacast(_clname);
}

int planedecider::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3ButtonGroup::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void planedecider::planeaxisChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_Jcrap__controlpanel[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: signature, parameters, type, tag, flags
      21,   20,   20,   20, 0x05,
      40,   20,   20,   20, 0x05,
      61,   59,   20,   20, 0x05,

 // slots: signature, parameters, type, tag, flags
      87,   20,   20,   20, 0x0a,
     102,   20,   20,   20, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Jcrap__controlpanel[] = {
    "Jcrap::controlpanel\0\0ZvalueChanged(int)\0"
    "coaddsChanged(int)\0,\0scaleChanged(float,float)\0"
    "wavewrite(int)\0changecoaddlimits(int)\0"
};

void Jcrap::controlpanel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        controlpanel *_t = static_cast<controlpanel *>(_o);
        switch (_id) {
        case 0: _t->ZvalueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->coaddsChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->scaleChanged((*reinterpret_cast< float(*)>(_a[1])),(*reinterpret_cast< float(*)>(_a[2]))); break;
        case 3: _t->wavewrite((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->changecoaddlimits((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData Jcrap::controlpanel::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject Jcrap::controlpanel::staticMetaObject = {
    { &Q3VBox::staticMetaObject, qt_meta_stringdata_Jcrap__controlpanel,
      qt_meta_data_Jcrap__controlpanel, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Jcrap::controlpanel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Jcrap::controlpanel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Jcrap::controlpanel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Jcrap__controlpanel))
        return static_cast<void*>(const_cast< controlpanel*>(this));
    return Q3VBox::qt_metacast(_clname);
}

int Jcrap::controlpanel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3VBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void Jcrap::controlpanel::ZvalueChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Jcrap::controlpanel::coaddsChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Jcrap::controlpanel::scaleChanged(float _t1, float _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_END_MOC_NAMESPACE
