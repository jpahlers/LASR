#include "actions.h"
//Added by qt3to4:
#include <Q3HBoxLayout>
#include <QLabel>
#include <Q3VBoxLayout>

colorassign::colorassign(QWidget *parent, string cname) :
		Q3HBox(parent, cname.c_str()),
		color(cname.c_str(), this),
		image(this),
		buttname(cname)		
{
	connect(&color, SIGNAL(clicked()), this, SLOT(emitclicked()));
}

void colorassign::emitclicked()
{
	emit clicked(*this);
}

colorcube::colorcube(imagespace *i) :
		Q3VBox(0, "Color Cube Creation Dialog"),
		r(this, "Red"),
		g(this, "Green"),
		b(this, "Blue"),
		composite(this, "Save"),
		ispace(i)
{
	connect(&r, SIGNAL(clicked(colorassign&)), this, SLOT(assignimage(colorassign&)));
	connect(&g, SIGNAL(clicked(colorassign&)), this, SLOT(assignimage(colorassign&)));
	connect(&b, SIGNAL(clicked(colorassign&)), this, SLOT(assignimage(colorassign&)));
	composite.image.imagecube() = cube(10,10,3,0.);
	composite.image.BW() = 0;

	connect(&composite, SIGNAL(clicked(colorassign&)), this, SLOT(colorsave(colorassign&)));
		
	cout << "About to show colorimagegenerator window\n"; cout.flush();
	
	show();
	
	
}

void colorcube::assignimage(colorassign& c)
{
	c.image.imagecube() = ispace->imageplane();
	c.image.imageplane() = c.image.imagecube();
	c.image.setscaling(ispace->scalemin(), ispace->scalemax());
	
	if ((composite.image.imagecube().N(X) != c.image.imageplane().N(X))
			|| (composite.image.imagecube().N(Y) != c.image.imageplane().N(Y))) {
		cout << "sizes don't match: " << composite.image.imagecube().N(X) << " != ";
		cout << c.image.imageplane().N(X) << "\n";
		cout << "sizes don't match: " << composite.image.imagecube().N(Y) << " != ";
		cout << c.image.imageplane().N(Y) << "\n";		
		composite.image.imagecube() = cube(c.image.imageplane().N(X),
				c.image.imageplane().N(Y), 3);

	}	
		
	int z(0);
	if (c.buttname == string("Red")) z=0;
	if (c.buttname == string("Green")) z=1;
	if (c.buttname == string("Blue")) z=2;
	
	for (int x=0;x<composite.image.imagecube().N(X);x++)
		for (int y=0;y<composite.image.imagecube().N(Y);y++)
			composite.image.imagecube()(x,y,z) = 
					(c.image.imageplane()(x,y,0)-c.image.scalemin()) / 
					(c.image.scalemax()-c.image.scalemin());
//	composite.image.imgcube.totif().write("color.tif");
	composite.image.BW()=0;
	composite.image.setscaling(0., 1.);
				
		
}

void colorcube::colorsave(colorassign& c)
{
	c.image.imagecube().totif().write("color.tif", 0., 1.);
}

void colorcube::reject()
{
	delete this;
}

void classifycube::classtreefill(cube& c, int d, int e)
{
	cout << "Classtreefilling " << d << ", " << e << "\n";
	int ysize(c.N(Y)/(depth+1));
	int xsize(c.N(X)/int(pow(2,d)));
	for (int x=e*xsize;x<(e+1)*xsize-1;x++) {
		for (int y=d*ysize;y<(d+1)*ysize-1;y++) {
			c(x,y,0) = treecolors(e,d,0);
			c(x,y,1) = treecolors(e,d,1);
			c(x,y,2) = treecolors(e,d,2);
		}
	}
}

classifycube::classifycube(imagespace *i) :
		Q3VBox(0, "Cube Classification Box"),
		ispace(i),
		treeroot(i->imagecube().classify(mFAST)),
		treespace(this),
		classmap(this),
		ACTIONSmenu(0, "Classify Actions"),
		graphbutton("Multicolor Graph",&ACTIONSmenu),
		stabilizebutton("Stabilize",&ACTIONSmenu),
		savemapbutton("Save Unit Map",&ACTIONSmenu)
{       

   connect( &graphbutton, SIGNAL(pressed()), this, SLOT( colorgraph() ));
   connect( &stabilizebutton, SIGNAL(pressed()), this, SLOT( stabilize() ));
   connect( &savemapbutton, SIGNAL(pressed()), this, SLOT( savemap() ));
	
	ACTIONSmenu.show();

	depth = 10;
	size  = 5;

	cube treeview(int(pow(2,depth))*size, (depth+1)*size,3, 0.);
	
	treecolors = cube(int(pow(2,depth)), (depth+1), 3);
	for (int d=0;d<=depth;d++) {
		for (int e=0;e<pow(2,d);e++) {
			if (d<5)
				treecolors(e,d,0)=treecolors(e,d,1)=treecolors(e,d,2)=1.;
			if (d>5)
				treecolors(e,d,0)=treecolors(e,d,1)=treecolors(e,d,2)=.25;
			if (d==5) {	
				cube pal(8,1,3); // palette
				pal(0,0,0)=1.;  // pal 1 = red 
				pal(1,0,2)=1.;  // pal 2 = blue
				pal(2,0,1)=1.;  // pal 3 = green
				pal(3,0,0)=0.5; // pal 4 = grey
				pal(3,0,1)=0.5;  
				pal(3,0,2)=0.5; 
				pal(4,0,0)=1.0; // pal 5 = orange?
				pal(4,0,1)=0.5; 
				pal(5,0,1)=1.0; // pal 6 = bluegreen?
				pal(5,0,2)=1.0;
				pal(6,0,0)=1.0; // pal 7 = yellow?
				pal(6,0,1)=1.0; 
				pal(7,0,0)=1.0; // pal 7 = purple
				pal(7,0,2)=1.0; // pal 7 = purple
			
				vector<cube> morepal(4);
				morepal[0] = pal;
				morepal[1] = pal * 0.66;
				morepal[2] = pal * 0.33;
				morepal[3] = pal + 0.4;
	
				for (int i=0;i<32;i++) {
					treecolors(i,d,0) = morepal[i%4]((int)(i/4),0,0);
					treecolors(i,d,1) = morepal[i%4]((int)(i/4),0,1);
					treecolors(i,d,2) = morepal[i%4]((int)(i/4),0,2);
				}
			}
			
			classtreefill(treeview,d,e);
		}
	}
	
	treespace.load(treeview);
	treespace.setscaling(0.,1.);
	
	classes = ispace->imagecube().pixelclassify(treeroot,treecolors);
	classmap.load(classes.first);
	classmap.setscaling(0.,1.);
	cout << classes.first.info();
		
	treespace.Algorithm = new changeclassify(&treespace, this);
	cout << "About to show\n";
	show();
}




void classifycube::reclassify(int ix, int iy)
{
	int d = int(iy/size);
	int e = int(ix/size/powf(2.,(depth-d)));
	cout << "Click located at depth " << d << " node " << e << "\n";
	
	if (treecolors(e,d,0) == 1. &&
		 treecolors(e,d,1) == 1. &&
		 treecolors(e,d,2) == 1.) {
		// consolidate lower classes
		cube color(1,1,1);
		for (int ld=d+1;ld<=depth;ld++) {
			for (int le=e*int(powf(2.,ld-d));le<(e+1)*powf(2.,ld-d);le++) {
				if (treecolors(le,ld,0) == 0.25 &&
					 treecolors(le,ld,1) == 0.25 &&
				    treecolors(le,ld,2) == 0.25); // if gray, leave alone
				else if (treecolors(le,ld,0) == 1. &&
					 treecolors(le,ld,1) == 1. &&
					 treecolors(le,ld,2) == 1.) { //if it's white, make it gray
					treecolors(le,ld,0) = 0.25;
					treecolors(le,ld,1) = 0.25;
					treecolors(le,ld,2) = 0.25;
				} else {  //if colored, set the color and then set gray
					if (color.N(Z)==1) {
						color = treecolors.skewer(Z,le,ld);
						treecolors(e,d,0) = color(0,0,0);
						treecolors(e,d,1) = color(0,0,1);
						treecolors(e,d,2) = color(0,0,2);
						classtreefill(treespace.imagecube(),d,e);
					}
					treecolors(le,ld,0) = 0.25;
					treecolors(le,ld,1) = 0.25;
					treecolors(le,ld,2) = 0.25;
				}
				
				classtreefill(treespace.imagecube(),ld,le);
			}
		}
	} else if (treecolors(e,d,0) == 0.25 &&
		        treecolors(e,d,1) == 0.25 &&
		        treecolors(e,d,2) == 0.25) {
		// fission an upper class into more parts
		int pd(d), pe(e);
		while (treecolors(pe,pd,0) == 0.25 &&
				 treecolors(pe,pd,1) == 0.25 &&
				 treecolors(pe,pd,2) == 0.25) {
			pd--;
			pe/=2;
		}
		cube parentcolor(treecolors.skewer(Z,pe,pd));
		
		for (int ud=pd;ud<=d;ud++) { // set all upper nodes white
			for (int ue=pe*int(powf(2.,ud-pd));ue<(pe+1)*powf(2.,ud-pd);ue++) {
				if (ud!=d) {
					treecolors(ue,ud,0) = 1.;
					treecolors(ue,ud,1) = 1.;
					treecolors(ue,ud,2) = 1.;
					classtreefill(treespace.imagecube(),ud,ue);
				} else {
					double mult=1.-((ue-pe*powf(2.,ud-pd))/(pe+2)*powf(2.,ud-pd));
					treecolors(ue,ud,0) = parentcolor(0,0,0)*mult;
					treecolors(ue,ud,1) = parentcolor(0,0,1)*mult;
					treecolors(ue,ud,2) = parentcolor(0,0,2)*mult;
					classtreefill(treespace.imagecube(),ud,ue);
				}
			}
		}
	} else {
		colordialog cd(this, treecolors(e,d,0), treecolors(e,d,1),
				treecolors(e,d,2));
		treecolors(e,d,0) = cd.R;
		treecolors(e,d,1) = cd.G;
		treecolors(e,d,2) = cd.B;
		
		classtreefill(treespace.imagecube(),d,e);
	}
	
	treespace.setscaling(0., 1.);	
	
	classes = ispace->imagecube().pixelclassify(treeroot,treecolors);
	classmap.load(classes.first);
	classmap.setscaling(0.,1.);
}

colordialog::colordialog(QWidget *parent, double r, double g, double b) : 
		QDialog(parent, "Color Dialog"),
		R(r),
		G(g),
		B(b)
{
	setCaption("Set Color");
	
	Rlabel = new QLabel("R",this);
	Redit  = new QLineEdit(this);
	Redit->setText(QString::fromStdString(float2str(R)));
	Glabel = new QLabel("G",this);
	Gedit  = new QLineEdit(this);
	Gedit->setText(QString::fromStdString(float2str(G)));
	Blabel = new QLabel("B",this);
	Bedit  = new QLineEdit(this);
	Bedit->setText(QString::fromStdString(float2str(B)));
	
	Flabel = new QLabel("Use?",this);
	Flag = new QCheckBox(this);
	Flag->setDown(flag);
	
	cancelbutton = new QPushButton("Cancel", this);
	donebutton   = new QPushButton("Assign", this);
	donebutton->setDefault(true);
	
//	connect(donebutton, SIGNAL(clicked()),  this, SLOT(close));
	connect(donebutton, SIGNAL(clicked()), this, SLOT(RGBset()));
	
	Q3HBoxLayout *blanks = new Q3HBoxLayout;
	blanks->addWidget(Rlabel);
	blanks->addWidget(Redit);
	blanks->addWidget(Glabel);
	blanks->addWidget(Gedit);
	blanks->addWidget(Blabel);
	blanks->addWidget(Bedit);
	blanks->addWidget(Flabel);
	blanks->addWidget(Flag);
	
	Q3HBoxLayout *buttons = new Q3HBoxLayout;
	buttons->addWidget(cancelbutton);
	buttons->addStretch(1);
	buttons->addWidget(donebutton);

	Q3VBoxLayout *all = new Q3VBoxLayout(this);
	all->addLayout(blanks);
	all->addLayout(buttons);
	
	exec();
		
}

void colordialog::RGBset()
{
	R = str2float(Redit->text().toStdString());
	G = str2float(Gedit->text().toStdString());
	B = str2float(Bedit->text().toStdString());
	flag = Flag->isChecked();
	close();
}


void classifycube::colorgraph()
{
	cout << "Colorgraph()\n";
	cube centroids, colors=cube(0,1,3).totif();
	for (int d=0;d<=depth;d++) {
		for (int e=0;e<int(powf(2.,d));e++) {
			// if this one's white or gray, ignore it.
			if (treecolors(e,d,0)==1.&&treecolors(e,d,1)==1.&&treecolors(e,d,2)==1.);
			else if (treecolors(e,d,0)==0.25&&treecolors(e,d,1)==0.25&&
				treecolors(e,d,2)==0.25);
			
			// if it's colored, save its centroid and color
			else {
				// search the tree and find depth d, leaf e
				Jcrap::pixelnode *p=&treeroot;
				for (int j=int(powf(2,d-1));j!=0;j/=2){
					cout << "Checking " << e << "&" << j;
					if (p->children()==1) {cout << " 0 "; p=p;}
					else if (e&j) { cout << " r "; p=&(p->right()); }
					else {cout << " l "; p=&(p->left()); }
				}
				cout << "\n";
				
				if (centroids.N(Z) == 1)
					centroids = p->centroid();
				else
					centroids = centroids.blocksx(p->centroid());
				
				colors = colors.blocksx(treecolors.skewer(Z,e,d));
			}
		}
	}
	
	int gnum=0;
	for (int i=0;i<centroids.N(X);i++){
		string outname("centroid.");
		outname += int2str(i);
		outname += ".Jcube";
		
		cube thiscentroid(centroids.skewer(Z,i,0));
		unsigned int thiscolor;
		for (int j=0;j<3;j++) {
			if (colors(i,0,j) > 1.) colors(i,0,j)=1.;
			if (colors(i,0,j) < 0.) colors(i,0,j)=0.;
		}
		thiscolor = int(colors(i,0,0)/1.*255.)*256*256 +
						int(colors(i,0,1)/1.*255.)*256     +
						int(colors(i,0,2)/1.*255.);
		char colorcstring[10];
		ostrstream colorstrstream(colorcstring, 10);
		cout << "i = " << i << ", thiscolor = ";
		colorstrstream << '#' << setfill('0') << setw(6) << std::hex << thiscolor << "\n";
		colorcstring[7] = '\0';
		cout << string(colorcstring) << "\n";
		
		thiscentroid.keyword("graph_linecolor", colorcstring);
		
		thiscentroid.graph(); gnum++;
		thiscentroid.keyword("titangraph", "yes");
		
		if (i==centroids.N(X)-1) 
			thiscentroid.graph(int2str(gnum%5).c_str());
		if (gnum%5 == 0 && i!=centroids.N(X)-1)
			thiscentroid.graph("5");
	}
	cout << std::dec << setfill(' ');
}
		
void classifycube::stabilize(){
}
		
void classifycube::savemap()
{
	string startdir(ispace->imagefilename() +
			string(".classes.tif"));
	QString filename=Q3FileDialog::getSaveFileName(startdir.c_str(), "*classes.tif", this);
	classmap.imagecube().totif().write(filename.ascii());
	
	startdir = ispace->imagefilename() +
			string(".classtree.tif");
	filename=Q3FileDialog::getSaveFileName(startdir.c_str(), "*classtree.tif", this);
	treespace.imagecube().totif().write(filename.ascii());

}

mapoffsets::mapoffsets(imagespace *i) :
		geotemplate(),
		tobeoffset()
{
	E = auto_ptr<Q3VBox>(new Q3VBox(this));
	E1 = auto_ptr<Q3HBox>(new Q3HBox(&*E));
	E1label = auto_ptr<QLabel>(new QLabel("E1  ",&(*E1)));
	E1edit  = auto_ptr<QLineEdit>(new QLineEdit(&(*E1)));
	E1edit->setText(QString::fromStdString(float2str(0.)));
	
	E2 = auto_ptr<Q3HBox>(new Q3HBox(&*E));
	E2label = auto_ptr<QLabel>(new QLabel("E2  ",&*E2));
	E2edit  = auto_ptr<QLineEdit>(new QLineEdit(&*E2));
	E2edit->setText(QString::fromStdString(float2str(0.)));
	
	E3 = auto_ptr<Q3HBox>(new Q3HBox(&*E));	
	E3label = auto_ptr<QLabel>(new QLabel("E3  ",&*E3));
	E3edit  = auto_ptr<QLineEdit>(new QLineEdit(&*E3));
	E3edit->setText(QString::fromStdString(float2str(0.)));
	
	whichbox   = auto_ptr<Q3HBox>(new Q3HBox(&*E));
	whichscale = auto_ptr<Q3ButtonGroup>(new Q3ButtonGroup(&*whichbox));
	whichgeo   = auto_ptr<QRadioButton>(new QRadioButton("geo", &*whichbox));
	whichtobe  = auto_ptr<QRadioButton>(new QRadioButton("tobe", &*whichbox));
	whichscale->insert(&*whichgeo);
	whichscale->insert(&*whichtobe);
	whichtobe->toggle();
	
	loadgeotemplatebutt = auto_ptr<QPushButton>(new QPushButton("Load Geotemplate",&*E));
	loadtobeoffsetbutt = auto_ptr<QPushButton>(new QPushButton("Load Tobeoffset",&*E));
	shiftbutt = auto_ptr<QPushButton>(new QPushButton("Shift",&*E));
	blinkbutt = auto_ptr<QPushButton>(new QPushButton("Blink",&*E));
		
	
	iarea = auto_ptr<imagespace>(new imagespace(this));
	

   connect( &*loadgeotemplatebutt, SIGNAL(pressed()), this, SLOT( loadtemplate() ));
   connect( &*loadtobeoffsetbutt, SIGNAL(pressed()), this, SLOT( loadoffset() ));
   connect( &*shiftbutt, SIGNAL(pressed()), this, SLOT( shift() ));
   connect( &*blinkbutt, SIGNAL(pressed()), this, SLOT( blink() ));
	
	show();
}

void mapoffsets::loadtemplate()
{
	QString filename=Q3FileDialog::getOpenFileName("./", "*cyl*Jcube", this);

	cout << "whichgeo->isChecked() = " << whichgeo->isChecked() << "\n";
	cout << "whichtobe->isChecked()= " << whichtobe->isChecked() << "\n";
	
	cube incube(filename.toStdString());
	
	if (incube.N(Z) > 3)
		incube = incube.plane(Z, 2.01f); 
	geoscale = incube.median(0.995);
	cout << "Scaling 0 to " << geoscale << "\n";
	geotemplateorig = incube/geoscale;  
//	geotemplate.astype(tif).write("geotemplate.tif", 0., 1.);

	
	if (tobeoffsetorig.N(X) > 1) {
		cout << "Resampling . . .\n";
		if (whichtobe->isChecked()) {
			cout << "Downsampling geotemplate! >> \n";
			geotemplate = geotemplateorig.resample(tobeoffsetorig);
			tobeoffset = tobeoffsetorig;
		}
		if (whichgeo->isChecked()){
			cout << "Downsampling tobeoffset >> \n";
			geotemplate = geotemplateorig;
			tobeoffset = tobeoffsetorig.resample(geotemplateorig);
		}
	}
	
	iarea->load(geotemplate);
	iarea->setscaling(0, 1);
	
	if (geotemplate.N(X) > 1  &&  tobeoffset.N(X) > 1)
		shift();
	
}

void mapoffsets::loadoffset()
{	
	QString filename=Q3FileDialog::getOpenFileName("./", "*cyl*Jcube", this);

	cout << "whichgeo->isChecked() = " << whichgeo->isChecked() << "\n";
	cout << "whichtobe->isChecked()= " << whichtobe->isChecked() << "\n";
	
	cube incube(filename.toStdString());
	
	if (incube.N(Z) > 3)
		incube = incube.plane(Z, 2.01f);
	tobeoffsetorig = incube/0.18;

	if (geotemplateorig.N(X) > 1) {
		if (whichtobe->isChecked()){
			cout << "Downsampling geotemplate! >> \n";
			geotemplate = geotemplateorig.resample(tobeoffsetorig);
			tobeoffset = tobeoffsetorig;
		}
		if (whichgeo->isChecked()){
			cout << "Downsampling tobeoffset >> \n";
			geotemplate = geotemplateorig;
			tobeoffset = tobeoffsetorig.resample(geotemplateorig);
		}
	}
			
	iarea->load(tobeoffset);
	iarea->setscaling(0, 1);
		
	if (geotemplate.N(X) > 1  &&  tobeoffset.N(X) > 1)
		shift();
	
}

float ew0conv(float inlon)
{
	float answer(inlon);
	while (answer > 180.) answer -= 360.;
	while (answer <-180.) answer += 360.;
	return answer;
}

float west180conv(float inlon)
{
	float answer(inlon);
	while (answer > 0.) answer -= 360.;
	while (answer <-360.) answer += 360.;
	return answer;
}

float notouchie(float inlon)
{
	return inlon;
}

void mapoffsets::shift()
{
	cout << "IN shift() ------------\n";
//	offset = tobeoffset.resample(geotemplate, mNN);
	const double dpr(180./3.1415926535897932384);
	float (*lonconvention)(float)=&notouchie;
	geotemplate.write("geotest.Jcube");
	if (whichgeo->isChecked()) {
		if (geotemplate.Axis(X,0) < -181.1) {
			cout << "Switching to west180 lonconvention (found " << geotemplate.Axis(X,0) << ")\n";
			lonconvention=&west180conv;
		} else lonconvention=&ew0conv;
		offset = tobeoffset.cylindereuler(geotemplate, str2float(E1edit->text().toStdString())/dpr,
				str2float(E2edit->text().toStdString())/dpr, str2float(E3edit->text().toStdString())/dpr,
				mNN,lonconvention);
	}
	if (whichtobe->isChecked()) {
		if (tobeoffset.Axis(X,0) < -181.1) {
			cout << "Switching to west180 lonconvention (found " << tobeoffset.Axis(X,0) << ")\n";
			lonconvention=&west180conv;
		} else lonconvention=&ew0conv;
		offset = tobeoffset.cylindereuler(tobeoffset, str2float(E1edit->text().toStdString())/dpr,
				str2float(E2edit->text().toStdString())/dpr, str2float(E3edit->text().toStdString())/dpr, 
				mNN,lonconvention);
	}
	
	cout << offset.info();
//	offset.astype(tif).write("offset.tif", 0., 1.);
//	geotemplate.astype(tif).write("geotemplate.tif");
	iarea->load(geotemplate);
	iarea->setscaling(0, 1);
	iarea->setpreviousimg();
	iarea->load(offset);
	iarea->setscaling(0, 1);
	blink();
	blink();
}

void mapoffsets::blink()
{
/*	static bool which(0);
	if (which) iarea->load(geotemplate);
	if (!which) iarea->load(offset);
	iarea->setscaling(0, 1);
	which = !which;*/
	iarea->blink();
	cout << "whichgeo->isChecked() = " << whichgeo->isChecked() << "\n";
	cout << "whichtobe->isChecked()= " << whichtobe->isChecked() << "\n";
	
}

subhelper::subhelper(imagespace *i) 
{	
	imgorig   = auto_ptr<imagespace>(new imagespace(this));
	
	imgorig->load(i->imageplane());
	imgorig->setscaling(i->scalemin(), i->scalemax());
	
	QString filename=Q3FileDialog::getOpenFileName("./", "*Jcube", this);
	img2bsub  = auto_ptr<imagespace>(new imagespace(this, "2bsubbed", filename));
	img2bsub->setscaling(img2bsub->imagecube().median(0.01),img2bsub->imagecube().median(0.99));
	
	
	multslider= auto_ptr<slidedial> (new slidedial ("Subfactor", this, "Sub factor"));
	multslider->rerange(0, 12000);
	imgdiff   = auto_ptr<imagespace>(new imagespace(this));
	
	connect(&*multslider, SIGNAL(valueChanged(int)),
		this, SLOT(recalculate(int)));
	
	show();
	

}

void subhelper::recalculate(int v)
{
	float mult(1./10000.*float(v));
	
	imgdiff->load(imgorig->imageplane()-img2bsub->imageplane()*mult);
	imgdiff->setscaling(imgorig->imageplane().min(),imgorig->imageplane().max()); 
	
}
