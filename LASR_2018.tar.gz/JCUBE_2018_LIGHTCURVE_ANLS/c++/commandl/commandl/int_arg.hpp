/*
This is a descendent of argument that deals with int values.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: int_arg.hpp,v 1.2 2003/03/03 00:52:30 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef INT_ARG_HEADER	// Begin the Header Guard to prevent multiple
#define INT_ARG_HEADER	//	inclusions.

#include "argument.hpp"

namespace commandl
{

/*!
	\brief An argument class that acts like an int.
*/
class int_arg : public argument
{

// ==================== Constructors & Destructor ===================== //
public:

	int_arg
		(
		std::vector<std::string>,	// keys
		std::string = "",			// value description
		std::string = "",			// description
		bool = false,				// argument required
		bool = false				// value required?
		);

	int_arg
		(
		std::string,				// key
		std::string = "",			// value description
		std::string = "",			// description
		bool = false,				// argument required
		bool = false				// value required?
		);


// =========================== Accessors ============================== //
public:

	operator int() const;


// =========================== Methods ================================ //
public:

	//				 value(s)	prefix,      key,         assignment
	void operator()	(
					const std::string&,					// prefix
					const std::string&,					// key
					const unsigned long					// order
					);
	void operator()	(
					const std::string&,					// value
					const std::string&,					// prefix
					const std::string&,					// key
					const std::string&,					// assign
					const unsigned long					// order
					);
	void operator()	(
					const std::vector<std::string>&,	// values
					const std::string&,					// prefix
					const std::string&,					// key
					const std::string&,					// assign
					const unsigned long					// order
					);
	int_arg& operator=( const int& );


// --------------------------- Protected Methods ---------------------- //
protected:


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:

//! The underlying int that this class is wrapping.
	int	arguments_int;


}; // End of the class declaration

} // End of the namespace declaration

#endif	// End the Header Guard

