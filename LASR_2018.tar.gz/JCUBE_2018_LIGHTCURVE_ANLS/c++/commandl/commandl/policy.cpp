/*
This is an abstract base class for keeping track of parsing policies.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: policy.cpp,v 1.3 2003/03/25 23:53:36 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <bitset>
#include <string>
#include <utility>
#include <vector>
#include "policy.hpp"

/*
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "matcher ($Revision: 1.3 $ $Date: 2003/03/25 23:53:36 $)";
*/

// ==================== Constructors & Destructor ==================== //

commandl::policy::policy
	(
	std::vector<std::string>			prefixes,
	std::vector<std::string>			assignments,
	std::bitset<8>						policy_bitset,
	std::pair<std::string, std::string>	optional_brackets,
	std::pair<std::string, std::string> value_brackets
	)
	:	Prefixes( 			prefixes			),
		Assignments(		assignments			),
		Optional_Brackets(	optional_brackets	),
		Value_Brackets(		value_brackets		)
	{
	// This is kinda flakey, I need to come up with a better scheme.
	is_empty_valid_prefix(				policy_bitset.test(0)	);
	is_empty_valid_assignment(			policy_bitset.test(1)	);
	is_token_separator_assignment(		policy_bitset.test(2)	);
	no_prefix_keep_going(				policy_bitset.test(3)	);
	no_prefix_keep_element(				policy_bitset.test(4)	);
	no_key_keep_going(					policy_bitset.test(5)	);
	no_key_keep_element(				policy_bitset.test(6)	);
	ignore_prefix_if_value_required(	policy_bitset.test(7)	);
	}

commandl::policy::policy()
	{
	add_prefix( "-" );
	set_optional_brackets( std::make_pair(std::string("["), std::string("]")) );
	set_value_brackets(    std::make_pair(std::string("<"), std::string(">")) );
	is_empty_valid_prefix(				false	);
	is_empty_valid_assignment(			true	);
	is_token_separator_assignment(		true	);
	no_prefix_keep_going(				false	);
	no_prefix_keep_element(				false	);
	no_key_keep_going(					false	);
	no_key_keep_element(				false	);
	ignore_prefix_if_value_required(	false	);
	}

// =========================== Accessors ============================== //

/*!
	\brief Returns the vector of prefixes allowed for this policy.

	The returned vector contains all of the strings which are valid
	prefixes for this policy.

	\return A vector of strings.
*/
std::vector<std::string> 
commandl::policy::prefixes() const
	{
	return Prefixes;
	}

/*!
	\brief Returns the vector of assignments allowed for this policy.

	The returned vector contains all of the strings which are valid
	assignments for this policy.

	\return A vector of strings.
*/
std::vector<std::string>
commandl::policy::assignments() const
	{
	return Assignments;
	}

/*!
	\brief Returns the pair of strings that are intended to enclose optional
		elements in a usage statement.

	\return A pair of strings.
*/
std::pair<std::string, std::string>
commandl::policy::optional_brackets() const
	{
	return Optional_Brackets;
	}

/*!
	\brief Returns the pair of strings that are intended to enclose value
		elements in a usage statement.

	\return A pair or strings.
*/
std::pair<std::string, std::string>
commandl::policy::value_brackets() const
	{
	return Value_Brackets;
	}

/*!
	\brief Is the empty string a valid prefix?

	Usually this is no, but sometimes you'd like to eliminate the
	need for a special prefix character when parsing elements based
	purely on position.

	\return A boolean.
*/
bool
commandl::policy::is_empty_valid_prefix() const
	{
	return Empty_Is_Prefix;
	}

/*!
	\brief Is the empty string a valid assignment?

	This is most commonly true when you want the key and the value
	in the same element without having to specify an explicit
	assignment character.  For example, if the element is "-afoo", 
	and the key is "a", and you would like "foo" to be recognized
	as the value, then this should be true.

	\return A boolean.
*/
bool
commandl::policy::is_empty_valid_assignment() const
	{
	return Empty_Is_Assignment;
	}

/*!
	\brief Is the token separator a valid assignment?

	Instead of explicitly naming an assignment character like "="
	in the following "-a=foo", you'd like to just say "-a foo",
	where "-a" would be one element and "foo" would be the next.
	In this case you would want the token separator to be
	considered an assignment, so the the separation between "-a"
	and "foo" would be considered an assignment assigning the 
	value "foo" to the key "a".

	\return A boolean.
*/
bool
commandl::policy::is_token_separator_assignment()	const
	{
	return Separator_Is_Assignment;
	}

/*!
	\brief No prefix has been found on the element, should parsing continue?

	When the parser has found no matching prefixes that match the 
	beginning of this element (including the empty string if valid),
	what should it do?  This return value tells it to keep going, or stop.

	\return A boolean.
*/
bool
commandl::policy::no_prefix_keep_going() const
	{
	return No_Prefix_Keep_Going;
	}

/*!
	\brief No prefix has been found on the element, should element be kept?

	When the parser has found no matching prefixes that match the 
	beginning of this element (including the empty string if valid),
	and no_prefix_keep_going() returns true, should the element be
	kept by the parser or ignored?

	\return A boolean.
*/
bool
commandl::policy::no_prefix_keep_element() const
	{
	return No_Prefix_Keep_Element;
	}

/*!
	\brief No key has been found in the element, should parsing continue?

	When the parser has found a matching prefix, but no matching key,
	what should it do?  This return value tells it to keep going, or stop.

	\return A boolean.
*/
bool
commandl::policy::no_key_keep_going() const
	{
	return No_Key_Keep_Going;
	}

/*!
	\brief No key has been found in the element, should element be kept?

	When the parser has found a matching prefix, but no matching key,
	and no_key_keep_going() returns true, should the element be
	kept by the parser or ignored?

	\return A boolean.
*/
bool
commandl::policy::no_key_keep_element() const
	{
	return No_Key_Keep_Element;
	}

/*!
	\brief If a value is required, should the next element be taken?

	When the parser has matched a key with an argument, and the 
	argument requires a value, but the next element that could be
	considered as a value begins with a valid prefix, what should
	be done?  If this returns true, then that next element is 
	taken as a value (even though it starts with a prefix).  If this
	returns false, then the required value for the argument is not
	given (most likely causing an exception), but the element with
	a prefix remains in the list of un-parsed elements.

	\return A boolean.
*/
bool
commandl::policy::ignore_prefix_if_value_required() const
	{
	return Ignore_Prefix;
	}


// =========================== Methods ================================ //

/*!
	\brief Adds a string to the end of this policy's list of valid prefixes.

	\param A string which will be added as a valid prefix.
*/
void
commandl::policy::add_prefix( const std::string& new_prefix )
	{
	Prefixes.push_back( new_prefix );
	}

/*!
	\brief Adds a string to the end of this policy's list of valid assignments.

	\param A string which will be added as a valid assignment operator.
*/
void
commandl::policy::add_assignment( const std::string& new_assignment )
	{
	Assignments.push_back( new_assignment );
	}

/*!
	\brief Sets the pair used to enclose optional elements.

	This doesn't really affect the parsing behavior at all, it's
	mostly to make usage statements look the way you want them to.

	\param A pair of strings that will be used to enclose optional elements.
*/
void
commandl::policy::set_optional_brackets
	(
	const std::pair<std::string, std::string>& brackets
	)
	{
	Optional_Brackets = brackets;
	}

/*!
	\brief Sets the pair used to enclose value elements.

	This doesn't really affect the parsing behavior at all, it's
	mostly to make usage statements look the way you want them to.

	\param A pair of strings that will be used to enclose value elements.

*/
void
commandl::policy::set_value_brackets
	(
	const std::pair<std::string, std::string>& brackets
	)
	{
	Value_Brackets = brackets;
	}

/*!
	\brief Sets whether the empty string is a valid prefix.

	\param A Boolean.
*/
void
commandl::policy::is_empty_valid_prefix( bool is_valid )
	{
	Empty_Is_Prefix = is_valid;
	}

/*!
	\brief Sets whether the empty string is a valid assignment.

	\param A Boolean.
*/
void
commandl::policy::is_empty_valid_assignment( bool is_valid )
	{
	Empty_Is_Assignment = is_valid;
	}

/*!
	\brief Sets whether the boundary between elements is a valid assignment.

	\param A Boolean.
*/
void
commandl::policy::is_token_separator_assignment( bool sep_is_assign )
	{
	Separator_Is_Assignment = sep_is_assign;
	}

/*!
	\brief Sets whether to keep going or stop if no prefix is found.

	\param A Boolean.
*/
void 
commandl::policy::no_prefix_keep_going( bool keep_going )
	{
	No_Prefix_Keep_Going = keep_going;
	}

/*!
	\brief Sets whether an element with no prefix should be kept.

	\param A Boolean.
*/
void
commandl::policy::no_prefix_keep_element( bool keep_element )
	{
	No_Prefix_Keep_Element = keep_element;
	}

/*!
	\brief Sets whether to keep going or stop if no key is found.

	\param A Boolean.
*/
void
commandl::policy::no_key_keep_going( bool keep_going )
	{
	No_Key_Keep_Going = keep_going;
	}

/*!
	\brief Sets whether an element with no key should be kept.

	\param A Boolean.
*/
void
commandl::policy::no_key_keep_element( bool keep_element )
	{
	No_Key_Keep_Element = keep_element;
	}

/*!
	\brief Sets whether elements with a valid prefix should be 
	consumed by preceding arguments with required values.

	\param A Boolean.
*/
void
commandl::policy::ignore_prefix_if_value_required( bool ignore_prefix )
	{
	Ignore_Prefix = ignore_prefix;
	}


// --------------------------- Protected Methods ---------------------- //


// --------------------------- Private Methods ------------------------ //

