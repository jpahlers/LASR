/*
This is an abstract base class for command line arguments.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: argument.cpp,v 1.2 2003/03/03 00:52:30 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <string>
#include <vector>
#include "argument.hpp"

/*
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "argument ($Revision: 1.2 $ $Date: 2003/03/03 00:52:30 $)";
*/

// ==================== Constructors & Destructor ==================== //

/*!
	\brief Constructor for a vector of keys.

	This constructor allows for multiple keys for this argument, such 
	that multiple keys can be aliased to this argument.  How the
	keys are matched to command line tokens is dependent on the
	matcher object used.

	\param key_strings		A vector of strings that will be parsed into
							keys (by the matcher) for this argument object.
	\param val_desc			A string which is intended to be a textual
							description of value that this argument takes.
	\param desc				A string which is intended to be a plain textual
							description of the function of this argument.
	\param required			If true, indicates that this argument object is
							required, but it is up to other code to respect
							that.
	\param values_count		This indicates the number of values that this
							argument expects to receive.
	\param values_required	If true, indicates that this argument
							requires a value or values.
					

*/
commandl::argument::argument
	(
	std::vector<std::string>	key_strings,	// keys
	std::string					val_desc,		// description of the value
	std::string					desc,			// description string
	bool						required,		// argument required
	int							values_count,	// number of values
	bool						values_required	// values required?
	)
	:	Keys( 				key_strings		),
		Value_Description(	val_desc		),
		Description(		desc			),
		Argument_Required(	required		),
		Number_Of_Values(	values_count	),
		Values_Required(	values_required	),
		Found(				0				)
	{}

/*!
	\brief Constructor for a single key.

	\overload

	This constructor allows for construction with a single key.
*/
commandl::argument::argument
	(
	std::string	key_string,		// key
	std::string	val_desc,		// description of the value
	std::string	desc,			// description string
	bool		required,		// argument required
	int			values_count,	// number of values
	bool		values_required	// values required?
	)
	:	Value_Description(	val_desc		),
		Description(		desc			),
		Argument_Required(	required		),
		Number_Of_Values(	values_count	),
		Values_Required(	values_required	),
		Found(				0				)
	{
	Keys.push_back( key_string );
	}


// =========================== Accessors ============================== //

/*! 
	\brief Returns the keys for this argument.

	This method returns a copy of the vector of strings that represents
	the keys for this argument.

	\return A vector of strings.
*/
inline std::vector<std::string>
commandl::argument::get_keys() const
	{
	return Keys;
	}

/*!
	\brief Indicates whether this argument is a required argument.

	\return A boolean indicating whether this argument is required.
*/
inline bool
commandl::argument::required() const
	{
	return Argument_Required;
	}

/*!
	\brief Returns the number of values that this argument expects.

	The returned integer indicates to callers how many values this
	argument knows how to deal with.  It also allows callers to 
	determine which of the operator() methods to call.

	If this is 0 or 1, the operator()( string ) version can be called.
	If this is >1 or <0, then operator()( vector<string> ) should be
	called.
	
	It is assumed that callers will check this value prior to a call
	of operator(). Return values >1 will indicate that a vector with
	that many elements will be properly dealt with in operator(),
	conversely negative values here indicate that the operator() is
	expecting to handle a vector with "many" elements.  In this regard
	all negative numbers are identical.

	\return The number of values this argument is prepared to accept.
*/
inline int
commandl::argument::values_size() const
	{
	return Number_Of_Values;
	}

/*!
	\brief Returns whether the values are required by this argument.

	If number_of_values is zero, this value is meaningless.

	\return A boolean indicating whether the values for this argument
			are required.

*/
inline bool
commandl::argument::values_required() const
	{
	return Values_Required;
	}

/*!
	\brief Indicates whether this argument was found.

	This usually indicates that the argument was found during
	a parsing cycle.  However, the found( bool ) method is 
	public, and things other than the argument parser could
	have called it.

	\return A boolean, if true, then this argument was found by something.
*/
inline bool
commandl::argument::was_found() const
	{
	if( Found == 0 )	return false;
	else				return true;
	}

/*!
	\brief Returns an unsigned long int that indicates the order in which 
		this argument was found.

	\return An unsigned long integer indicating the order this argument
			was found.
*/
inline unsigned long
commandl::argument::order() const
	{
	return Found;
	}

/*!
	\brief Gets the description of this argument.

	Be warned that this string may be empty if the programmer is
	lazy.

	\return A string that should describe this argument.
		
*/
inline std::string
commandl::argument::description() const
	{
	return Description;
	}

/*!
	\brief Gets the description of the value.

	\return A string that should describe the value or values that
			this argument takes.
*/
inline std::string
commandl::argument::value_description() const
	{
	return Value_Description;
	}

// =========================== Methods ================================ //

/*!
	\brief Allows addition of another string to the list of keys.

	This is generally used for adding more aliases to a particular
	argument.

	\param new_key The string that should be added to the list of
					keys for this argument.

*/
void
commandl::argument::add_key( const std::string& new_key )
	{
	Keys.push_back( new_key );
	return;
	}

/*!
	\brief Sets the order in which this argument was found.

	This argument should be given the an unsigned long value 
	indicating the order in which this argument was found.
	For example, if the prefix were a "-", and the following are
	valid keys: "s" (which takes a value), "z", "x", "v", "f" 
	(which takes a value), and "blah".  Then if we get the
	following tokens:

		-sstate -zxvf foo.txt -blah

	then the following unsigned long ints should be assigned to
	the found method:

	<table>
	<tr><td>key		<td>value	<td>found() value
	<tr><td>s		<td>state	<td>1
	<tr><td>z		<td>(true)	<td>2
	<tr><td>x		<td>(true)	<td>3
	<tr><td>v		<td>(true)	<td>4
	<tr><td>f		<td>foo.txt	<td>5
	<tr><td>blah	<td>(true)	<td>6
	</table>

	\param order	The unsigned long integer indicating the order
					that this argument was found in.
*/
void
commandl::argument::found( const unsigned long order )
	{
	Found = order;
	return;
	}


// --------------------------- Protected Methods ---------------------- //

/*!
	\brief Allows assignment of the number_of_values this argument accepts.

	This method sets the number of values this argument accepts, and
	returns the old_value;

int
argument::number_of_values( int new_number )
	{
	int old_number = number_of_values;
	number_of_values = new_number;
	return old_number;
	}

*!
	\brief Allows user to set whether the values for this argument are required.

	This method sets the requirement status of the values for this 
	argument, and returns the old value.

bool
argument::is_required( bool new_required )
	{
	bool old_required = values_required;
	values_required = new_required;
	return old_required;
	}
*/

// --------------------------- Private Methods ------------------------ //

