/*
This is a descendent of argument that will display a usage statement.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: usage_arg.cpp,v 1.2 2003/03/03 00:52:30 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "exceptions.hpp"
#include "argument.hpp"
#include "usage_arg.hpp"

/*
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "int_arg ($Revision: 1.2 $ $Date: 2003/03/03 00:52:30 $)";
*/

// ==================== Constructors & Destructor ==================== //

commandl::usage_arg::usage_arg
	(
	std::vector<std::string>		keys,	// keys
	std::string						desc	// description
	)
	:	argument( keys, std::string(), desc, false, int(0), false )
	{ }

commandl::usage_arg::usage_arg
	(
	std::string						key,	// key
	std::string						desc	// description
	)
	:	argument( key, std::string(), desc, false, int(0), false )
	{ }


// =========================== Accessors ============================== //


// =========================== Methods ================================ //

/*!
	\brief This method basically just throws the usage_exception.

*/
void
commandl::usage_arg::operator()
	(
	const std::string&	prefix,
	const std::string&	key,
	const unsigned long	order
	)
	{
	throw usage_exception( "Usage Argument", key );
	found( order );
	return;
	}

/*!
	\brief This method will result in throwing a usage_exception.
*/
void
commandl::usage_arg::operator()
	(
	const std::string&	value,
	const std::string&	prefix,
	const std::string&	key,
	const std::string&	assign,
	const unsigned long	order
	)
	{
	operator()( prefix, key, order );
	return;
	}

/*!
	\brief This method will result in throwing a usage_exception.
*/
void
commandl::usage_arg::operator()
	(
	const std::vector<std::string>&		values,
	const std::string&					prefix,
	const std::string&					key,
	const std::string&					assign,
	const unsigned long					order
	)
	{
	operator()( prefix, key, order );
	return;
	}

// --------------------------- Protected Methods ---------------------- //


// --------------------------- Private Methods ------------------------ //

