/*
This descendent of matcher, performs matches against a whole string.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: whole_matcher.cpp,v 1.3 2003/03/03 00:52:30 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "exceptions.hpp"
#include "argument.hpp"
#include "matcher.hpp"
#include "whole_matcher.hpp"
#include <map>
#include <string>
#include <vector>

#if defined (DEBUG)
/*******************************************************************************        DEBUG controls
 
        DEBUG report selection options.
        Define any of the following options to obtain the desired debug reports:*/
#define DEBUG_ALL               (-1)
#define DEBUG_CONSTRUCTORS      (1 << 0)
#define DEBUG_ACCESSORS         (1 << 1)
 
#include        <iostream>
#include        <iomanip>
using std::cerr;
using std::endl;
#endif  //      DEBUG

/*
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "matcher ($Revision: 1.3 $ $Date: 2003/03/03 00:52:30 $)";
*/

// ==================== Constructors & Destructor ==================== //

commandl::whole_matcher::whole_matcher()
	: matcher()
	{ }

commandl::whole_matcher::whole_matcher
	(
	std::vector<argument*> arguments
	)
	: matcher()
	{
	Keys = resolve_keys( arguments );
	}

commandl::whole_matcher::~whole_matcher()
	{ }

// =========================== Accessors ============================== //

/*!
	\brief This method tries to match the whole key exactly.
*/
commandl::argument*
commandl::whole_matcher::match( const std::string& key ) const
	{
	using std::map;
	using std::string;

	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << ">>> whole_matcher::match (" << key << ")" << endl;
	#endif

	// Let's try and find this key.
	map<string, argument*>::const_iterator matched_iter
															= Keys.find( key );

	if( matched_iter == Keys.end() )
		{
		throw matcher_exception	(
								"Couldn't find a key matching \"" 
								+ key + "\"",
								key
								);
		}

	argument* matched_arg = matched_iter->second;

	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << "<<< whole_matcher::match (" << key << ") returned a match."
			<< endl;
	#endif
	return matched_arg;
	//return (*matched_iter)->second;
	}

/*!
	\brief Given a key string, it will return a value that the matcher would
		use to match against.
*/
std::string
commandl::whole_matcher::usage_key( const std::string& key ) const
	{
	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << ">>> whole_matcher::usage_key(" << key << ")" << endl;
	cerr << "<<< whole_matcher::usage_key(" << key << ") returns: "
			<< key << endl;
	#endif

	return key;
	}


/*!
	\brief Given a vector of key strings, it will return a vector of values
		that the matcher would use to match against.
*/
std::vector<std::string>
commandl::whole_matcher::usage_keys
	(
	const std::vector<std::string>& keys
	) const
	{
	return keys;
	}

// =========================== Methods ================================ //

/*!
	\brief This method performs the task of providing unique keys.

	For this class, doing so involves taking each of the whole strings
	from the potential keys provided by the arguments.  If there
	is a conflict between two potential keys (if one of arg1's keys was
	"f" and and one of arg2's keys was "f"), then this method will throw.

*/
std::map<std::string, commandl::argument*>
commandl::whole_matcher::resolve_keys
	(
	const std::vector<argument*>& arguments
	)
	{
	using std::map;
	using std::string;
	using std::vector;
	
	map<string, argument*>	key_map;
	map<string, int>				key_count;

	for	(
		vector<argument*>::const_iterator arg_iter = arguments.begin();
		arg_iter != arguments.end();
		++arg_iter
		)
		{
		vector<string> arg_keys = (*arg_iter)->get_keys();

		for	(
			vector<string>::const_iterator arg_key_iter = arg_keys.begin();
			arg_key_iter != arg_keys.end();
			++arg_key_iter
			)
			{
			
			// note that below initializes key_count[*arg_key_iter] to zero.
			if( key_count[*arg_key_iter] > 0 )
				{
				throw matcher_exception	(
										"The potential key \""
										+ *arg_key_iter
										+ "\" is duplicated.",
										*arg_key_iter
										);
				}

			key_map[*arg_key_iter]		= *arg_iter;
			key_count[*arg_key_iter]	+= 1;
			}
		}

	return key_map;
	}

/*!
	\brief This method returns a newed copy of this object.

	Since the pointer returned has been newed, it is imperative that
	callers of this method are sure to call delete on the pointer.
*/
commandl::whole_matcher*
commandl::whole_matcher::clone() const
	{
	return new whole_matcher( *this );
	}

// --------------------------- Protected Methods ---------------------- //


// --------------------------- Private Methods ------------------------ //

