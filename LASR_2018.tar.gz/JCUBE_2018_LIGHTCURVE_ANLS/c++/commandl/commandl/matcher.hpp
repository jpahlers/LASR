/*
This is an abstract base class for matching potential keys to arguments.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: matcher.hpp,v 1.3 2003/03/25 23:53:36 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef MATCHER_HEADER	// Begin the Header Guard to prevent multiple
#define MATCHER_HEADER	//	inclusions.

#include <map>
#include <string>
#include <vector>


namespace commandl
{
class argument; // forward declaration

/*!
	\brief The class from which all matchers descend.

	The concept of a separate matcher arose because I felt that an
	argument shouldn't really be concerned with that activity.  And it
	also allows you to change whether your program would match on
	the first character of a key or the whole string of the key just
	by changing which matcher object you use, and not changing all of
	the argument objects.  This also allows you to write your own
	matchers, which can be arbitrarily complex.  An external matcher
	just separates and encapsulates the activity of determining whether
	a given string matches any of the keys of the various arguments
	that the matcher knows about.
	
	A commandl::matcher object knows about and uses commandl::argument
	objects.  Conversely, it is used by commandl::parser objects.

	This class contains a number of pure virtual methods that must
	be overridden by derived classes.

	It is suggested that derived matchers have a constructor that
	takes a vector of argument* and then calls the resolve_keys
	method on them.

	The match method is the primary method of the matcher class, and
	when given a string the matcher determines whether there is an
	appropriate match, and either returns the corresponding argument*
	from its Keys or throws a matcher_exception if it cannot find a match.

	The usage_key and usage_keys methods are intended to allow a user of 
	the matcher to pass in a string (or a vector of same), and the matcher
	will return a string (or a vector of same) that the matcher would use
	as a key.  It is mostly meant for the usage statement and other
	human-readable outputs.

	The resolve_keys method returns a map of keys to arguments, and is 
	the primary method that should be called upon construction of a 
	new matcher.  It sets up the keys and can throw a matcher_exception
	if it discovers a duplicate key according to its rules.

	The clone method is intended to allow users of a matcher to easily
	create a copy of a pointer to a matcher object for polymorphism
	reasons.
	
*/
class matcher
{

// ==================== Constructors & Destructor ===================== //
public:
	matcher();

	/*	It is highly suggested that you implement a constructor of this
		form when deriving a class from matcher.
	matcher
		(
		std::vector<argument*> // arguments
		);
	*/

	virtual ~matcher() = 0;

// =========================== Accessors ============================== //
public:

	virtual argument*
	match( const std::string& ) const = 0;

	virtual std::string
	usage_key( const std::string& ) const = 0;

	virtual std::vector<std::string>
	usage_keys( const std::vector<std::string>& ) const = 0;

	virtual std::map<std::string, argument*>
	keys() const;

// =========================== Methods ================================ //
public:

	virtual void
	set_arguments( const std::vector<argument*>& );

	virtual std::map<std::string, argument*>
	resolve_keys
		(
		const std::vector<argument*>&
		) = 0;

	virtual matcher*
	clone() const = 0;

// --------------------------- Protected Methods ---------------------- //
protected:


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:

	//! The map of unique keys to arguments.
	std::map<std::string, argument*>	Keys;

};	// End of the class declaration

}	// End of the namespace declaration

#endif	// End the Header Guard

