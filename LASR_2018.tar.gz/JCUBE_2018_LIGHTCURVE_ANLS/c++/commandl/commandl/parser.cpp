/*
This is an abstract base class for parsers.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: parser.cpp,v 1.7 2003/03/31 04:50:51 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "parser.hpp"

#include "exceptions.hpp"
#include "argument.hpp"
#include "matcher.hpp"
#include "whole_matcher.hpp"
#include "policy.hpp"
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <iterator>
#include <string>
#include <utility>
#include <vector>

#if defined (DEBUG)
/*******************************************************************************        DEBUG controls
 
        DEBUG report selection options.
        Define any of the following options to obtain the desired debug reports:*/
#define DEBUG_ALL               (-1)
#define DEBUG_CONSTRUCTORS      (1 << 0)
#define DEBUG_ACCESSORS         (1 << 1)
#define DEBUG_METHODS           (1 << 2)
 
#include        <iomanip>
using std::cerr;
using std::endl;
#endif  //      DEBUG


/*!
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "parser ($Revision: 1.7 $ $Date: 2003/03/31 04:50:51 $)";
*/

// ==================== Constructors & Destructor ==================== //

/*
commandl::parser::parser
	(
	matcher					matcher,
	policy					policy
	)
	:	Matcher(	matcher ),
		Policy(		policy	)
	{ }
*/

/*!
	\brief This is one of the many constructors for parser.
*/
commandl::parser::parser
	(
	const std::vector<argument*>&	arguments,
	const matcher&					matcher,
	const policy&					policy
	)
	:	Arguments(			arguments		),
		Matcher_ptr(		matcher.clone()	),	// there is a new in clone()
		Policy(				policy			),
		Throws_Exceptions(	false			)
	{
	if( ( Matcher_ptr->keys() ).empty() )
		{
		Matcher_ptr->set_arguments( arguments );
		}
	}

/*!
	\brief This constructor uses a default policy object.
*/
commandl::parser::parser
	(
	const std::vector<argument*>&	arguments,
	const matcher&					matcher
	)
	:	Arguments(			arguments		),
		Matcher_ptr(		matcher.clone()	),	// there is a new in clone()
		Policy(				policy()	),
		Throws_Exceptions(	false			)
	{
	if( ( Matcher_ptr->keys() ).empty() )
		{
		Matcher_ptr->set_arguments( arguments );
		}
	}

/*!
	\brief This constructor uses both a default policy object and a default
	matcher object.
*/
commandl::parser::parser
	(
	const std::vector<argument*>&	arguments
	)
	:	Arguments(			arguments					),
		Matcher_ptr(		whole_matcher().clone()		),
		Policy(				policy()				),
		Throws_Exceptions(	false						)
	{
	Matcher_ptr->set_arguments( arguments );
	}

/*!
	\brief This constructor is a copy constructor allowing a new parser
	object to be created from an existing parser object.
*/
commandl::parser::parser
	(
	const commandl::parser& parser
	)
	:	Arguments(					parser.Arguments					),
		Matcher_ptr(				parser.Matcher_ptr->clone() 		),
		Policy(						parser.Policy						),
		Throws_Exceptions(			parser.Throws_Exceptions			),
		Name(						parser.Name							),
		Position(					parser.Position						),
		Stop_Position(				parser.Stop_Position				),
		Elements(					parser.Elements						),
		Elements_without_prefixes(	parser.Elements_without_prefixes	),
		Elements_without_keys(		parser.Elements_without_keys		),
		Elements_after_stop(		parser.Elements_after_stop			)
	{ }

/*!
	\brief This destructor takes care of cleaning things up.
*/
commandl::parser::~parser()
	{
	delete Matcher_ptr;
	}

// =========================== Accessors ============================== //

/*!
    \brief Returns the Name for this parser.
 
    \return A string.
*/
std::string
commandl::parser::name() const
	{
	return Name;
	}

/*!
    \brief Returns the Position where the parser stopped.

	For most cases, this will be the last Position.  However,
	if the parser came across a stop_arg, then parsing would
	have terminated sooner.
 
    \return An unsigned long
*/
unsigned long
commandl::parser::stop_position() const
	{
	if( Stop_Position == 0 )
		{
		return Position;
		}
	else
		{
		return Stop_Position;
		}
	}

/*!
    \brief Returns the elements without valid prefixes.

	If the parser's Policy allows it, when elements that
	do not have a valid prefix are found, they are placed
	in this map, indexed by their Position.
	
    \return A map of Positions and elements.
*/
std::map<unsigned long, std::string>
commandl::parser::elements_without_prefixes() const
	{
	return Elements_without_prefixes;
	}

/*!
    \brief Returns the elements without matching keys.

	If the parser's Policy allows it, when elements that
	do not match a key are found, they are placed
	in this map, indexed by their Position.
	
    \return A map of Positions and elements.
*/

std::map<unsigned long, std::string>
commandl::parser::elements_without_keys() const
	{
	return Elements_without_keys;
	}

/*!
    \brief Returns the elements after the Stop_Position.

	If parsing is stopped before all of the elements are
	parsed, then the remaining elements can be retrieved
	via this method.  The map contains their Positions and
	the elements themselves.
	
    \return A map of Positions and elements.
*/
std::map<unsigned long, std::string>
commandl::parser::elements_after_stop() const
	{
	return Elements_after_stop;
	}

/*!
    \brief Returns a complete usage statement based on the parser's Arguments.

	This method places a full usage statement on the given ostream.  It
	consists of the information for all of the Arguments that this parser
	knows about.  This method is written such that it can easily be used in 
	a standard ostream inserter sequence, if desired.
	
    \return An ostream reference.
*/
std::ostream&
commandl::parser::usage( std::ostream& output ) const
	{
	using std::string;
	using std::vector;

	short_usage( output );

	output << std::endl;

	for	(
		vector<argument*>::const_iterator arg_iter = Arguments.begin();
		arg_iter != Arguments.end();
		++arg_iter
		)
		{
		usage( *arg_iter, output );
		}

	output << std::endl;
	return output;
	}

/*!
    \brief Returns a usage statement for the given argument_ptr.

	This method places a full usage statement about the given argument.
	This method is written such that it can easily be used in 
	a standard ostream inserter sequence, if desired.
	
    \return An ostream reference.
*/
std::ostream&
commandl::parser::usage
	(
	argument* argument_ptr,
	std::ostream& output
	) const
	{
	using std::string;
	using std::vector;

	string prefix;
	if( !Policy.prefixes().empty() )
		{
		prefix = Policy.prefixes().front();
		}

	vector<string> keys = Matcher_ptr->usage_keys( (*argument_ptr).get_keys() );

	int argument_width		= 9;
	int description_width	= 60;

	std::ostringstream args;
	args << prefix;
	if( keys.size() > 1 )
		{
		vector<string>::iterator penultimate_key_iter = keys.end();
		string delim( ", " + prefix );
		std::copy	(
					keys.begin(), --penultimate_key_iter,
					std::ostream_iterator<string>( args, delim.c_str() )
					);
		}
	args << keys.back();

	std::string leading;
	if( args.str().size() >= argument_width )
		{
		output << args.str() << std::endl;
		leading = output.fill();
		}
	else
		{
		leading = args.str();
		}

	std::istringstream raw_description( (*argument_ptr).description() );
	std::ostringstream formated_description;
	while( raw_description )
		{
		std::string item;
		raw_description >> item;
		if	(
			formated_description.str().size() + item.size() + 1
				> description_width
			)
			{
			output << std::right << std::setw(argument_width) << leading 
				<< std::left << " "
				<< std::setw(description_width) << formated_description.str() 
				<< std::endl;
			leading = output.fill();
			formated_description.str("");
			formated_description << "  ";
			}
		formated_description << " " << item;
		}

	output << std::right << std::setw(argument_width) << leading 
		<< std::left << " "
		<< std::setw(description_width) << formated_description.str() 
		<< std::endl;
	
	return output;
	}

/*!
    \brief Returns a short usage statement based on the parser's Arguments.

	This method places a short, one-line, usage statement on the given 
	ostream.  It consists of the information for all of the Arguments that
	this parser knows about.  This method is written such that it can 
	easily be used in a standard ostream inserter sequence, if desired.

	\param The ostream on which to write.

    \return An ostream reference.
*/
std::ostream&
commandl::parser::short_usage( std::ostream& output ) const
	{
	using std::string;
	using std::vector;

	output << Name << " Usage: ";

	for	(
		vector<argument*>::const_iterator arg_iter = Arguments.begin();
		arg_iter != Arguments.end();
		++arg_iter
		)
		{
		//output << short_usage( *arg_iter, output ) << " ";
		short_usage( *arg_iter, output );
		output << " ";
		}
	
	// Add information about alternate prefixes.
	if( Policy.prefixes().size() > 1 )
		{
		vector<string>::iterator prefix_iter = Policy.prefixes().begin();
		output	<< "In addition to \"" << *prefix_iter++ 
				<< "\", other acceptable prefixes are: ";
		// There is a fancy way to do this, the following may not be it.
		//copy( prefix_iter, Policy.prefixes().end(), output, ", " );
		}

	// Add information about alternate assignments.
	if( Policy.assignments().size() > 1 )
		{
		vector<string>::iterator assign_iter = Policy.assignments().begin();
		output	<< "In addition to \"" << *assign_iter++ 
				<< "\", other acceptable assignments are: ";
		// There is a fancy way to do this, the following may not be it.
		//copy( assign_iter, Policy.assignments().end(), output, ", " );
		}

	output << std::flush;
	return output;
	}

/*!
    \brief Returns a short usage statement for the given argument_ptr.

	This method places a short usage statement about the given argument.
	This method is written such that it can easily be used in 
	a standard ostream inserter sequence, if desired.

	\param An argument* that we will get the usage information from.

	\param The ostream on which to write.
	
    \return An ostream reference.
*/
std::ostream&
commandl::parser::short_usage
	(
	argument* argument_ptr,
	std::ostream& output
	) const
	{
	using std::pair;
	using std::string;
	using std::vector;

	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << ">>> parser::short_usage( argument*, std::ostream& )" << endl;
	#endif

	string prefix;
	if( !Policy.prefixes().empty() )
		{
		prefix = Policy.prefixes().front();
		}

	string assign;
	if( Policy.assignments().empty() )
		{
		assign.assign( " " );
		}
	else
		{
		assign = Policy.assignments().front();
		}


	// Put on the brackets if needed.
	if( !(*argument_ptr).required() )
		{
		output << Policy.optional_brackets().first;
		}

	// Get an appropriate key string from the Matcher.
	string temp_key = ( (*argument_ptr).get_keys() ).front();

	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << "    temp key: " << temp_key << endl;
	#endif

	string key = Matcher_ptr->usage_key( temp_key );

	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << "    matched key: " << key << endl;
	#endif

	output << prefix << key;

	// Print the value part.
	if( !( (*argument_ptr).value_description().empty() ) )
		{
		if( !(*argument_ptr).values_required() )
			{
			output << Policy.optional_brackets().first;
			}
		output	<< assign
				<< Policy.value_brackets().first
				<< (*argument_ptr).value_description()
				<< Policy.value_brackets().second;
		if( !(*argument_ptr).values_required() )
			{
			output << Policy.optional_brackets().second;
			}
		}

	// We're done with this one, put on the brackets if needed.
	if( !(*argument_ptr).required() )
		{
		output << Policy.optional_brackets().second;
		}

	output.flush();
	
	#if ((DEBUG) & DEBUG_ACCESSORS)
	cerr << "<<< parser::short_usage( argument*, std::ostream& )" << endl;
	#endif
	return output;
	}


// =========================== Methods ================================ //

/*!
	\brief This simply sets a string that the parser will use as the name
	of this program in usage statements.

	This value doesn't affect the parsing at all.

	\param A string that will be used as the name.
*/
void
commandl::parser::set_name( const std::string& name )
	{
	Name.assign( name );
	}

/*!
	\brief Determines whether this parser will throw exceptions or not.

	The default behavior is for the parser to not throw any exceptions
	when parse() is called.  If there is a failure within that operation,
	the parse() method will simply return false.  However, if you'd
	like to get more information, you can always set this on, and get
	the exceptions out of the parse() method that may allow you more
	refined control.

	\param A boolean.
*/
void
commandl::parser::exceptions( bool throws_exceptions )
	{
	Throws_Exceptions = throws_exceptions;
	}

/*!
	\brief This is the main argument parsing method for this class.

	This library will <strong>not</strong> terminate your program, that's
	your job.  As such, it is highly recommended that you check the
	return value of this method (or turn on exceptions and catch them
	via the exceptions() method), and do something appropriate (maybe
	calling the usage() statement and exiting) if the value is false.

	This class does little more than convert the char** into a proper
	STL container and pass it to a different version of parse.

	\param An integer that is the number of elements in the char** array.

	\param A char** array with the tokens to parse.

	\param An ostream on which to write error messages.

	\return A boolean indicating success or failure.
*/
bool
commandl::parser::parse( int argc, char** argv, std::ostream& output )
	{
	// ? int argc = sizeof( argv ) / sizeof( argv[0] );

	// Assume that the char** is the program's argv, in which
	// case the first element is the program's name, not an argument.
	set_name( argv[0] );
	std::vector<std::string> elements( argv + 1, argv + argc );
	return parse( elements, output );
	}

/*!
	\brief This is the method that will parse the passed container.

	This method does the work of parsing the elements based on this
	object's matcher and policy.

	This library will <strong>not</strong> terminate your program, that's
	your job.  As such, it is highly recommended that you check the
	return value of this method (or turn on exceptions and catch them
	via the exceptions() method), and do something appropriate (maybe
	calling the usage() statement and exiting) if the value is false.

	\param A vector of strings that will be parsed for arguments.

	\param An ostream on which to write error messages.

	\return A boolean indicating success or failure.
*/
bool
commandl::parser::parse
	(
	std::vector<std::string> elements,
	std::ostream& output
	)
try
	{
	using std::string;
	using std::vector;
	using std::pair;

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << ">>> parser::parse(std::vector<std::string>, std::ostream&)"
		<< endl;
	#endif
	
	Elements.swap( elements );
	
	Position = 0;
	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "    ready to start iterating over the elements"
		<< endl;
	#endif
	for	(
		vector<string>::iterator element_iter = Elements.begin();
		element_iter != Elements.end();
		++element_iter
		)
		{
		string prefix;
		string key;
		string assignment;
		string value;
		string element_remainder;
		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    element is: " << *element_iter << endl;
		#endif

		try
			{		
			// The first step is to try and match with a prefix.
			try
				{
				pair<string,string> prefix_result
									= separate_prefix_from( *element_iter );
				prefix				= prefix_result.first;
				element_remainder	= prefix_result.second;
				#if ((DEBUG) & DEBUG_METHODS)
				cerr << "    found a prefix: " << prefix << " from " 
					<<  element_remainder   << endl;
				#endif
				}
			catch( const no_prefix& ex )
				{
				#if ((DEBUG) & DEBUG_METHODS)
				cerr << "    no prefix could be matched" << endl;
				#endif
				// No valid prefix has been found.
				if( Policy.no_prefix_keep_going() )
					{
					if( Policy.no_prefix_keep_element() )
						{
						Elements_without_prefixes.insert
										(
										make_pair(++Position, *element_iter)
										);
						}
					continue; // advance to the next element.
					}
				else
					{
					//stop parsing
					#if ((DEBUG) & DEBUG_METHODS)
					cerr << "    about to throw stop_parsing" << endl;
					#endif
					throw stop_parsing
							(
							"Stopped parsing due to element without prefix."
							);
					}
				}
			
			// We have now identified a valid prefix.

			// Now we must search for the assignment.
			pair<string::size_type,string> assignment_result
									= find_assignment_in( element_remainder );
			if( assignment_result.first != string::npos )
				{
				assignment = assignment_result.second;
				key = element_remainder.substr	(
												string::size_type( 0 ),
												assignment_result.first
												);
				value = element_remainder.substr(
												assignment_result.first
												+ assignment.size()
												);
				}
			else
				{
				key = element_remainder;
				}
			#if ((DEBUG) & DEBUG_METHODS)
			cerr << "    the key is " << key << endl;
			#endif
			
			// We have now identified a key (and possibly some other stuff).
			// Now we need to ask the matcher for a match.
			try
				{
				// The following will return a match, or throw.
				argument* matched_arg_ptr = Matcher_ptr->match( key );
				#if ((DEBUG) & DEBUG_METHODS)
				cerr << "    found a match" << endl;
				#endif

				if( (*matched_arg_ptr).values_size() == 0 )
					{
					// This argument doesn't want any values.
					if( value.empty() )
						{
						(*matched_arg_ptr)( prefix, key, ++Position );
						}
					else
						{
						// We got a value that shouldn't be there.
						throw parser_exception	(
				"A value has been identified for an argument that forbids it.",
												key
												);
						}
					}
				else
					{
					// This argument is after one or more values.
					#if ((DEBUG) & DEBUG_METHODS)
					cerr <<  "    state of things" 
						<< "\n      prefix: " << prefix 
						<< "\n      key: " << key
						<< "\n      assign: " << assignment
						<< "\n      value: " << value << endl;
					#endif
					if( (*matched_arg_ptr).values_required() )
						{
						#if ((DEBUG) & DEBUG_METHODS)
						cerr << "    value required" << endl;
						#endif
						parse_required_values	(
												prefix,
												key,
												assignment,
												value,
												matched_arg_ptr,
												element_iter,
												Elements.end()
												);
						#if ((DEBUG) & DEBUG_METHODS)
						cerr << "    required done" << endl;
						#endif
						}
					else
						{
						#if ((DEBUG) & DEBUG_METHODS)
						cerr << "    value optional" << endl;
						#endif
						parse_optional_values	(
												prefix,
												key,
												assignment,
												value,
												matched_arg_ptr,
												element_iter,
												Elements.end()
												);
						#if ((DEBUG) & DEBUG_METHODS)
						cerr << "    optional done, element is " 
							<< *element_iter << endl;
						#endif
						}
					}
				}
			catch( const matcher_exception& ex )
				{
				#if ((DEBUG) & DEBUG_METHODS)
				cerr <<  "    there was no match"
					<< "\n    is_empty_valid_assignment(): " 
					<< Policy.is_empty_valid_assignment() << endl;
				#endif
				if( Policy.is_empty_valid_assignment() && !key.empty() )
					{
					#if ((DEBUG) & DEBUG_METHODS)
					cerr << "    char" << endl;
					#endif
					try
						{
						parse_character_keys(
											prefix,
											key,
											element_iter,
											Elements.end()
											);
						}
					catch( const no_key& ex )
						{
						//string character_invalid_key = ex.element();
						string message( "The element \"" );
						message += ex.element();
						message += "\" from within \"";
						message += prefix + key;
						message += "\" is not a valid key.";
						throw no_key( message, key );
						}
					#if ((DEBUG) & DEBUG_METHODS)
					cerr << "    char done, element is " 
						<< *element_iter << endl;
					#endif
					}
				else
					{
					if( Policy.no_key_keep_going() )
						{
						if( Policy.no_key_keep_element() )
							{
							Elements_without_keys.insert
											(
											make_pair(++Position, *element_iter)
											);
							}
						continue; // advance to the next element.
						}
					else
						{
						string message( "The element \"" );
						message += prefix + key;
						message += "\" is not a valid key.";
						throw no_key( message, key );
						}
					}
				}

			}
		catch( const stop_parsing& ex )
			{
			/* This catch is inside the for loop so that it can 
				access element_iter.
			*/
			#if ((DEBUG) & DEBUG_METHODS)
			cerr << "    caught stop_parsing" << endl;
			#endif
			Stop_Position = Position;
			
			for	( ;
				element_iter != Elements.end();
				++element_iter
				)
				{
				#if ((DEBUG) & DEBUG_METHODS)
				cerr << "    element to insert " << *element_iter << endl;
				#endif
				Elements_after_stop.insert
					(
					make_pair(++Position, *element_iter)
					);
				}
			
			// maybe set up something in the policy about re-throwing 
			// this if asked to do so.

			#if ((DEBUG) & DEBUG_METHODS)
			cerr << "    done with stop_parsing" << endl;
			#endif
			// return; <-- not needed because of the next if statement?
			}
		if( element_iter == Elements.end() ) break;
		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    end of element cycle, element is " 
			<< *element_iter << endl;
		#endif
		}
	
	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "    finished iterating through the elements." << endl;
	#endif

	// We are now finished parsing, so we need to check to make sure that
	// all the required arguments were found.
	for	(
		vector<argument*>::iterator argument_iter = Arguments.begin();
		argument_iter != Arguments.end();
		++argument_iter
		)
		{
		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    checking for required arguments." << endl;
		#endif
		if	(
			(*argument_iter)->required() && !(*argument_iter)->was_found()
			)
			{
			// Argument was required, but not found.
			string message( "The argument \"" );
			message += (*argument_iter)->get_keys().front();
			message += "\" was required, but not found.";
			throw parser_exception
					(
					message,
					(*argument_iter)->get_keys().front()
 					);
			}
		}

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "<<< parser::parse(std::vector<std::string>, std::ostream&)"
		<< endl;
	#endif
	return true;
	}
catch( const commandl::usage_exception& ex )
	{
	/* We have gotten a usage_exception, which means that we have
		encountered a usage argument in the parsing.  It is not
		this module's job to exit a user's program.  The user needs
		to either have us throwing exceptions, or catching the boolean
		return value of parse(), and do something appropriate.
	*/	
	if( Throws_Exceptions ) { throw; }

	usage( output );
	return false;
	}
catch( const commandl::argument_exception& ex )
    {
	if( Throws_Exceptions ) { throw; }

    output << ex.what() << std::endl;
	usage( ex.arg_ptr(), output );
	return false;
    }
catch( const commandl::exception& ex )
	{
	if( Throws_Exceptions ) { throw; }
	
    output << ex.what() << std::endl;
	usage( output );
	return false;
	}

/*!
	\brief This method properly overloads the = for a parser.

	\param A parser object.

	\param A reference to a parser object.
*/
commandl::parser&
commandl::parser::operator=( const parser& parser )
	{
	if( this == &parser ) return *this;
		
	Arguments					= parser.Arguments;
	Matcher_ptr					= parser.Matcher_ptr->clone();
	Policy						= parser.Policy;
	Name						= parser.Name;
	Position					= parser.Position;
	Stop_Position				= parser.Stop_Position;
	Elements					= parser.Elements;
	Elements_without_prefixes	= parser.Elements_without_prefixes;
	Elements_without_keys		= parser.Elements_without_keys;
	Elements_after_stop			= parser.Elements_after_stop;

	return *this;
	}


// --------------------------- Protected Methods ---------------------- //

/*!
	\brief Identifies a prefix in the passed string and returns a pair.

	The returned pair's first element is the prefix, and the second 
	element is the non-prefix part of the passed in string.  If this
	method cannot find a prefix, it will throw.

	\param A string.

	\return A pair of strings.
*/
std::pair<std::string, std::string>
commandl::parser::separate_prefix_from
	(
	std::string element
	)
	{
	using std::string;
	using std::vector;

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << ">>> parser::separate_prefix_from(" << element << ")" << endl;
	#endif

	vector<string> prefixes	= Policy.prefixes();
	string::size_type beginning(0);

	for	(
		vector<string>::iterator prefix_iter = prefixes.begin();
		prefix_iter != prefixes.end();
		++prefix_iter
		)
		{
		if( element.find( *prefix_iter ) == beginning )
			{
			// Great, we've identified a prefix.
			//string prefix(				*prefix_iter					 );
			string element_remainder( element.substr(( *prefix_iter ).size()) );
			return make_pair( *prefix_iter, element_remainder );
			}
		}
	// No matching prefix has been found.

	#if ((DEBUG) & DEBUG_METHODS)	
	cerr << "    is_empty_valid_prefix: " 
		<< Policy.is_empty_valid_prefix()  << endl;
	#endif
	if( Policy.is_empty_valid_prefix() )
		{
		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    setting prefix to empty" << endl;
		cerr << "<<< parser::separate_prefix_from(" << element << ")"
			<< endl;
		#endif
		return make_pair( string(""), element );
		}

	// No valid prefix has been found.
	throw no_prefix	(
					"No matching prefix could be found in \""
					+ element + "\".",
					element
					);
	}

/*!
	\brief  Identifies an assignment operator in a string.

	This method searches for a valid assignment operator within
	the string.  If it identifies one it returns the position 
	of that assignment operator and string that is the operator 
	that was found.  If it doesn't find one, it still returns 
	a pair where the location is string::npos, and the opertor
	is the empty string.

	\param A string to be searched.

	\return A pair of std::string::size_type and a string.

*/
std::pair<std::string::size_type, std::string>
commandl::parser::find_assignment_in
	(
	std::string element
	)
	{
	using std::string;
	using std::vector;

	// Now we must search for the assignment.
	vector<string> assignments	= Policy.assignments();
	for	(
		vector<string>::iterator assign_iter = assignments.begin();
		assign_iter != assignments.end();
		++assign_iter
		)
		{
		string::size_type assignment_position = element.find( *assign_iter );
		if( assignment_position != string::npos )
			{
			// Great, we've identified a valid assignment.
			return make_pair( assignment_position, *assign_iter);
			}
		}
	// No assignment has been found within the element.
	return make_pair( string::npos, string("") );
	}

/*!
	\brief This method determines if there is a prefix and key in a string.

	This method either returns quietly, or throws if it cannot identify
	a valid prefix and a valid key within the given string.

	\param A string.
*/
void
commandl::parser::identify_prefix_and_key( std::string element )
	{
	using std::pair;
	using std::string;

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << ">>> parser::identify_prefix_and_key(" << element << ")" << endl;
	#endif

	pair<string,string> prefix_result = separate_prefix_from( element );

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "    there is a prefix on " << element << endl;
	#endif

	pair<string::size_type,string> assignment_result
				= find_assignment_in( prefix_result.second );

	string key = prefix_result.second.substr(
											string::size_type( 0 ),
											assignment_result.first
											);
	try
		{
		Matcher_ptr->match( key );
		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    there is a match on " << key << endl;
		#endif
		}
	catch( const matcher_exception& ex )
		{
		if( Policy.is_empty_valid_assignment() && !key.empty() )
			{
			string char_key = key.substr(
										string::size_type( 0 ),
										string::size_type( 1 )
										);
			Matcher_ptr->match( char_key );
			#if ((DEBUG) & DEBUG_METHODS)
			cerr << "    there is a match on " << char_key << std::endl;
			#endif
			}
		else
			{
			throw;
			}
		}
	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "<<< parser::identify_prefix_and_key(" << element << ")" 
		<< endl;
	#endif
	}

/*!
	\brief If the argument requires values, this method parses it.

	\param A string that will be used as the prefix.
	\param A string that will be used as the key.
	\param A string that will be used as the assignment.
	\param A string that will be used as the value.
	\param The argument* that will get values.
	\param The iterator that points to the tokens to be parsed.
	\param The iterator indicating the end of the tokens to be parsed.
*/
void
commandl::parser::parse_required_values
	(
	std::string							prefix,
	std::string							key,
	std::string							assignment,
	std::string							value,
	commandl::argument*			argument,
	std::vector<std::string>::iterator&	element_iterator,
	std::vector<std::string>::iterator	element_end
	)
	{
	using std::string;
	using std::vector;

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << ">>> parser::parse_required_values( . . . )" << endl;
	#endif

	// Do we need exactly one value, and do we have exactly one?
	if( (*argument).values_size() == 1 && !value.empty() )
		{
		(*argument)( value, prefix, key, assignment, ++Position );
		return;
		}

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "    is_token_separator_assignment(): "
		<< Policy.is_token_separator_assignment() << endl;
	#endif

	if( Policy.is_token_separator_assignment() )
		{
		vector<string> values;
		if( !value.empty() )
			{
			values.push_back( value );
			}

		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    about to start going to the next element" << endl;
		cerr << "    the current element is " << *element_iterator << endl;
		bool temp = (values.size() < (*argument).values_size())
					|| ((*argument).values_size() < 0);
		cerr << "    is values.size() <= values_size(): " << temp << endl;
		temp = element_iterator != element_end;
		cerr << "    is element_iterator != element_end: " << temp << endl;
		#endif
		for
			(++element_iterator;
				(	(values.size() < (*argument).values_size()) 
					||
					((*argument).values_size() < 0)
				)
				&&
				( element_iterator != element_end );
			++element_iterator
			)
		//while( *argument.values_size() < values.size() )
			{
			//++element_iterator;
			try
				{
				// We just want to know if there is a prefix.
				identify_prefix_and_key( *element_iterator );

				if( (*argument).values_size() < 0 )
					{
					// We don't need that next element, so the
					// iterator needs to be backed up.
					--element_iterator;

					if( values.empty() )
						{
						// No values to call this argument on.
						throw parser_exception	( 
												"No values found for argument.",
												key
												);
						}
					break;
					}
				else
					{
					if( Policy.ignore_prefix_if_value_required() )
						{
						// There is a prefix, but we take it anyway.
						#if ((DEBUG) & DEBUG_METHODS)
						cerr << "    add this element to values: "
							<< *element_iterator << endl;
						#endif
						values.push_back( *element_iterator );
						}
					else
						{
						// We need a value, but do not have one.

						// Since the next element has a prefix, we
						// need to back up the iterator.
						--element_iterator;

						throw parser_exception	(
												"No values found for argument.",
												key
												);
						}
					}
				}
			catch( const no_prefix& ex )
				{
				// No prefix on the next element.
				#if ((DEBUG) & DEBUG_METHODS)
				cerr << "    add this element to values: " 
					<< *element_iterator << endl;
				#endif
				values.push_back( *element_iterator );
				}
			catch( const matcher_exception& ex )
				{
				// Prefix but no match on the key in the next element.
				#if ((DEBUG) & DEBUG_METHODS)
				cerr << "    add this element to values: " 
					<< *element_iterator << endl;
				#endif
				values.push_back( *element_iterator );
				}
			}
		if(
			( (*argument).values_size() == values.size() )
			||
			( (*argument).values_size() < 0 && !values.empty() )
		  )
			{
			(*argument)( values, prefix, key, assignment, ++Position );
			}
		else
			{
			throw parser_exception
			(
			"This argument required several values, but none could be found.",
			key
			);
			}
		}
	else
		{
		// The token separator isn't an assignment.

		if( (( *argument ).values_size() < 0) && (!value.empty())  )
			{
			(*argument)( value, prefix, key, assignment, ++Position );
			}
		else
			{
			throw parser_exception
			(
			"This argument required several values, but none could be found.",
			key
			);
			}
		}
	// back up the iterator to point to the last element parsed/used.
	--element_iterator;

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "<<< parser::parse_required_values( . . . )" << endl;
	#endif
	return;
	}


/*!
	\brief If the argument has optional values, this method parses it.

	\param A string that will be used as the prefix.
	\param A string that will be used as the key.
	\param A string that will be used as the assignment.
	\param A string that will be used as the value.
	\param The argument* that will get values.
	\param The iterator that points to the tokens to be parsed.
	\param The iterator indicating the end of the tokens to be parsed.
*/
void
commandl::parser::parse_optional_values
	(
	std::string							prefix,
	std::string							key,
	std::string							assignment,
	std::string							value,
	commandl::argument*			argument,
	std::vector<std::string>::iterator&	element_iterator,
	std::vector<std::string>::iterator	element_end
	)
	{
	using std::string;
	using std::vector;

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << ">>> parser::parse_optional_values( . . . )" << endl;
	#endif

	// Can we take exactly one value, and do we have exactly one?
	if( (*argument).values_size() == 1 && !value.empty() )
		{
		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    takes one and has one, calling (*argument)( . . .)" 
			<< endl;
		#endif
		(*argument)( value, prefix, key, assignment, ++Position );
		return;
		}

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "    is_token_separator_assignment(): " 
		<< Policy.is_token_separator_assignment() << endl;
	#endif

	if( Policy.is_token_separator_assignment() )
		{
		vector<string> values;
		if( !value.empty() )
			{
			values.push_back( value );
			}

		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    about to start going to the next element" << endl;
		cerr << "    the current element is " << *element_iterator << endl;
		bool temp = (values.size() < (*argument).values_size()) 
					|| ((*argument).values_size() < 0);
		cerr << "    is values.size() <= values_size(): " << temp << endl;
		temp = element_iterator != element_end;
		cerr << "    is element_iterator != element_end: " << temp << endl;
		#endif
		for
			(++element_iterator;
				(	(values.size() < (*argument).values_size()) 
					||
					((*argument).values_size() < 0)
				)
				&&
				( element_iterator != element_end );
			++element_iterator
			)
		//while( *argument.values_size() < values.size() )
			{
			//++element_iterator;
			#if ((DEBUG) & DEBUG_METHODS)
			cerr << "    next element is " << *element_iterator << endl;
			#endif
			try
				{
				// We just want to know if there is a prefix & match.
				identify_prefix_and_key( *element_iterator );

				--element_iterator;

				if( values.empty() )
					{
					(*argument)( prefix, key, ++Position );
					return;
					}
				else
					{
					break;
					}
				
				}
			catch( const no_prefix& ex )
				{
				// No prefix on the next element.
				#if ((DEBUG) & DEBUG_METHODS)
				cerr << "    add this element to values: " 
					<< *element_iterator << endl;
				#endif
				values.push_back( *element_iterator );
				}
			catch( const matcher_exception& ex )
				{
				// Prefix but no match on the key in the next element.
				#if ((DEBUG) & DEBUG_METHODS)
				cerr << "    add this element to values: " 
					<< *element_iterator << endl;
				#endif
				values.push_back( *element_iterator );
				}
			}
		if(
			( (*argument).values_size() == values.size() )
			||
			( !values.empty() )
		  )
		  	{
			(*argument)( values, prefix, key, assignment, ++Position );
			}
		else
			{
			(*argument)( prefix, key, ++Position );
			}
		}
	else
		{
		// The token separator isn't an assignment.
		if( value.empty() )
			{
			(*argument)( prefix, key, ++Position );
			}
		else
			{
			(*argument)( value, prefix, key, assignment, ++Position );
			}
		}
	// back up the iterator to point to the last element parsed/used.
	--element_iterator;
	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "<<< parser::parse_optional_values( . . . )" << endl;
	#endif
	return;
	}

/*!
	\brief This method will recursively break up a token to try and find keys
			amongst the leading characters.

	For example, this method would could take the token "fbar" and depending
	on the Policy would interpret in in different ways:
	
	<table>
	<tr><td>key(s)	<td>value
	<tr><td>fbar	<td>Can be optionally looked for in the next token.
	<tr><td>f		<td>bar
	<tr><td>f,b,a,r <td>The key "r" could optionally look to the next token.
	<tr><td>f,b		<td>The key "b" could take "ar"
	<tr><td>f,b,a	<td>The key "a" could take "r"
	</table>

	\param A string that will be used as the prefix.
	\param A string that will be used as the element to break up.
	\param The iterator that points to the tokens to be parsed.
	\param The iterator indicating the end of the tokens to be parsed.
	\param A boolean indicating whether this method is being called
			from within itself.
*/
void
commandl::parser::parse_character_keys
	(
	std::string							prefix,
	std::string							element,
	std::vector<std::string>::iterator&	element_iterator,
	std::vector<std::string>::iterator	element_end,
	bool								nested
	)
	{
	using std::string;
	using std::vector;

	#if ((DEBUG) & DEBUG_METHODS)
	cerr << ">>> parser::parse_character_keys( . . . )" << endl;
	#endif

	for/*ever*/(;;)
		{
		string key = element.substr	(
									string::size_type( 0 ),
									string::size_type( 1 )
									);
		string value = element.substr( string::size_type( 1 ) );
		#if ((DEBUG) & DEBUG_METHODS)
		cerr << "    key is " << key << ", and value is " << value << endl;
		#endif
		try
			{
			// The following will return a match, or throw.
			argument* matched_arg_ptr = Matcher_ptr->match( key );
			#if ((DEBUG) & DEBUG_METHODS)
			cerr << "    found a match" << endl;
			#endif
			
			if( (*matched_arg_ptr).values_size() == 0 )
				{
				// This argument doesn't want any values.
				(*matched_arg_ptr)( prefix, key, ++Position );
				
				if( value.empty() )
					{
					#if ((DEBUG) & DEBUG_METHODS)
					cerr << "<<< parser::parse_character_keys( . . . )" << endl;
					#endif
					return;
					}
				}
			else
				{
				// This argument is after one or more values.
				if( (*matched_arg_ptr).values_required() )
					{
					#if ((DEBUG) & DEBUG_METHODS)
					cerr << "    required" << endl;
					#endif
					parse_required_values	(
											prefix,
											key,
											string(),
											value,
											matched_arg_ptr,
											element_iterator,
											element_end
											);
					#if ((DEBUG) & DEBUG_METHODS)
					cerr << "    required done" << endl;
					cerr << "<<< parser::parse_character_keys( . . . )" << endl;
					#endif
					return;
					}
				else
					{
					if( !value.empty() )
						{
						try
							{
							#if ((DEBUG) & DEBUG_METHODS)
							cerr 
							<< "    recursively trying to parse a char key" 
							<< endl;
							#endif
							unsigned long temp_position( ++Position );
							parse_character_keys(
												prefix,
												value,
												element_iterator,
												element_end,
												true
												);

							(*matched_arg_ptr)( prefix, key, temp_position );
							#if ((DEBUG) & DEBUG_METHODS)
							cerr << "<<< parser::parse_character_keys( . . . )"
 								<< endl;
							#endif
							return;
							}
						catch( const matcher_exception& ex )
							{
							#if ((DEBUG) & DEBUG_METHODS)
							cerr << "    couldn't match " << value 
								<< " to a key" << endl;
							#endif
							--Position;
							// we want to call parse_optional_values,
							// so we do nothing here and just pass through.
							}
						}

					#if ((DEBUG) & DEBUG_METHODS)
					cerr << "    will try optional with " << key
						<< ", " << value << endl;
					#endif
					parse_optional_values	(
											prefix,
											key,
											string(),
											value,
											matched_arg_ptr,
											element_iterator,
											element_end
											);
					#if ((DEBUG) & DEBUG_METHODS)
					cerr << "    done with optional" << endl;
					cerr << "<<< parser::parse_character_keys( . . . )"
						<< endl;
					#endif
					return;
					}
				}

			}
		catch( const matcher_exception& ex )
			{
			#if ((DEBUG) & DEBUG_METHODS)
			cerr << "    there was no match" << endl;
			#endif
			if( nested )
				{
				// re-throw
				throw;
				}

			if( Policy.no_key_keep_going() )
				{
				if( Policy.no_key_keep_element() )
					{
					Elements_without_keys.insert
											(
											make_pair( ++Position, key )
											);
					}
				}
			else
				{
				//stop parsing
				string message( "The element \"" );
				message += key;
				message += "\" is not a valid key.";
				throw no_key( message, key );
				}
			}
		element = value;
		}
	#if ((DEBUG) & DEBUG_METHODS)
	cerr << "<<< parser::parse_character_keys( . . . )"	<< endl;
	#endif
	return;
	}

// --------------------------- Private Methods ------------------------ //

