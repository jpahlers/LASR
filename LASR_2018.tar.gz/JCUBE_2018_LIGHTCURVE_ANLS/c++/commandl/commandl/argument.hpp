/*
This is an abstract base class for command line arguments.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: argument.hpp,v 1.3 2003/03/25 23:53:36 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef ARGUMENT_HEADER	// Begin the Header Guard to prevent multiple
#define ARGUMENT_HEADER	//	inclusions.

#include <string>
#include <vector>

namespace commandl
{

/*!
	\brief The class from which all arguments descend.

	The argument class is an abstract base class that covers the various
	kinds of things that you want to be modifiable by the user of your
	program.  If these objects were just special function commandl
	objects, then you'd have to go through a second step to get the
	information that you want out of them to use in your program.
	However, through the magic of multiple inheritance and overloading,
	these objects are so much more.  For example, the commandl::int_arg
	class inherits from the abstract base class argument, but also
	functions just like an int.  You can use it just like you would use
	an int anywhere in your code, it just has a few extra methods that
	it inherits from commandl::argument so that it can be used by the
	commandl::parser object.  For example, once the parser has used the
	matcher to determine a match, it passes the prefix, key, assignment,
	value and other information to the argument, and the argument at
	this point can take those values and fill itself out, or it can
	throw an exception (if you try and pass the value <em>blah</em> to an
	int_arg, it will do just that).

	In addition to things like int_arg, float_arg, and string_arg that
	function like ints, floats, and strings, there are also a few special
	purpose argument classes, like usage_arg and stop_arg which essentially
	just interrupt the parsing process and cause the parser object to
	do some specific things (this is done via exceptions, such that
	argument objects don't have to know about the parser directly).
	The commandl::usage_arg argument object when matched causes the
	parser to emit a usage message either on STDERR or on an output
	stream of your choosing.  The commandl::stop_arg when matched causes
	the parser to stop parsing the tokens that it was given, and depending
	on the commandl::policy object being used will most likely put any
	extra tokens into a vector for later use.

	Also, a commandl::argument object is what I think of as a distal
	class.  It isn't involved in any of the parsing or matching activities,
	and doesn't use either of those classes.
*/
class argument
{

// ==================== Constructors & Destructor ===================== //
public:
	argument
		(
		std::vector<std::string>,	// keys
		std::string,				// value description
		std::string,				// description
		bool,						// argument required
		int,						// number of values
		bool						// values required?
		);

	argument
		(
		std::string,			// key
		std::string,			// value_description
		std::string,			// description
		bool,					// argument required
		int,					// number of values
		bool					// values required?
		);

	virtual ~argument()
		{};

// =========================== Accessors ============================== //
public:

	virtual
	void operator()	(
					const std::string&,					//prefix
					const std::string&,					//key
					const unsigned long					//order
					) = 0;
	virtual
	void operator()	(
					const std::string&,					//value
					const std::string&,					//prefix
					const std::string&,					//key
					const std::string&,					//assign
					const unsigned long					//order
					) = 0;
	virtual
	void operator()	(
					const std::vector<std::string>&,	//values
					const std::string&,					//prefix
					const std::string&,					//key
					const std::string&,					//assign
					const unsigned long					//order
					) = 0;

	virtual std::vector<std::string>	get_keys()				const;
	virtual bool						required()				const;
	virtual int							values_size()			const;
	virtual bool						values_required()		const;
	virtual bool						was_found()				const;
	virtual unsigned long				order()					const;
	virtual std::string					description()			const;
	virtual std::string					value_description()		const;

// =========================== Methods ================================ //
public:

	virtual void	add_key(	const std::string&	);
	virtual void	found(		const unsigned long	);


// --------------------------- Protected Methods ---------------------- //
protected:

	/*
	virtual int		number_of_values( int );
	virtual bool	is_required( bool );
	*/


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:

	/*! This contains the strings which are keys for this argument, how
		these keys are interpreted is based on the matcher object.
	*/	
	std::vector<std::string>	Keys;
	/*! This indicates whether the argument itself is required.
	*/
	bool						Argument_Required;
	/*! This defines how many values this argument knows how to accept.
	*/
	int							Number_Of_Values;
	/*!	Indicates whether the values are required, if number_of_values 
		is zero, this doesn't mean anything.
	*/
	bool						Values_Required;
	/*!
		Indicates whether the argument was found during parsing, and
		in which position.
	*/
	unsigned long				Found;
	/*!
		The description of this argument.
	*/
	std::string					Description;
	/*!
		The description of this argument's value.
	*/
	std::string					Value_Description;


};	// End of the class declaration

}	// End of the namespace declaration

#endif	// End the Header Guard

