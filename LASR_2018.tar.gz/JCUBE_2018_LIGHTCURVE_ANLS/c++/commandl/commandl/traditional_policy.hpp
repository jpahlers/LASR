/*
This is a policy class for the traditional "common" parsing scheme.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: traditional_policy.hpp,v 1.2 2003/03/03 00:52:30 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef TRADITIONAL_POLICY_HEADER	// Begin the Header Guard to prevent
#define TRADITIONAL_POLICY_HEADER	//	multiple inclusions.

#include "policy.hpp"
#include <bitset>
#include <string>
#include <vector>


namespace commandl
{

/*!
	\brief The class for traditional or common unix command line parsing.
*/
class traditional_policy : public policy
{

// ==================== Constructors & Destructor ===================== //
public:
	traditional_policy();

/*
	policy
		(
		std::bitset<8>,				// policy bitset
		std::vector<std::string>	// prefixes
		std::vector<std::string>	// assignments
		);
*/

// =========================== Accessors ============================== //
public:


// =========================== Methods ================================ //
public:


// --------------------------- Protected Methods ---------------------- //
protected:


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:


};	// End of the class declaration

}	// End of the namespace declaration

#endif	// End the Header Guard

