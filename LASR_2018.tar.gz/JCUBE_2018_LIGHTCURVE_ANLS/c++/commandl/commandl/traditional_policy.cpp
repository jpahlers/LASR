/*
This is a policy class for the traditional "common" parsing scheme.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: traditional_policy.cpp,v 1.2 2003/03/03 00:52:30 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <string>
#include <vector>
#include "traditional_policy.hpp"

/*
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "matcher ($Revision: 1.2 $ $Date: 2003/03/03 00:52:30 $)";
*/

// ==================== Constructors & Destructor ==================== //

commandl::traditional_policy::traditional_policy()
		:	policy()
		{

		add_prefix(		"--"	);
		add_prefix(		"-"		);
		add_assignment(	"="		);

		is_empty_valid_prefix(				false	);
		is_empty_valid_assignment(			true	);
		is_token_separator_assignment(		true	);
		no_prefix_keep_going(				false	);
		no_prefix_keep_element(				false	);
		no_key_keep_going(					false	);
		no_key_keep_element(				false	);
		ignore_prefix_if_value_required(	false	);
		}

// =========================== Accessors ============================== //


// =========================== Methods ================================ //


// --------------------------- Protected Methods ---------------------- //


// --------------------------- Private Methods ------------------------ //

