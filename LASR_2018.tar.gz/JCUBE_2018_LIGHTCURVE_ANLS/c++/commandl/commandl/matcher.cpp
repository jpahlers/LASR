/*
This is an abstract base class for matching potential keys to arguments.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: matcher.cpp,v 1.3 2003/03/25 23:53:36 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include "exceptions.hpp"
#include "matcher.hpp"
#include "argument.hpp"

/*
	This ID variable is useful for allowing this class to identify itself
	when it throws exceptions or otherwise.

private static const char*
	ID = "matcher ($Revision: 1.3 $ $Date: 2003/03/25 23:53:36 $)";
*/

// ==================== Constructors & Destructor ==================== //

commandl::matcher::matcher()
	{ }

/*	It is highly suggested that you implement a constructor of this
	form when deriving a class from matcher.
commandl::matcher::matcher
	(
	std::vector<argument*> arguments
	)
	{
	Keys = resolve_keys( arguments );
	}
*/

// Even though the destuctor is pure virtual, it still needs an implementation,
// or the linker will complain as it tries to destroy a matcher object.
commandl::matcher::~matcher() {}

// =========================== Accessors ============================== //

/*!
	\brief This method returns a copy of the map of unique keys to arguments.

	\return A map of keys to argument*.
*/
inline std::map<std::string, commandl::argument*>
commandl::matcher::keys() const
	{
	return Keys;
	}


// =========================== Methods ================================ //

/*!
	\brief This method allows you to give the matcher a new set of 
			arguments to resolve keys and match against.

	\param A vector of argument*
*/
void
commandl::matcher::set_arguments
	(
	const std::vector<argument*>& arguments
	)
	{
	std::map<std::string, commandl::argument*>
	temp_keys = resolve_keys(arguments);

	Keys.swap( temp_keys );
	return;
	}


// --------------------------- Protected Methods ---------------------- //


// --------------------------- Private Methods ------------------------ //

