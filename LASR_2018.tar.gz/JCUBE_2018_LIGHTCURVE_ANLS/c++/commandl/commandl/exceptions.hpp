/*
This header defines all of the exception classes for the commandl package.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: exceptions.hpp,v 1.3 2003/03/03 00:52:30 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef EXCEPTIONS_HEADER	// Begin the Header Guard to prevent
#define EXCEPTIONS_HEADER	//	multiple inclusions.

#include <exception>
#include <string>
#include <vector>

namespace commandl
{
class argument; // forward declaration

/*
	\brief This is the base exception class for the commandl library.
*/
class exception : public std::exception
{

// ==================== Constructors & Destructor ===================== //
public:


	exception( const std::string& what_message )
		: What( what_message )
		{ }

	virtual ~exception() throw()
		{ }

// =========================== Accessors ============================== //
public:

	virtual const char* what() const throw() { return What.c_str(); }


// =========================== Member Variables ======================= //
protected:

	//! Contains the primary message about this exception.
	std::string What;

}; // End of the class declaration



/*!
	\brief This is a base class for argument-related exceptions.
*/
class argument_exception : public exception
{

// ==================== Constructors & Destructor ===================== //
public:

	/*
	argument_exception( const std::string& what_message )i
		: commandl::exception( what_message )
		{ }
	*/

	argument_exception	(
						const	std::string&				what_message,
								commandl::argument* 		argument
						)
		:	commandl::exception(	what_message	),
			Arg_ptr( 				argument		)
		{ }

	argument_exception	(
						const	std::string&				what_message,
								commandl::argument*			argument,
						const	std::string&				prefix,
						const	std::string&				key
						)
		:	commandl::exception(	what_message	),
			Arg_ptr(	 			argument		),
			Prefix( 				prefix			),
			Key(					key				)
		{ }

	argument_exception	(
						const	std::string&				what_message,
								commandl::argument*			argument,
						const	std::string&				prefix,
						const	std::string&				key,
						const	std::string&				assign,
						const	std::string&				value
						)
		:	commandl::exception(	what_message	),
			Arg_ptr( 				argument		),
			Prefix( 				prefix			),
			Key(					key				),
			Assign(					assign			)
		{
		Values.push_back( value );
		}

	argument_exception	(
						const	std::string&				what_message,
								commandl::argument*			argument,
						const	std::string&				prefix,
						const	std::string&				key,
						const	std::string&				assign,
						const	std::vector<std::string>&	values
						)
		:	commandl::exception(	what_message	),
			Arg_ptr( 				argument		),
			Prefix( 				prefix			),
			Key(					key				),
			Assign(					assign			),
			Values(					values			)
		{ }

	virtual ~argument_exception() throw()
		{ }

// =========================== Accessors ============================== //
public:

	virtual argument*					arg_ptr()	const { return Arg_ptr; }
	virtual std::string					prefix()	const { return Prefix;	}
	virtual std::string					key()		const { return Key;		}
	virtual std::string					assign()	const { return Assign;	}
	virtual std::vector<std::string>	values()	const { return Values;	}


// =========================== Methods ================================ //
public:


// --------------------------- Protected Methods ---------------------- //
protected:


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:

	//! A pointer to the argument object that threw this exception.
	commandl::argument*	Arg_ptr;

	//! The prefix related to this exception.
	std::string 				Prefix;	

	//! The key related to this exception.
	std::string 				Key;

	//! The assignment related to this exception.
	std::string 				Assign;

	//! The values related to this exception.
	std::vector<std::string>	Values;

}; // End of the class declaration



/*!
	\brief This is a base class for matcher-related exceptions.
*/
class matcher_exception : public exception
{

// ==================== Constructors & Destructor ===================== //
public:

	/*!
		\brief Simple constructor for a matcher_exception.
	*/
	matcher_exception( const std::string& what_message )
		: commandl::exception( what_message )
		{ }

	/*!
		\brief Constructor for a matcher_exception that includes the key.

		matcher_exceptions happen when there are problems with a specific
		key.  This constructor for matcher_exception allows the user to
		place a copy of the potentially offending key in the exception.
	*/
	matcher_exception	(
						const std::string& what_message,
						const std::string& key
						)
		:	commandl::exception(	what_message	),
			Key(					key				)
		{ }

	virtual ~matcher_exception() throw()
		{ }

// =========================== Accessors ============================== //
public:

	virtual std::string key() const { return Key; }


// =========================== Methods ================================ //
public:


// --------------------------- Protected Methods ---------------------- //
protected:


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:

	std::string Key; //!< The key related to this exception.


}; // End of the class declaration


/*!
	\brief This is a base class for parser-related exceptions.
*/
class parser_exception : public exception
{

// ==================== Constructors & Destructor ===================== //
public:

	parser_exception( const std::string& what_message )
    	: commandl::exception( what_message )
    	{ }

	parser_exception
		(
		const std::string& what_message,
		const std::string& element
		)
    	:	commandl::exception( what_message ),
			Element( element )
    	{ }

	virtual ~parser_exception() throw()
		{ }

// =========================== Accessors ============================== //
public:

	std::string element() const
		{
		return Element;
		}

// =========================== Member Variables ======================= //
protected:

	std::string Element;

}; // End of the class declaration


/*!
	\brief This is a parser exception class for when no prefix is found.
*/
class no_prefix : public parser_exception
{

// ==================== Constructors & Destructor ===================== //
public:

	no_prefix( const std::string& what_message )
		: parser_exception( what_message )
    	{ }

	no_prefix( const std::string& what_message, const std::string& element )
		:	parser_exception( what_message, element )
    	{ }

	~no_prefix() throw()
		{ }


}; // End of the class declaration


/*!
	\brief This is a parser exception class for when parsing should halt.
*/
class stop_parsing: public parser_exception
{

// ==================== Constructors & Destructor ===================== //
public:

	stop_parsing( const std::string& what_message )
		: parser_exception( what_message )
    	{ }

	stop_parsing( const std::string& what_message, const std::string& element )
		:	parser_exception( what_message, element )
    	{ }

	~stop_parsing() throw()
		{ }

}; // End of the class declaration


/*!
	\brief This is a parser exception indicating that a usage statement 
		should be printed.
*/
class usage_exception: public parser_exception
{

// ==================== Constructors & Destructor ===================== //
public:

	usage_exception( const std::string& what_message )
		: parser_exception( what_message )
    	{ }

	usage_exception
		(
		const std::string& what_message,
		const std::string& element
		)
		: parser_exception( what_message, element )
    	{ }

	~usage_exception() throw()
		{ }

}; // End of the class declaration



/*!
	\brief This is a parser exception class for when no key could be identified.
*/
class no_key: public parser_exception
{

// ==================== Constructors & Destructor ===================== //
public:

	no_key( const std::string& what_message )
		: parser_exception( what_message )
    	{ }

	no_key( const std::string& what_message, const std::string& element )
		:	parser_exception( what_message, element )
    	{ }

	~no_key() throw()
		{ }


}; // End of the class declaration


} // End of namespace declaration

#endif	// End the Header Guard

