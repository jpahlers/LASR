/*
This is the master header file for the commandl package.  It is
provided as a convenience for the end-user, such that everything
needed can be easily included by simply including this header file.
    
	Copyright (C) 2003 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@RossBeyer.net

	CVS $Id: commandl.hpp,v 1.3 2003/03/03 16:34:27 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef COMMANDL_HEADER	// Begin the Header Guard to
#define COMMANDL_HEADER	// prevent multiple inclusions.

#include "commandl/exceptions.hpp"

#include "commandl/argument.hpp"
#include "commandl/int_arg.hpp"
#include "commandl/float_arg.hpp"
#include "commandl/string_arg.hpp"
#include "commandl/usage_arg.hpp"
#include "commandl/stop_arg.hpp"

#include "commandl/matcher.hpp"
#include "commandl/char_matcher.hpp"
#include "commandl/whole_matcher.hpp"

#include "commandl/policy.hpp"
#include "commandl/traditional_policy.hpp"

#include "commandl/parser.hpp"

#endif	// End the Header Guard

