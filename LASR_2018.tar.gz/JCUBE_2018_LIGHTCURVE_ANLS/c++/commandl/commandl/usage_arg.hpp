/*
This is a descendent of argument that will display a usage statement.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: usage_arg.hpp,v 1.2 2003/03/03 00:52:30 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef USAGE_ARG_HEADER	// Begin the Header Guard to prevent multiple
#define USAGE_ARG_HEADER	//	inclusions.

#include "argument.hpp"
#include <iosfwd>

namespace commandl
{

/*!
	\brief An argument class that when found will display a usage statement.
*/
class usage_arg : public argument
{

// ==================== Constructors & Destructor ===================== //
public:

	usage_arg
		(
		std::vector<std::string>,		// keys
		std::string = ""				// description
		);

	usage_arg
		(
		std::string,					// key
		std::string = ""				// description
		);

	virtual ~usage_arg()
		{};

// =========================== Accessors ============================== //
public:


// =========================== Methods ================================ //
public:

	//				 value(s)	prefix,      key,         assignment
	virtual
	void operator()	(
					const std::string&,					// prefix
					const std::string&,					// key
					const unsigned long					// order
					);
	virtual
	void operator()	(
					const std::string&,					// value
					const std::string&,					// prefix
					const std::string&,					// key
					const std::string&,					// assign
					const unsigned long					// order
					);
	virtual
	void operator()	(
					const std::vector<std::string>&,	// values
					const std::string&,					// prefix
					const std::string&,					// key
					const std::string&,					// assign
					const unsigned long					// order
					);

// --------------------------- Protected Methods ---------------------- //
protected:


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:


}; // End of the class declaration

} // End of the namespace declaration

#endif	// End the Header Guard

