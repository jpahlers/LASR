/*
This is an abstract base class for keeping track of parsing policies.
    
	Copyright (C) 2002 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@rossbeyer.net

	CVS $Id: policy.hpp,v 1.3 2003/03/25 23:53:37 rbeyer Exp $


  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl packge is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef BASIC_POLICY_HEADER	// Begin the Header Guard to prevent multiple
#define BASIC_POLICY_HEADER	//	inclusions.

#include <bitset>
#include <string>
#include <utility>
#include <vector>


namespace commandl
{

/*!
	\brief The class from which all policies descend.

	Policy objects are pretty much just data storage objects.  They
	contain a number of boolean values and other basic information like
	what the acceptable prefix tokens are (or if no prefix token is
	required), what the assignment operators are (or if no assignment
	operator is needed), and things like whether the parser should keep
	going if a token doesn't match and if it should keep track of those
	things which don't match.  Handy, but simple was the idea here.

*/
class policy
{

// ==================== Constructors & Destructor ===================== //
public:
	policy
		(
		std::vector<std::string>,						// prefixes
		std::vector<std::string>,						// assignments
		std::bitset<8>,									// policy bitset
		std::pair<std::string, std::string>				// optional_brackets
				= std::make_pair(std::string("["), std::string("]")),
		std::pair<std::string, std::string>				// value_brackets
				= std::make_pair(std::string("<"), std::string(">"))
		);

/*
	policy
		(
		std::bitset<8>,				// policy bitset
		std::vector<std::string>	// prefixes
		std::vector<std::string>	// assignments
		);
*/

	policy();


// =========================== Accessors ============================== //
public:

	virtual std::vector<std::string> 			prefixes()			const;
	virtual std::vector<std::string> 			assignments()		const;
	virtual std::pair<std::string, std::string>	optional_brackets()	const;
	virtual std::pair<std::string, std::string>	value_brackets()	const;
	
	virtual bool is_empty_valid_prefix()			const;
	virtual bool is_empty_valid_assignment()		const;
	virtual bool is_token_separator_assignment()	const;
	virtual bool no_prefix_keep_going()				const;
	virtual bool no_prefix_keep_element()			const;
	virtual bool no_key_keep_going()				const;
	virtual bool no_key_keep_element()				const;
	virtual bool ignore_prefix_if_value_required()	const;
	// virtual bool gobble_regardless_of_prefix()	const;


// =========================== Methods ================================ //
public:

	virtual void add_prefix(						const std::string&	);
	virtual void add_assignment(					const std::string&	);
	virtual void set_optional_brackets
						(
						const std::pair<std::string, std::string>&
						);
	virtual void set_value_brackets
						(
						const std::pair<std::string, std::string>&
						);
	virtual void is_empty_valid_prefix(				bool 				);
	virtual void is_empty_valid_assignment(			bool 				);
	virtual void is_token_separator_assignment(		bool 				);
	virtual void no_prefix_keep_going(				bool 				);
	virtual void no_prefix_keep_element(			bool 				);
	virtual void no_key_keep_going(					bool 				);
	virtual void no_key_keep_element(				bool 				);
	virtual void ignore_prefix_if_value_required(	bool 				);


// --------------------------- Protected Methods ---------------------- //
protected:


// --------------------------- Private Methods ------------------------ //
private:
	

// =========================== Member Variables ======================= //
protected:

	/*!
		This vector contains all of the strings that are valid prefixes
		for this policy.  Order is important, if you wanted both "--" 
		and "-" to be valid prefixes for this policy, then "--" should 
		be closer to the front of the vector of prefixes than just "-". 
		If a potential key was foo, and the command line to parse had
		"--foo" in it, if "-" were before "--", then the parser would
		match the first "-" and use "-foo" as the key to pass to the
		matcher.  Probably not the behavior that you want.
	*/
	std::vector<std::string>
	Prefixes;

	/*!
		This vector contains all of the strings that are valid assignments
		for this policy.  Again, order is important, see Prefixes.
	*/
	std::vector<std::string>
	Assignments;

	//! The strings that will bracket option elements in usage statements.
	std::pair<std::string, std::string> Optional_Brackets;

	//! The strings that will bracket value elements in usages statements.
	std::pair<std::string, std::string> Value_Brackets;

	//! Is the empty string a valid prefix?
	bool
	Empty_Is_Prefix;

	//! Is the empty string a valid assignment?
	bool
	Empty_Is_Assignment;

	//! Is the boundary between tokens a valid assignment?
	bool
	Separator_Is_Assignment;

	//! Should the parser keep going if there is an element with no prefix?
	bool
	No_Prefix_Keep_Going;

	//! If there is an element with no prefix, should it be kept?
	bool
	No_Prefix_Keep_Element;

	//! Should the parser keep going if there is an element with no valid key?
	bool
	No_Key_Keep_Going;

	//! If there is an element with no key, should it be kept?
	bool
	No_Key_Keep_Element;

	/*! In the case of arguments with required values, if the next element 
		has a valid prefix, should it be taken as a value anyway?
	*/
	bool
	Ignore_Prefix;

};	// End of the class declaration

}	// End of the namespace declaration

#endif	// End the Header Guard

