/*
This program runs a natural neighbor algorithm on irregularly gridded data.
    
	Copyright (C) 2003 Ross A. Beyer

		Contact Author: Ross A. Beyer, rbeyer@lpl.arizona.edu

	CVS $Id: nn.cpp,v 1.1 2003/03/31 04:48:07 rbeyer Exp $

  License & Copyright Information
  -------------------------------

	This file is part of the commandl package, 
	$Name: commandl_Beta-1 $.

    The commandl package is free software; you can redistribute it
    and/or modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2 of the 
	License, or (at your option) any later version.

    The commandl package is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  Program Details
  ---------------

	This program was originally crafted to read in some data from a file
	of irregularly gridded data (from the Mars Orbital Laser Altimeter
	on the Mars Global Surveyor spacecraft, FYI).  The actual program
	uses a C++ wrapper for the ngmath library's natgrids function
	(a part of the NCAR Graphics library).  However, so that you
	don't have to install the ngmath library just to get this example
	to work, that part has been removed.


*/

#include <string>
#include <vector>
#include <stdexcept>
#include <iostream>
#include <istream>
#include <fstream>
#include <limits>
#include <algorithm>
#include <iterator>
#include <commandl.hpp>


/* This little function should define a Manipulator to ignore the
	rest of the line.  It was taken from page 614 of the Josuttis book.
*/
std::istream&
ignoreLine( std::istream& stream )
	{
	//skip until end-of-line
	//stream.ignore( std::numeric_limits<int>::max(), '\n' );
	stream.ignore( std::numeric_limits<std::streamsize>::max(), '\n' );

	return stream;
	}


int main( int argc, char* argv[] )
try	{
	using namespace std;
	using namespace commandl;

	/* Set up the arguments and parse the command line */
	string_arg	input_file	(
							"input",
							"filename",
							"This is file should contain the output from the PEDR2TAB program. Alternately, any file that has two header lines and then the first three columns of data should be latitude, longitude, and elevation.",
							true,
							true
							);
	string_arg	output_file	(
							"output",
							"filename",
							"This is the name of the file that this program will write its output to.  The output will be in a form consumable by OpenDX.",
 							true, // maybe not if I can default to STDOUT.
							true
							);
	int_arg		numxout	(
						"x",
						"number of x elements", 
						"This argument specifies the number of elements in the x direction that will be present in the output grid.",
						true,
						true
						);
	int_arg		numyout	(
						"y",
						"number of y elements", 
						"This argument specifies the number of elements in the y direction that will be present in the output grid.",
						true,
						true
						);
	float_arg	lat_max	(
						//"latitude maximum",
						"n",
						"latitude in degrees",
						"If specified, this will serve as a northernmost limit to the extent of the output grid.",
						false,
						true
						);
	float_arg	lat_min (
						//"latitude minimum",
						"s",
						"latitude in degrees",
						"If specified, this will serve as a southernmost limit to the extent of the output grid.",
						false,
						true
						);
	float_arg	lon_max	(
						//"longitude maximum",
						"e",
						"east longitude in degrees",
						"If specified, this will serve as an easternmost limit to the extent of the output grid.",
						false,
						true
						);
	float_arg	lon_min	(
						//"longitude minimum",
						"w",
						"east longitude in degrees",
						"If specified, this will serve as a westernmost limit to the extent of the output grid.",
						false,
						true
						);
	int_arg		verbose	(
						"v",
						"verbosity level", 
						"Enabling this argument makes the program verbose. There are currently only two levels of verbosity: 0 and 1. Level 1 is very verbose.",
						false,
						false
						);
	usage_arg	usage	(
						"help",
						"Displays a usage message"
						);

	// Set up appropriate defaults
	lat_max =  90.0;
	lat_min = -90.0;
	lon_max = 360.0;
	lon_min =   0.0;
	verbose = 0;

	vector<argument*> arguments;
	arguments.push_back( &input_file );
	arguments.push_back( &output_file );
	arguments.push_back( &numxout );
	arguments.push_back( &numyout );
	arguments.push_back( &lat_max );
	arguments.push_back( &lat_min );
	arguments.push_back( &lon_max );
	arguments.push_back( &lon_min );
	arguments.push_back( &verbose );
	arguments.push_back( &usage	);

	// Everything is ready, set up a matcher and parse those arguments!
	char_matcher my_matcher( arguments );
	parser my_parser( arguments, my_matcher );
	bool parsed = my_parser.parse( argc, argv );

	// Check the return value of the parse() method, and do the 
	// appropriate thing.  Or turn on exceptions and catch them.
	if( !parsed )
		{
		exit(1);
		}

	/* Error check the input numbers */
	if( numxout <= 0 )
		{
		throw std::invalid_argument( "numxout must be positive" );
		}
	if( numyout <= 0 )
		{
		throw std::invalid_argument( "numyout must be positive" );
		}
	if( lat_max <= lat_min )
		{
		throw std::invalid_argument( "The maximum latitude must be greater than the minimum latitude.");
		}
	if( lon_max <= lon_min )
		{
		throw std::invalid_argument( "The maximum longitude must be greater than the minimum longitude.");
		}

	if( verbose.was_found() )
		{
		cerr << "Done with initial argument parsing and setup." << endl;
		}
	
	/* We need to parse the input file for latitude, longitude, and elevation.
		This logic assumes that the input file is the output from the
		PEDR2TAB program, and that the first three columns are the data
		that we are after.  I suppose if we wanted to be really fancy
		we could parse the header line for the keywords that we are
		after and then grab the data from the columns in an adaptive
		sort of way, but that would entail a lot of work.
	*/
	vector<float> latitude;
	vector<float> longitude;
	vector<float> elevation;

	/* Open the file */
	ifstream input( input_file.c_str() );
	if( !input )
	    {
	    cerr << "Cannot open input file " << input_file << endl;
	    exit(1);
	    }
	// We need to skip the two header lines.
	input >> ignoreLine >> ignoreLine;


	float temp_lon, temp_lat, temp_el;
	//while( !input.eof() )
	while( input >> temp_lon >> temp_lat >> temp_el >> ignoreLine )
		{
		/* Grab the first three whitespace separated values from each line
		*/

		if( verbose > 0 )
			{
			cerr << temp_lon << "\t" << temp_lat << "\t" << temp_el << endl;
			}

		// Only include values if they are within the specified bounds.
		if	(
			(temp_lat <= lat_max) && (temp_lat >= lat_min) &&
			(temp_lon <= lon_max) && (temp_lon >= lon_min)
			)
			{
			if( verbose > 0 )
				{
				cerr << "element passed into push_back stage" << endl;
				cerr << temp_lon << "\t" << temp_lat << "\t" << temp_el << endl;
				}
			latitude.push_back(		temp_lat	);
			longitude.push_back(	temp_lon	);
			elevation.push_back(	temp_el		);
			}
		}			
	input.close();

	if( verbose.was_found() )
		{
		cerr << "Done parsing the file for data." << endl;
		}

	/* Determine what the edges of the output grid should be */
	float x_max, x_min, y_max, y_min;

	if( lat_max.was_found() )
		{
		y_max = lat_max;
		}
	else
		{
		//find the maximum value in the latitude array
		y_max = *max_element( latitude.begin(),latitude.end() );
		}

	if( lat_min.was_found() )
		{
		y_min = lat_min;
		}
	else
		{
		//find the minimum value in the latitude array
		y_min = *min_element( latitude.begin(),latitude.end() );
		}

	if( lon_max.was_found() )
		{
		x_max = lon_max;
		}
	else
		{
		//find the maximum value in the longitude array
		x_max = *max_element( longitude.begin(),longitude.end() );
		}

	if( lon_min.was_found() )
		{
		x_min = lon_min;
		}
	else
		{
		//find the minimum value in the longitude array
		x_min = *min_element( longitude.begin(),longitude.end() );
		}

	if( verbose.was_found() )
		{
		cerr << "Done determining the edges of the output grid." << endl;

		if( verbose > 0 )
			{
			cerr << "Number of elements in the longitude vector: " 
				<< longitude.size() << endl;
			}

		cerr << "Starting to run the natural neighbor algorithm." << endl;
		}

	/*
		In the original program this is where we ran the natural neighbor
		algorithm.  We'll skip that for this example.
		
	*/

	if( verbose.was_found() )
		{
		cerr << "Done with the natural neighbor algorithm." << endl;
		}

	/* Instead of writing out data that we don't have, we'll just create
		a little message in the specified output file.
	*/
	ofstream output( output_file.c_str() );
	if( !output )
		{
		cerr << "cannot open the output file " << output_file << endl;
		std::exit(1);
		}

	output	<< "This is only an example." << endl
			<< "In the event of a real program, this output file would have real data in it." << endl
			<< endl
			<< "This has been an example." << endl;

	output.close();

	exit(0);
	}
catch( const std::exception& ex )
	{
	std::cerr << ex.what() << std::endl;
	exit(1);
	}
